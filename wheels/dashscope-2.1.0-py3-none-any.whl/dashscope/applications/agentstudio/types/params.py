# -*- coding: utf-8 -*-
# Copyright (c) Alibaba, Inc. and its affiliates.
"""Per-resource API request parameter definitions.

Each resource group (Agents, Environments, Sessions, …) defines the
request-body structures for its write endpoints.  All classes inherit
from :class:`~dashscope.applications.agentstudio.types.models.BaseModel` so that
``.to_dict()`` produces a ready-to-send wire-format dict.

The ``__init__`` signature uses **user-friendly** parameter names
(e.g. ``system_prompt``) while the ``super().__init__()`` call passes
**wire-format** field names (e.g. ``system``).

Python 3.8+ compatible.
"""

from __future__ import annotations

from typing import Any, Dict, Mapping, Optional, Sequence, Union

from dashscope.applications.agentstudio.types.models import (
    BaseModel,
    ModelConfig,
    ResourceInput,
)

_NOT_GIVEN = object()


def _to_mapping(value: Any) -> Any:
    if hasattr(value, "to_dict"):
        return value.to_dict()
    if isinstance(value, Mapping):
        return dict(value)
    return value


def _resolve_model(
    model: Optional[Union[str, ModelConfig]],
) -> Dict[str, Any]:
    """Wire ``model`` from a ModelConfig or a bare model id; id required."""
    if model is None:
        raise ValueError("model is required")
    if isinstance(model, str):
        model = ModelConfig(id=model)
    if not isinstance(model, ModelConfig):
        raise TypeError(
            f"model must be a ModelConfig, got {type(model).__name__} "
            "(use ModelConfig(**raw))",
        )
    if not model.id:
        raise ValueError("model.id is required")
    return model.to_dict()


# ===========================================================================
# Agents
# ===========================================================================


class AgentCreateParams(BaseModel):
    """Request body for ``POST /agents``.

    Maps to :meth:`Agents.create`.  The SDK method exposes ``model`` as a
    :class:`ModelConfig` or a bare model id, and ``system_prompt`` as a
    keyword arg; the wire format uses ``model: {"id": "…", …}`` and
    ``system``.
    """

    _fields = (
        "name",
        "model",
        "description",
        "system",
        "tools",
        "mcp_servers",
        "skills",
        "multiagent",
        "metadata",
    )

    def __init__(
        self,
        *,
        name: str,
        model: Union[str, ModelConfig],
        description: Optional[str] = None,
        system_prompt: Optional[str] = None,
        tools: Optional[Sequence[Mapping[str, Any]]] = None,
        mcp_servers: Optional[Sequence[Mapping[str, Any]]] = None,
        skills: Optional[Sequence[Mapping[str, Any]]] = None,
        multiagent: Optional[Mapping[str, Any]] = None,
        metadata: Optional[Mapping[str, Any]] = None,
    ) -> None:
        super().__init__(
            name=name,
            model=_resolve_model(model),
            description=description,
            system=system_prompt,
            tools=([dict(t) for t in tools] if tools is not None else None),
            mcp_servers=(
                [dict(s) for s in mcp_servers]
                if mcp_servers is not None
                else None
            ),
            skills=([dict(s) for s in skills] if skills is not None else None),
            multiagent=(
                _to_mapping(multiagent) if multiagent is not None else None
            ),
            metadata=(dict(metadata) if metadata is not None else None),
        )


class AgentUpdateParams(BaseModel):
    """Request body for ``POST /agents/{id}`` (update latest version)."""

    _fields = (
        "version",
        "name",
        "model",
        "description",
        "system",
        "tools",
        "mcp_servers",
        "skills",
        "multiagent",
        "metadata",
    )

    def __init__(
        self,
        *,
        version: int,
        name: Optional[str] = None,
        model: Optional[Union[str, ModelConfig]] = None,
        description: Optional[str] = None,
        system_prompt: Optional[str] = None,
        tools: Optional[Sequence[Mapping[str, Any]]] = None,
        mcp_servers: Optional[Sequence[Mapping[str, Any]]] = None,
        skills: Optional[Sequence[Mapping[str, Any]]] = None,
        multiagent: Optional[Mapping[str, Any]] = None,
        metadata: Optional[Mapping[str, Any]] = None,
    ) -> None:
        super().__init__(
            version=version,
            name=name,
            model=(_resolve_model(model) if model is not None else None),
            description=description,
            system=system_prompt,
            tools=([dict(t) for t in tools] if tools is not None else None),
            mcp_servers=(
                [dict(s) for s in mcp_servers]
                if mcp_servers is not None
                else None
            ),
            skills=([dict(s) for s in skills] if skills is not None else None),
            multiagent=(
                _to_mapping(multiagent) if multiagent is not None else None
            ),
            metadata=(dict(metadata) if metadata is not None else None),
        )


class AgentListParams(BaseModel):
    """Query params for ``GET /agents``.

    ``include_archived`` is a Python bool mapped to the wire-format
    string ``"true"`` / ``"false"``.
    """

    _fields = ("limit", "page", "include_archived")

    def __init__(  # pylint: disable=useless-parent-delegation
        self,
        *,
        limit: Optional[int] = None,
        page: Optional[str] = None,
        include_archived: Optional[bool] = None,
    ) -> None:
        archived = (
            str(include_archived).lower()
            if include_archived is not None
            else None
        )
        super().__init__(
            limit=limit,
            page=page,
            include_archived=archived,
        )


class AgentVersionListParams(BaseModel):
    """Query params for ``GET /agents/{id}/versions``."""

    _fields = ("limit", "page")


# ===========================================================================
# Environments
# ===========================================================================


class EnvironmentCreateParams(BaseModel):
    """Request body for ``POST /environments``."""

    _fields = ("name", "config", "description", "scope", "metadata")

    def __init__(  # pylint: disable=useless-parent-delegation
        self,
        *,
        name: str,
        config: Mapping[str, Any],
        description: Optional[str] = None,
        scope: Optional[str] = None,
        metadata: Optional[Mapping[str, Any]] = None,
    ) -> None:
        super().__init__(
            name=name,
            config=dict(config),
            description=description,
            scope=scope,
            metadata=(dict(metadata) if metadata is not None else None),
        )


class EnvironmentUpdateParams(BaseModel):
    """Request body for ``POST /environments/{id}``."""

    _fields = ("name", "description", "config", "scope", "metadata")

    def __init__(  # pylint: disable=useless-parent-delegation
        self,
        *,
        name: Optional[str] = None,
        description: Optional[str] = None,
        config: Optional[Mapping[str, Any]] = None,
        scope: Optional[str] = None,
        metadata: Optional[Mapping[str, Any]] = None,
    ) -> None:
        super().__init__(
            name=name,
            description=description,
            config=(dict(config) if config is not None else None),
            scope=scope,
            metadata=(dict(metadata) if metadata is not None else None),
        )


class EnvironmentListParams(BaseModel):
    """Query params for ``GET /environments``.

    ``include_archived`` is a Python bool mapped to the wire-format
    string ``"true"`` / ``"false"``.
    """

    _fields = ("limit", "page", "include_archived")

    def __init__(  # pylint: disable=useless-parent-delegation
        self,
        *,
        limit: Optional[int] = None,
        page: Optional[str] = None,
        include_archived: Optional[bool] = None,
    ) -> None:
        archived = (
            str(include_archived).lower()
            if include_archived is not None
            else None
        )
        super().__init__(
            limit=limit,
            page=page,
            include_archived=archived,
        )


# ===========================================================================
# Sessions
# ===========================================================================


class SessionCreateParams(BaseModel):
    """Request body for ``POST /sessions``.

    ``agent`` accepts the Agent ID string (backward compatible) **or** an
    Agent reference/override object (a mapping with
    ``type="agent_with_overrides"``) that establishes Session-level
    overrides for ``system``/``tools``/``mcp_servers``/``skills``.

    ``environment_variables`` and ``mcp_configs`` are Session-level
    settings independent of the agent. ``resources`` is create-only — it
    cannot be modified via ``updateSession``; each item is a mapping or
    a :class:`~dashscope.applications.agentstudio.types.models.Mount`
    (``file`` / ``memory_store`` — built-in or Bailian
    ``provider="agentstudio_memory"`` — / ``oss``).
    """

    _fields = (
        "agent",
        "environment_id",
        "title",
        "resources",
        "vault_ids",
        "environment_variables",
        "mcp_configs",
        "metadata",
    )

    def __init__(  # pylint: disable=useless-parent-delegation
        self,
        *,
        agent: Any,
        environment_id: Optional[str] = None,
        title: Optional[str] = None,
        resources: Optional[Sequence[ResourceInput]] = None,
        vault_ids: Optional[Sequence[str]] = None,
        environment_variables: Optional[Mapping[str, str]] = None,
        mcp_configs: Optional[Sequence[Mapping[str, Any]]] = None,
        metadata: Optional[Mapping[str, Any]] = None,
    ) -> None:
        super().__init__(
            agent=_to_mapping(agent),
            environment_id=environment_id,
            title=title,
            resources=(
                [_to_mapping(r) for r in resources]
                if resources is not None
                else None
            ),
            vault_ids=(list(vault_ids) if vault_ids is not None else None),
            environment_variables=(
                dict(environment_variables)
                if environment_variables is not None
                else None
            ),
            mcp_configs=(
                [_to_mapping(m) for m in mcp_configs]
                if mcp_configs is not None
                else None
            ),
            metadata=(dict(metadata) if metadata is not None else None),
        )


class SessionUpdateParams(BaseModel):
    """Request body for ``POST /sessions/{id}``.

    Omitted (``None``) fields are not sent — the existing value is kept;
    ``[]`` / ``{}`` explicitly clear the value. ``agent`` is a Session-level
    Agent config patch (a plain mapping carrying only ``system``/``tools``/
    ``mcp_servers``/``skills``); the mapping is passed through verbatim so
    an explicit ``None`` sub-field serializes to JSON ``null`` (delete the
    override and re-inherit), an omitted sub-field stays absent (keep the
    override), and ``[]`` / ``""`` override to empty. The server enforces
    the override principle; the SDK does not read or merge the agent source.
    """

    _fields = (
        "title",
        "metadata",
        "vault_ids",
        "environment_variables",
        "agent",
        "mcp_configs",
    )

    def __init__(  # pylint: disable=useless-parent-delegation
        self,
        *,
        title: Optional[str] = None,
        metadata: Optional[Mapping[str, Any]] = None,
        vault_ids: Optional[Sequence[str]] = None,
        environment_variables: Optional[Mapping[str, str]] = None,
        agent: Any = None,
        mcp_configs: Optional[Sequence[Mapping[str, Any]]] = None,
    ) -> None:
        super().__init__(
            title=title,
            metadata=(dict(metadata) if metadata is not None else None),
            vault_ids=(list(vault_ids) if vault_ids is not None else None),
            environment_variables=(
                dict(environment_variables)
                if environment_variables is not None
                else None
            ),
            agent=(_to_mapping(agent) if agent is not None else None),
            mcp_configs=(
                [_to_mapping(m) for m in mcp_configs]
                if mcp_configs is not None
                else None
            ),
        )


class SessionListParams(BaseModel):
    """Query params for ``GET /sessions``.

    ``statuses`` is a list of session status strings such as
    ``"idle"``, ``"running"``, ``"terminated"``.

    Python-friendly parameter names (``statuses``, ``created_at_gt``, …)
    are mapped to wire-format keys (``statuses[]``, ``created_at[gt]``, …)
    inside ``__init__``.
    """

    _fields = (
        "limit",
        "page",
        "agent_id",
        "statuses[]",
        "created_at[gt]",
        "created_at[gte]",
        "created_at[lt]",
        "created_at[lte]",
    )

    def __init__(
        self,
        *,
        limit: Optional[int] = None,
        page: Optional[str] = None,
        agent_id: Optional[str] = None,
        statuses: Optional[Sequence[str]] = None,
        created_at_gt: Optional[str] = None,
        created_at_gte: Optional[str] = None,
        created_at_lt: Optional[str] = None,
        created_at_lte: Optional[str] = None,
    ) -> None:
        kwargs = {}
        kwargs["limit"] = limit
        kwargs["page"] = page
        kwargs["agent_id"] = agent_id
        if statuses is not None:
            kwargs["statuses[]"] = list(statuses)
        if created_at_gt is not None:
            kwargs["created_at[gt]"] = created_at_gt
        if created_at_gte is not None:
            kwargs["created_at[gte]"] = created_at_gte
        if created_at_lt is not None:
            kwargs["created_at[lt]"] = created_at_lt
        if created_at_lte is not None:
            kwargs["created_at[lte]"] = created_at_lte
        super().__init__(**kwargs)


# ===========================================================================
# SessionEvents
# ===========================================================================


class SessionEventSendParams(BaseModel):
    """Request body for ``POST /sessions/{id}/events``.

    The ``input`` array must contain at least one event.
    """

    _fields = ("input",)

    def __init__(  # pylint: disable=useless-parent-delegation
        self,
        *,
        input: Sequence[  # pylint: disable=redefined-builtin
            Mapping[str, Any]
        ],
    ) -> None:
        super().__init__(
            input=[dict(e) for e in input],
        )


class SessionEventListParams(BaseModel):
    """Query params for ``GET /sessions/{id}/events``.

    ``types`` is a list of event type strings sent as repeated
    ``types[]`` query keys (the server parses a list, not a single
    comma-joined string).  ``created_at_*`` parameters are mapped to the
    bracket-based wire keys ``created_at[gt]`` etc.
    """

    _fields = (
        "types[]",
        "created_at[gt]",
        "created_at[gte]",
        "created_at[lt]",
        "created_at[lte]",
        "limit",
        "order",
        "page",
    )

    def __init__(
        self,
        *,
        types: Optional[Sequence[str]] = None,
        created_at_gt: Optional[str] = None,
        created_at_gte: Optional[str] = None,
        created_at_lt: Optional[str] = None,
        created_at_lte: Optional[str] = None,
        limit: Optional[int] = None,
        order: Optional[str] = None,
        page: Optional[str] = None,
    ) -> None:
        kwargs = {}
        if types is not None:
            kwargs["types[]"] = list(types)
        if created_at_gt is not None:
            kwargs["created_at[gt]"] = created_at_gt
        if created_at_gte is not None:
            kwargs["created_at[gte]"] = created_at_gte
        if created_at_lt is not None:
            kwargs["created_at[lt]"] = created_at_lt
        if created_at_lte is not None:
            kwargs["created_at[lte]"] = created_at_lte
        kwargs["limit"] = limit
        kwargs["order"] = order
        kwargs["page"] = page
        super().__init__(**kwargs)


# ===========================================================================
# Session Resources (runtime mount)
# ===========================================================================


class SessionResourceAddParams(BaseModel):
    """Request body for ``POST /sessions/{id}/resources`` (runtime mount).

    ``type`` is currently always ``"file"``; ``mount_path`` must be an
    absolute path under ``/uploads/``. The server returns a
    session-scoped copy ``file_id`` that differs from this source id.
    """

    _fields = ("type", "file_id", "mount_path")


class SessionResourceListParams(BaseModel):
    """Query params for ``GET /sessions/{id}/resources``."""

    _fields = ("limit", "page")


class SessionThreadListParams(BaseModel):
    """Query params for ``GET /sessions/{id}/threads``."""

    _fields = ("limit", "page")


# ===========================================================================
# Security (overview + agent logs)
# ===========================================================================


class SecurityListAgentLogsParams(BaseModel):
    """Query params for ``GET /security/agent_logs``.

    Page-number pagination (``current_page`` / ``page_size``); the response
    also carries a ``next_page`` cursor (null at the end). Filters:
    ``risk_level`` (high/medium/low), ``status``, ``risk_name``,
    ``app_name``, ``asset_type`` (agent/tool/skill/knowledge_base/memory/
    channel), ``vendor``, ``order_by`` (default check_time), ``order``
    (asc/desc), ``lang`` (zh/en), ``status_list`` (multi-value).
    """

    _fields = (
        "current_page",
        "page_size",
        "risk_level",
        "status",
        "risk_name",
        "app_name",
        "asset_type",
        "vendor",
        "order_by",
        "order",
        "lang",
        "status_list",
    )

    def __init__(
        self,
        *,
        current_page: Optional[int] = None,
        page_size: Optional[int] = None,
        risk_level: Optional[str] = None,
        status: Optional[str] = None,
        risk_name: Optional[str] = None,
        app_name: Optional[str] = None,
        asset_type: Optional[str] = None,
        vendor: Optional[str] = None,
        order_by: Optional[str] = None,
        order: Optional[str] = None,
        lang: Optional[str] = None,
        status_list: Optional[Sequence[str]] = None,
    ) -> None:
        kwargs = {}
        kwargs["current_page"] = current_page
        kwargs["page_size"] = page_size
        kwargs["risk_level"] = risk_level
        kwargs["status"] = status
        kwargs["risk_name"] = risk_name
        kwargs["app_name"] = app_name
        kwargs["asset_type"] = asset_type
        kwargs["vendor"] = vendor
        kwargs["order_by"] = order_by
        kwargs["order"] = order
        kwargs["lang"] = lang
        if status_list is not None:
            kwargs["status_list"] = list(status_list)
        super().__init__(**kwargs)


# ===========================================================================
# Deployments
# ===========================================================================


class DeploymentCreateParams(BaseModel):
    """Request body for ``POST /deployments``."""

    _fields = (
        "name",
        "description",
        "agent",
        "environment_id",
        "schedule",
        "initial_events",
        "resources",
        "vault_ids",
        "environment_variables",
        "metadata",
    )

    def __init__(
        self,
        *,
        name: str,
        agent: Any,
        initial_events: Sequence[Mapping[str, Any]],
        description: Optional[str] = None,
        environment_id: Optional[str] = None,
        schedule: Any = None,
        resources: Optional[Sequence[Any]] = None,
        vault_ids: Optional[Sequence[str]] = None,
        environment_variables: Optional[Mapping[str, str]] = None,
        metadata: Optional[Mapping[str, str]] = None,
    ) -> None:
        BaseModel.__init__(
            self,
            name=name,
            description=description,
            agent=_to_mapping(agent),
            environment_id=environment_id,
            schedule=(_to_mapping(schedule) if schedule is not None else None),
            initial_events=[dict(event) for event in initial_events],
            resources=(
                [_to_mapping(resource) for resource in resources]
                if resources is not None
                else None
            ),
            vault_ids=(list(vault_ids) if vault_ids is not None else None),
            environment_variables=(
                dict(environment_variables)
                if environment_variables is not None
                else None
            ),
            metadata=(dict(metadata) if metadata is not None else None),
        )


class DeploymentUpdateParams(BaseModel):
    """Request body for ``POST /deployments/{deployment_id}``.

    ``environment_id`` and ``schedule`` preserve the distinction between an
    omitted argument and an explicit ``None``. Explicit ``None`` is emitted as
    JSON ``null`` to clear the field.
    """

    _fields = (
        "name",
        "description",
        "agent",
        "environment_id",
        "schedule",
        "initial_events",
        "resources",
        "vault_ids",
        "environment_variables",
        "metadata",
    )

    def __init__(
        self,
        *,
        name: Optional[str] = None,
        description: Optional[str] = None,
        agent: Any = None,
        environment_id: Any = _NOT_GIVEN,
        schedule: Any = _NOT_GIVEN,
        initial_events: Optional[Sequence[Mapping[str, Any]]] = None,
        resources: Optional[Sequence[Any]] = None,
        vault_ids: Optional[Sequence[str]] = None,
        environment_variables: Optional[Mapping[str, str]] = None,
        metadata: Optional[Mapping[str, str]] = None,
    ) -> None:
        self._environment_id_given = environment_id is not _NOT_GIVEN
        self._schedule_given = schedule is not _NOT_GIVEN
        super().__init__(
            name=name,
            description=description,
            agent=(_to_mapping(agent) if agent is not None else None),
            environment_id=(
                environment_id if self._environment_id_given else None
            ),
            schedule=(
                _to_mapping(schedule)
                if self._schedule_given and schedule is not None
                else None
            ),
            initial_events=(
                [dict(event) for event in initial_events]
                if initial_events is not None
                else None
            ),
            resources=(
                [_to_mapping(resource) for resource in resources]
                if resources is not None
                else None
            ),
            vault_ids=(list(vault_ids) if vault_ids is not None else None),
            environment_variables=(
                dict(environment_variables)
                if environment_variables is not None
                else None
            ),
            metadata=(dict(metadata) if metadata is not None else None),
        )

    def to_dict(self) -> dict:
        body = super().to_dict()
        if self._environment_id_given and self.environment_id is None:
            body["environment_id"] = None
        if self._schedule_given and self.schedule is None:
            body["schedule"] = None
        return body


class DeploymentListParams(BaseModel):
    """Query params for ``GET /deployments``."""

    _fields = (
        "agent_id",
        "keyword",
        "status",
        "include_archived",
        "limit",
        "page",
        "created_at[gte]",
        "created_at[lte]",
    )

    def __init__(
        self,
        *,
        agent_id: Optional[str] = None,
        keyword: Optional[str] = None,
        status: Optional[str] = None,
        include_archived: Optional[bool] = None,
        limit: Optional[int] = None,
        page: Optional[str] = None,
        created_at_gte: Optional[str] = None,
        created_at_lte: Optional[str] = None,
    ) -> None:
        super().__init__(
            agent_id=agent_id,
            keyword=keyword,
            status=status,
            include_archived=(
                str(include_archived).lower()
                if include_archived is not None
                else None
            ),
            limit=limit,
            page=page,
            **{
                "created_at[gte]": created_at_gte,
                "created_at[lte]": created_at_lte,
            },
        )


class DeploymentRunListParams(BaseModel):
    """Query params for deployment run list endpoints."""

    _fields = ("limit", "page")


# ===========================================================================
# Files
# ===========================================================================


class FileListParams(BaseModel):
    """Query params for ``GET /files``.

    File upload uses multipart form data and is therefore not
    represented as a param class.
    """

    _fields = ("limit", "page", "scope_id")


# ===========================================================================
# Skills
# ===========================================================================


class SkillCreateParams(BaseModel):
    """Request body for ``POST /skills``.

    ``file_id`` references a file previously uploaded via the Files API.
    The server extracts ``name`` and ``description`` from the zip's
    ``SKILL.md``; they are not client-settable.
    """

    _fields = ("file_id",)


class SkillListParams(BaseModel):
    """Query params for ``GET /skills``."""

    _fields = ("source", "limit", "page")


# ===========================================================================
# SkillVersions
# ===========================================================================


class SkillVersionCreateParams(BaseModel):
    """Request body for ``POST /skills/{skill_id}/versions``."""

    _fields = ("file_id",)


class SkillVersionListParams(BaseModel):
    """Query params for ``GET /skills/{skill_id}/versions``."""

    _fields = ("limit", "page")


# ===========================================================================
# Vaults
# ===========================================================================


class VaultCreateParams(BaseModel):
    """Request body for ``POST /vaults``."""

    _fields = ("display_name", "metadata")


class VaultUpdateParams(BaseModel):
    """Request body for ``POST /vaults/{vault_id}``."""

    _fields = ("display_name", "metadata")


class VaultListParams(BaseModel):
    """Query params for ``GET /vaults``."""

    _fields = ("include_archived", "limit", "page")

    def __init__(
        self,
        *,
        include_archived: Optional[bool] = None,
        **kwargs: Any,
    ) -> None:
        if include_archived is not None:
            kwargs["include_archived"] = str(
                include_archived,
            ).lower()
        super().__init__(**kwargs)


# ===========================================================================
# Credentials
# ===========================================================================


class CredentialCreateParams(BaseModel):
    """Request body for ``POST /vaults/{vault_id}/credentials``."""

    _fields = ("auth", "display_name", "metadata")

    def __init__(self, *, auth: Any = None, **kwargs: Any) -> None:
        if auth is not None:
            if hasattr(auth, "to_dict"):
                kwargs["auth"] = auth.to_dict()
            elif isinstance(auth, Mapping):
                kwargs["auth"] = dict(auth)
            else:
                kwargs["auth"] = auth
        super().__init__(**kwargs)


class CredentialUpdateParams(BaseModel):
    """Request body for ``POST /vaults/{v}/credentials/{c}``."""

    _fields = ("auth", "display_name", "metadata")

    def __init__(self, *, auth: Any = None, **kwargs: Any) -> None:
        if auth is not None:
            if hasattr(auth, "to_dict"):
                kwargs["auth"] = auth.to_dict()
            elif isinstance(auth, Mapping):
                kwargs["auth"] = dict(auth)
            else:
                kwargs["auth"] = auth
        super().__init__(**kwargs)


class CredentialListParams(BaseModel):
    """Query params for ``GET /vaults/{vault_id}/credentials``."""

    _fields = ("include_archived", "limit", "page")

    def __init__(
        self,
        *,
        include_archived: Optional[bool] = None,
        **kwargs: Any,
    ) -> None:
        if include_archived is not None:
            kwargs["include_archived"] = str(
                include_archived,
            ).lower()
        super().__init__(**kwargs)


# ===========================================================================
# Memory stores
# ===========================================================================


class MemoryStoreCreateParams(BaseModel):
    """Request body for ``POST /memory_stores``.

    ``name`` must contain 1..255 characters; names may repeat within
    a workspace, and the session mount slug ``/mnt/memory/<name>/`` is
    derived from it. ``description`` is passed to the agent — write it
    for the model, not for humans.
    """

    _fields = ("name", "description", "metadata")


class MemoryStoreUpdateParams(BaseModel):
    """Request body for ``POST /memory_stores/{store_id}``.

    ``metadata`` is replaced wholesale (unlike CMA's merge-patch):
    keys not included here are dropped; a key set to ``null`` deletes
    it. To change one key, re-send the whole mapping.
    """

    _fields = ("name", "description", "metadata")


class MemoryStoreListParams(BaseModel):
    """Query params for ``GET /memory_stores``.

    Note: unlike the console API, the public API has no ``keyword``
    filter.
    """

    _fields = ("include_archived", "limit", "page")

    def __init__(
        self,
        *,
        include_archived: Optional[bool] = None,
        **kwargs: Any,
    ) -> None:
        if include_archived is not None:
            kwargs["include_archived"] = str(
                include_archived,
            ).lower()
        super().__init__(**kwargs)


# ===========================================================================
# Memories
# ===========================================================================


class MemoryCreateParams(BaseModel):
    """Request body for ``POST /memory_stores/{store_id}/memories``.

    ``path`` rules (enforced server-side, case-sensitive): POSIX style
    with a leading ``/`` and no trailing ``/``; 2..1024 UTF-8 bytes;
    NFC-normalized; every segment non-empty and not ``.`` or ``..``;
    no control / format / line- or paragraph-separator code points.
    ``content`` is UTF-8 text, <= 102400 bytes.  A memory already
    existing at ``path`` returns 409 ``memory_path_conflict_error``
    (the same rules apply to a rename via ``memories.update``).
    """

    _fields = ("path", "content")


class MemoryUpdateParams(BaseModel):
    """Request body for ``POST /memory_stores/{store_id}/memories/{memory_id}``.

    At least one of ``path`` / ``content`` must be given.  Passing the
    current ``content_sha256`` (from the retrieved memory) enables
    optimistic concurrency — a mismatch returns 409
    ``memory_precondition_failed_error``.
    """

    _fields = ("path", "content", "content_sha256")


class MemoryListParams(BaseModel):
    """Query params for ``GET /memory_stores/{store_id}/memories``.

    ``path_prefix`` scopes the listing (server-validated: must start
    and end with ``/`` — ``"/notes/"`` matches ``/notes/a.md`` but not
    ``/notes_backup/old.md``; a bare ``"/"`` lists the whole store).
    ``depth`` is 0/absent (flat) or 1 (single-level tree) on the wire;
    ``view`` is ``basic`` (metadata only, the default, ``limit`` up to
    100) or ``full`` (include ``content``, ``limit`` capped at 20 —
    the backend rejects higher values with 400).
    """

    _fields = ("path_prefix", "depth", "view", "limit", "page")


# ===========================================================================
# Memory versions
# ===========================================================================


class MemoryVersionListParams(BaseModel):
    """Query params for ``GET /memory_stores/{store_id}/memory_versions``.

    Filters: ``memory_id``, ``operation`` (``created`` / ``modified`` /
    ``deleted``), ``created_at_gte`` / ``created_at_lte`` (ISO-8601
    timestamps; sent on the wire as ``created_at.gte`` /
    ``created_at.lte``), ``view`` (``basic`` / ``full``).  Versions are
    returned newest-first.
    """

    _fields = (
        "memory_id",
        "operation",
        "created_at.gte",
        "created_at.lte",
        "view",
        "limit",
        "page",
    )

    def __init__(
        self,
        *,
        created_at_gte: Optional[str] = None,
        created_at_lte: Optional[str] = None,
        **kwargs: Any,
    ) -> None:
        if created_at_gte is not None:
            kwargs["created_at.gte"] = created_at_gte
        if created_at_lte is not None:
            kwargs["created_at.lte"] = created_at_lte
        super().__init__(**kwargs)


# ===========================================================================
# Webhook endpoints
# ===========================================================================


class WebhookEndpointCreateParams(BaseModel):
    """Request body for ``POST /webhook_endpoints``."""

    _fields = ("description", "url", "events")


class WebhookEndpointUpdateParams(BaseModel):
    """Request body for ``PUT /webhook_endpoints/{id}``."""

    _fields = ("description", "url", "events")


class WebhookEventListParams(BaseModel):
    """Query parameters for endpoint-specific webhook events."""

    _fields = ("limit", "page")
