# -*- coding: utf-8 -*-
# Copyright (c) Alibaba, Inc. and its affiliates.
"""SessionEvents and AsyncSessionEvents resource classes."""

# Facade and resource objects are one internal AgentStudio implementation.
# pylint: disable=protected-access

from __future__ import annotations

from typing import (
    Any,
    AsyncIterator,
    Dict,
    Iterator,
    Mapping,
    Optional,
    Sequence,
)

from dashscope.applications.agentstudio.pagination import (
    AsyncCursorPage,
    CursorPage,
    build_page,
)
from dashscope.applications.agentstudio.resources._helpers import (
    _coerce_event,
    _events_path,
    _stream_path,
)
from dashscope.applications.agentstudio.streaming import (
    AsyncEventStream,
    EventStream,
)
from dashscope.applications.agentstudio.types import ServerEvent
from dashscope.applications.agentstudio.types.params import (
    SessionEventListParams,
    SessionEventSendParams,
)
from dashscope.applications.agentstudio.constants import (
    AGENTSTUDIO_DEFAULT_TIMEOUT,
    BlockType,
    SessionStatus,
    SSEEventType,
)

_TERMINAL_STATUSES = (
    SessionStatus.IDLE,
    SessionStatus.TERMINATED,
    SessionStatus.RESCHEDULED,
    SessionStatus.DELETED,
)


def _terminal_status(event: Any) -> bool:
    """True when a ``session_status`` event reports that the run is over."""
    if getattr(event, "type", None) != SSEEventType.SESSION_STATUS:
        return False
    block = event.content[0] if event.content else None
    data = getattr(block, "data", None) or {}
    return data.get("session_status") in _TERMINAL_STATUSES


class SessionEvents:
    """Session event send / list / stream."""

    def __init__(self, client) -> None:
        self._client = client

    def send(
        self,
        session_id: str,
        events: Sequence[Mapping[str, Any]],
    ) -> Dict[str, Any]:
        """Send events to a session."""
        if not events:
            raise ValueError("events must contain at least 1 entry")
        body = SessionEventSendParams(input=events).to_dict()
        resp = self._client.transport.request(
            "POST",
            _events_path(session_id),
            json=body,
        )
        return resp.data

    def list(
        self,
        session_id: str,
        *,
        types: Optional[Sequence[str]] = None,
        created_at_gt: Optional[str] = None,
        created_at_gte: Optional[str] = None,
        created_at_lt: Optional[str] = None,
        created_at_lte: Optional[str] = None,
        limit: Optional[int] = None,
        order: Optional[str] = None,
        page: Optional[str] = None,
    ) -> CursorPage[ServerEvent]:
        params = SessionEventListParams(
            types=types,
            created_at_gt=created_at_gt,
            created_at_gte=created_at_gte,
            created_at_lt=created_at_lt,
            created_at_lte=created_at_lte,
            limit=limit,
            order=order,
            page=page,
        ).to_dict()
        resp = self._client.transport.request(
            "GET",
            _events_path(session_id),
            params=params,
        )

        def fetch_next(nxt: str) -> CursorPage[ServerEvent]:
            return self.list(
                session_id,
                types=types,
                created_at_gt=created_at_gt,
                created_at_gte=created_at_gte,
                created_at_lt=created_at_lt,
                created_at_lte=created_at_lte,
                limit=limit,
                order=order,
                page=nxt,
            )

        return build_page(
            payload=resp.data,
            item_factory=_coerce_event,
            request_id=resp.request_id,
            fetch_next=fetch_next,
        )

    def stream(
        self,
        session_id: str,
        *,
        event_deltas: Optional[Sequence[str]] = None,
        timeout: Optional[float] = None,
    ) -> "_TypedEventStream":
        """Open the SSE stream and return an iterator of typed events.

        ``event_deltas`` opts into incremental streaming for the given event
        types (``"message"`` and/or ``"reasoning"``; aliases ``"agent.message"``
        / ``"agent.thinking"``); anything else the server rejects. The stream is
        read once, so ``text_deltas`` can be taken from it only; a second pass
        raises rather than returning nothing. A chunk stream is not a reliable
        source for final text: a reconnect replays only persisted events, so use
        ``text_stream``.
        """
        params: Optional[Dict[str, Any]] = None
        if event_deltas:
            params = {"event_deltas[]": list(event_deltas)}
        resp = self._client.transport.request(
            "GET",
            _stream_path(session_id),
            extra_headers={"Accept": "text/event-stream"},
            params=params,
            stream=True,
            timeout=timeout or AGENTSTUDIO_DEFAULT_TIMEOUT,
        )
        return _TypedEventStream(
            self._client._event_stream_cls(
                response=resp,
                exceptions_module=self._client.transport.exceptions,
            ),
        )


class _TypedEventStream:
    """Wrap :class:`EventStream` so iterating yields :class:`ServerEvent`.

    A stream is read once: a second pass would silently yield nothing, so it
    raises instead. Call ``sessions.events.stream()`` again to read the events.
    """

    _passed = False

    def __init__(self, stream: EventStream) -> None:
        self._stream = stream

    @classmethod
    def from_raw_events(
        cls,
        raw_events: Sequence[Mapping[str, Any]],
    ) -> "_TypedEventStream":
        """Create from a list of raw event dicts (for testing).

        Events flow through the normal :func:`_coerce_event` pipeline.
        """
        obj = object.__new__(cls)

        class _RawStream:
            def __iter__(self):
                return iter(raw_events)

            def close(self):
                pass

        obj._stream = _RawStream()
        return obj

    def __enter__(self) -> "_TypedEventStream":
        return self

    def __exit__(self, *exc: Any) -> None:
        self.close()

    def __iter__(self) -> Iterator[ServerEvent]:
        if self._passed:
            raise RuntimeError(
                "this stream is single-pass and was already consumed; call "
                "sessions.events.stream() again to read it again",
            )
        self._passed = True
        return self._iter()

    def _iter(self) -> Iterator[ServerEvent]:
        for payload in self._stream:
            yield _coerce_event(payload)

    @property
    def text_stream(self):
        """Iterate over text chunks from agent messages.

        Automatically stops when the session reaches ``idle`` or
        ``terminated`` status.
        """
        for event in self:
            if getattr(event, "type", None) == SSEEventType.MESSAGE:
                for block in event.content or []:
                    if getattr(block, "type", None) == BlockType.TEXT:
                        text = getattr(block, "text", "")
                        if text:
                            yield text
            elif _terminal_status(event):
                return

    @property
    def text_deltas(self):
        """Iterate over incremental text chunks from ``event_delta`` frames.

        Requires the stream to be opened with ``event_deltas``; otherwise
        yields nothing (use :attr:`text_stream` for terminal full text, which is
        also what a reconnect can rebuild — chunks are not replayed).
        """
        return self._text_deltas()

    def _text_deltas(self):
        for event in self:
            if getattr(event, "type", None) == "event_delta":
                text = event.delta_text
                if text:
                    yield text
            elif _terminal_status(event):
                return

    def close(self) -> None:
        self._stream.close()


class AsyncSessionEvents:
    """Async session event operations."""

    def __init__(self, client) -> None:
        self._client = client

    async def send(
        self,
        session_id: str,
        events: Sequence[Mapping[str, Any]],
    ) -> Dict[str, Any]:
        if not events:
            raise ValueError("events must contain at least 1 entry")
        body = SessionEventSendParams(input=events).to_dict()
        resp = await self._client.transport.request(
            "POST",
            _events_path(session_id),
            json=body,
        )
        return resp.data

    async def list(
        self,
        session_id: str,
        *,
        types: Optional[Sequence[str]] = None,
        created_at_gt: Optional[str] = None,
        created_at_gte: Optional[str] = None,
        created_at_lt: Optional[str] = None,
        created_at_lte: Optional[str] = None,
        limit: Optional[int] = None,
        order: Optional[str] = None,
        page: Optional[str] = None,
    ) -> AsyncCursorPage[ServerEvent]:
        params = SessionEventListParams(
            types=types,
            created_at_gt=created_at_gt,
            created_at_gte=created_at_gte,
            created_at_lt=created_at_lt,
            created_at_lte=created_at_lte,
            limit=limit,
            order=order,
            page=page,
        ).to_dict()
        resp = await self._client.transport.request(
            "GET",
            _events_path(session_id),
            params=params,
        )

        async def fetch_next(
            nxt: str,
        ) -> AsyncCursorPage[ServerEvent]:
            return await self.list(
                session_id,
                types=types,
                created_at_gt=created_at_gt,
                created_at_gte=created_at_gte,
                created_at_lt=created_at_lt,
                created_at_lte=created_at_lte,
                limit=limit,
                order=order,
                page=nxt,
            )

        return build_page(
            payload=resp.data,
            item_factory=_coerce_event,
            request_id=resp.request_id,
            page_cls=AsyncCursorPage,
            fetch_next=fetch_next,
        )

    async def stream(
        self,
        session_id: str,
        *,
        event_deltas: Optional[Sequence[str]] = None,
        timeout: Optional[float] = None,
    ) -> "_AioTypedEventStream":
        params: Optional[Dict[str, Any]] = None
        if event_deltas:
            params = {"event_deltas[]": list(event_deltas)}
        resp = await self._client.transport.request(
            "GET",
            _stream_path(session_id),
            extra_headers={"Accept": "text/event-stream"},
            params=params,
            stream=True,
            timeout=timeout or AGENTSTUDIO_DEFAULT_TIMEOUT,
        )
        return _AioTypedEventStream(
            self._client._event_stream_cls(
                response=resp,
                exceptions_module=self._client.transport.exceptions,
            ),
        )


class _AioTypedEventStream:
    def __init__(self, stream: AsyncEventStream) -> None:
        self._stream = stream

    async def __aenter__(self) -> "_AioTypedEventStream":
        return self

    async def __aexit__(self, *exc: Any) -> None:
        await self.aclose()

    _passed = False

    def __aiter__(self) -> AsyncIterator[ServerEvent]:
        if self._passed:
            raise RuntimeError(
                "this stream is single-pass and was already consumed; call "
                "sessions.events.stream() again to read it again",
            )
        self._passed = True
        return self._aiter()

    async def _aiter(self) -> AsyncIterator[ServerEvent]:
        async for payload in self._stream:
            yield _coerce_event(payload)

    @property
    def text_stream(self):
        return self._text_stream()

    async def _text_stream(self):
        async for event in self:
            if getattr(event, "type", None) == SSEEventType.MESSAGE:
                for block in event.content or []:
                    if getattr(block, "type", None) == BlockType.TEXT:
                        text = getattr(block, "text", "")
                        if text:
                            yield text
            elif getattr(event, "type", None) == SSEEventType.SESSION_STATUS:
                block = event.content[0] if event.content else None
                d = getattr(block, "data", None) or {}
                if d.get("session_status") in _TERMINAL_STATUSES:
                    return

    @property
    def text_deltas(self):
        """Async incremental text chunks from ``event_delta`` frames."""
        return self._text_deltas()

    async def _text_deltas(self):
        async for event in self:
            if getattr(event, "type", None) == "event_delta":
                text = event.delta_text
                if text:
                    yield text
            elif _terminal_status(event):
                return

    async def aclose(self) -> None:
        await self._stream.aclose()
