# -*- coding: utf-8 -*-
from __future__ import annotations

# Standard Library
import os
import re
import shutil
import tempfile
import asyncio

# Third-party Libraries
from pathlib import Path
from typing import Any, Dict, List, Optional, Union, Tuple
from typing_extensions import Self, Annotated
from pydantic import (
    BaseModel,
    Discriminator,
    Field,
    ConfigDict,
    Tag,
    field_validator,
)
import yaml

# Local Application
from .constants import (
    FC_DELETE_API,
    FC_LOAD_API,
    FC_QUERY_API,
    FC_QUERY_LOG_API,
    FC_REGISTER_REWARD_API,
    FC_REGISTER_ROLLOUT_API,
    FC_REGISTER_GROUP_REWARD_API,
    FC_UPLOAD_OSS_API,
    FC_LAYER_NAME,
    FC_REQUIREMENTS_FILE,
    FC_LAYER_USED,
    FC_LAYER_CREATE_API,
    FC_LAYER_QUERY_API,
    FC_LAYER_STATUS_TIMEOUT,
    FC_LAYER_STATUS_INTERVAL,
    LOG_LEVEL,
    resolve_fc_api_key,
)
from .model_types import (
    FileSpec,
    FunctionType,
    DatasetsType,
    DataSourceType,
    RequestFC,
    ResponseFC,
    Status,
    StatusType,
    TrainingType,
)
from ..component.data import (
    RewardInput,
    RewardOutput,
    RolloutInput,
    RolloutOutput,
    GroupRewardInput,
    GroupRewardOutput,
)
from .utils import (
    check_file,
    client_fc,
    create_deployment_files,
    deep_mask,
    generate_random_id,
    upload_zip_to_oss_and_by_signed_url,
    zip_dir,
    to_bailian_data,
    get_filepath_classname,
    get_func_type_id,
    get_weights_from_file,
    deep_remove_none,
)
from .log import logger
from .errors import (
    AgenticRLError,
    InputError,
    OutputError,
    OSSConnectionError,
    OSSUploadError,
    RegistrationError,
    FunctionLoadError,
    InstanceWarmupError,
    InstanceQueryError,
    FunctionLayerError,
    ValidationError,
    IOErrorWithCode,
    ValueErrorWithCode,
)

_LAYER_CREATE_REJECTED_SOLUTION = (
    "Review the server response and layer request. Fix invalid requirements "
    "or request parameters before retrying."
)
_LAYER_CREATE_LOCAL_SOLUTION = (
    "Check that the requirements file exists, is readable, and contains "
    "valid dependency declarations before retrying."
)
_LAYER_CREATE_TRANSIENT_SOLUTION = (
    "Retry after connectivity recovers. If the error persists, check the "
    "Function Compute layer service and request logs."
)
_LAYER_STATUS_QUERY_SOLUTION = (
    "Retry the layer status query after connectivity recovers."
)
_LAYER_STATUS_REJECTED_SOLUTION = (
    "Review the server response and layer code. For region lookup errors, "
    "report the request ID and layer code to the service owner before retrying."
)
_LAYER_BUILD_FAILED_SOLUTION = (
    "Check that requirements.txt or setup.py is valid and every dependency "
    "is installable, then review the layer build logs before retrying."
)
_LAYER_STATUS_MISSING_SOLUTION = (
    "Retry the status query. If the response still has no status, report the "
    "response and layer code to the service owner."
)
_LAYER_BUILD_TIMEOUT_SOLUTION = (
    "Increase FC_LAYER_STATUS_TIMEOUT if the layer is still building, then "
    "query the same layer code again instead of creating a duplicate layer."
)


def _fc_response_rejected(result: Dict[str, Any]) -> bool:
    status = result.get("status")
    return (
        (isinstance(status, dict) and status.get("code", 200) != 200)
        or result.get("code") not in (None, "", 0, 200)
        or result.get("success") is False
    )


class MountStorage(BaseModel):
    model_config = ConfigDict(extra="forbid")

    region: Optional[str] = None
    bucket: Optional[str] = None
    file_path: Optional[str] = None


class Dataset(BaseModel):
    model_config = ConfigDict(extra="forbid")

    type: DatasetsType = DatasetsType.TRAINING

    data_source_type: Optional[DataSourceType] = DataSourceType.FILE_ID
    file_name: Optional[str] = None
    file_id: Optional[str] = None
    download_url: Optional[str] = None
    mount_storage: Optional[MountStorage] = None

    async def upload_dataset(
        self,
        api_key: Optional[str] = None,
    ) -> Optional[str]:
        if (
            self.data_source_type == DataSourceType.FILE_ID
            and self.file_name is not None
        ):
            try:
                file_id = await to_bailian_data(
                    [FileSpec(path=self.file_name)],
                    api_key=api_key,
                )
                if file_id and isinstance(file_id, list) and len(file_id) > 0:
                    self.file_id = file_id[0]

            except AgenticRLError:
                # Keep the specific classification (code/solution/allow_retry)
                raise
            except Exception as e:
                raise OSSUploadError(
                    "Failed to upload datasets",
                    error_code=2061,
                ) from e

        return self.file_id


def _normalize_file_param(
    value: Optional[Union[List[str], str]],
) -> List[str]:
    """Normalize a dataset file parameter to a list of paths.

    ``None`` (the default) becomes an empty list instead of ``[None]``,
    a single string becomes a one-element list, and any other iterable
    is converted to a list. Runtime type checks use builtin types --
    ``typing`` aliases are annotations, not classes to test against.
    """
    if value is None:
        return []
    if isinstance(value, str):
        return [value]
    return list(value)


class Datasets(BaseModel):
    name: str = None
    datasets: List[Dataset] = None

    @classmethod
    async def upload_datasets(
        cls,
        training_files: Union[List[str], str] = None,
        validation_files: Union[List[str], str] = None,
        api_key: Optional[str] = None,
    ) -> Tuple[Optional[List[str]], Optional[List[str]]]:
        training_files = _normalize_file_param(training_files)
        validation_files = _normalize_file_param(validation_files)

        training_filespecs = [FileSpec(path=f) for f in training_files]
        validation_filespecs = [FileSpec(path=f) for f in validation_files]

        uploaded_training_ids = None
        uploaded_validation_ids = None
        try:
            if training_files:
                uploaded_training_ids = await to_bailian_data(
                    training_filespecs,
                    api_key=api_key,
                )
            if validation_files:
                uploaded_validation_ids = await to_bailian_data(
                    validation_filespecs,
                    api_key=api_key,
                )

        except AgenticRLError:
            # Keep the specific classification (code/solution/allow_retry)
            raise
        except Exception as e:
            raise OSSUploadError(
                "Failed to upload datasets",
                error_code=2062,
            ) from e

        return uploaded_training_ids, uploaded_validation_ids


class TrainingDataset(Dataset):
    type: DatasetsType = DatasetsType.TRAINING


class ValidationDataset(Dataset):
    type: DatasetsType = DatasetsType.VALIDATION


class FoundationModel(BaseModel):
    model_config = ConfigDict(extra="forbid")

    name: str = None


class Training(BaseModel):
    model_config = ConfigDict(extra="forbid")

    type: TrainingType = TrainingType.TRAINING_TYPE
    hyper_parameters: Dict[str, Any] = None
    resources: Dict[str, Any] = None

    @field_validator("hyper_parameters", "resources", mode="before")
    @classmethod
    def to_dict_values(cls, v: Dict) -> Dict[str, str]:
        """Convert all values in the dict to strings."""
        if v is None:
            return None
        return dict(v.items())


class Observability(BaseModel):
    ...


class Models(BaseModel):
    @classmethod
    def load_from_dict(cls, data: dict, **kwargs) -> Self:
        """Create an instance directly from a dictionary. Keys must match
        constructor parameters."""
        try:
            data.update(kwargs)
            return cls(**data)
        except Exception as e:
            raise IOErrorWithCode(
                "Failed to load from dict",
                error_code=1002,
            ) from e

    @classmethod
    def load_from_yaml(cls, file_path: str, **kwargs) -> Self:
        """Load a YAML file and create an instance."""
        try:
            check_file(file_path)
            with open(file_path, "r", encoding="utf-8") as f:
                d = yaml.load(f.read(), Loader=yaml.SafeLoader)
                d.update(kwargs)
            logger.info(f"Loaded from YAML: {file_path}")
        except Exception as e:
            raise IOErrorWithCode(
                f"Failed to load YAML file: {file_path}",
                error_code=1001,
                path=file_path,
            ) from e

        return cls.load_from_dict(d)

    def to_yaml(self, file_path: str, overwrite: bool = True) -> None:
        path = Path(file_path)
        if path.exists() and not overwrite:
            raise FileExistsError(
                f"File already exists: {file_path}, use overwrite=True to "
                f"force overwrite",
            )

        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            model_dict = self.model_dump(mode="json")
            # Remove keys whose value is None or empty string for a cleaner
            # YAML output
            model_dict = deep_remove_none(model_dict)
            logger.debug(
                f"The struct of Models class: "
                f""
                f"{model_dict if LOG_LEVEL == 'DEBUG' else deep_mask(model_dict)}",  # noqa: E501
            )

            with open(path, "w", encoding="utf-8") as f:
                yaml.safe_dump(
                    model_dict,
                    f,
                    encoding="utf-8",
                    allow_unicode=True,
                    sort_keys=False,
                )
        except Exception as e:
            raise IOErrorWithCode(
                "Failed to write file",
                error_code=1003,
            ) from e


class FunctionComponentModel(BaseModel):
    """Model representing function component configuration and operations."""

    model_config = ConfigDict(extra="forbid")

    zipdir: str = Field(
        default="./",
        description="Local directory path containing function code",
    )
    classpath: Optional[str] = Field(
        default="",
        description="Entrypoint class path for the function",
    )

    filepath: str = Field(
        default="",
        description="Main Python filepath containing function logic",
    )
    classname: str = Field(
        default="",
        description="Entrypoint class name for the function",
    )

    requirements_path: Optional[str] = Field(
        default=FC_REQUIREMENTS_FILE,
        description="Specify Python dependencies",
    )
    extra_files: Optional[List[str]] = Field(
        default=[],
        description="Additional deployment files required for function "
        "execution",
    )

    oss_id: Optional[str] = Field(
        default=None,
        description="Unique identifier for OSS storage resource",
    )
    oss_signed_url: Optional[str] = Field(
        default=None,
        description="Pre-signed URL for OSS bucket access",
    )

    def generate_id(self, func_type: FunctionType) -> str:
        """Generate unique OSS resource identifier."""
        oss_id = generate_random_id(func_type.value)
        self.oss_id = oss_id
        logger.debug(
            f"Generated OSS ID | Type: {func_type.name}, ID: {oss_id}",
        )
        return oss_id

    async def get_oss(
        self,
        oss_id: Optional[str] = None,
        api_key: Optional[str] = None,
    ) -> str:
        """Retrieve OSS signed URL for deployment package."""
        try:
            if oss_id:
                self.oss_id = oss_id

            result = await client_fc(
                resolve_fc_api_key(api_key),
                FC_UPLOAD_OSS_API,
                {"unique_key": self.oss_id},
            )
            self.oss_signed_url = result.get("output", {}).get("url", "")
            if not self.oss_signed_url:
                raise OSSConnectionError(
                    f"Empty OSS URL received: {result}",
                    error_code=2001,
                )

            logger.debug(
                f"Obtained OSS signed URL | ID: {self.oss_id}, "
                f"URL: {self.oss_signed_url}",
            )
            return self.oss_signed_url

        except OSSConnectionError:
            raise
        except Exception as e:
            raise OSSConnectionError(
                "Failed to obtain OSS URL",
                error_code=2002,
            ) from e

    async def create_layer(
        self,
        name: str = FC_LAYER_NAME,
        requirements_file: str = FC_REQUIREMENTS_FILE,
        api_key: Optional[str] = None,
        # oss_signed_url: str = None,
    ) -> str:
        """Retrieve OSS signed URL for deployment package."""
        layer_code = None
        layer_name = None
        try:
            # Validate requirements file if provided
            layer_name = name + "-" + generate_random_id()[:8]
            requirements = None
            if requirements_file and requirements_file.strip():
                req_path = os.path.join(self.zipdir, requirements_file)
                check_file(req_path)
                logger.debug(f"Found requirements file: {req_path}")
                with open(req_path, "r", encoding="utf-8") as f:
                    requirements = f.read()
            # oss_signed_url = oss_signed_url or self.oss_signed_url

            result = await client_fc(
                resolve_fc_api_key(api_key),
                FC_LAYER_CREATE_API,
                {
                    "layer_name": layer_name,
                    "requirements_content": requirements,
                    # "signed_url": oss_signed_url,
                },
            )
            if _fc_response_rejected(result):
                raise FunctionLayerError(
                    f"create rejected by server | {deep_mask(result)}",
                    layer_name=layer_name,
                    request_id=result.get("request_id"),
                    body=result,
                    allow_retry=False,
                    solution=_LAYER_CREATE_REJECTED_SOLUTION,
                )

            layer_code = (result.get("output") or {}).get("layer_code", "")
            if not layer_code:
                raise FunctionLayerError(
                    f"Empty layer code received: {deep_mask(result)}",
                    error_code=2013,
                    layer_name=layer_name,
                    request_id=result.get("request_id"),
                    body=result,
                    allow_retry=False,
                    solution=_LAYER_CREATE_REJECTED_SOLUTION,
                )
            logger.debug(
                f"Create function layer | layer-name: {layer_name} | "
                f"layer_code: {layer_code}",
            )

        except FunctionLayerError:
            raise
        except (InputError, OSError) as e:
            raise FunctionLayerError(
                f"create input error | {e}",
                error_code=2013,
                layer_name=layer_name,
                allow_retry=False,
                solution=_LAYER_CREATE_LOCAL_SOLUTION,
            ) from e
        except Exception as e:
            raise FunctionLayerError(
                f"create error | {e}",
                error_code=2013,
                layer_name=layer_name,
                allow_retry=True,
                solution=_LAYER_CREATE_TRANSIENT_SOLUTION,
            ) from e

        return layer_code

    async def to_oss(
        self,
        func_type: FunctionType,
        signed_url: Optional[str] = None,
    ) -> None:
        """Upload function package to OSS storage."""
        url = signed_url or self.oss_signed_url

        try:
            # Create deploy files
            create_deployment_files(
                functype=func_type,
                dirpath=self.zipdir,
                filepath=self.filepath,
                classname=self.classname,
                requirements_path=self.requirements_path,
            )

            with tempfile.NamedTemporaryFile(
                suffix=".zip",
                delete=False,
            ) as tmp:
                zip_dir(
                    output_zip=tmp.name,
                    dirpath=self.zipdir,
                    extra_files=self.extra_files,
                    rw_type="w",
                )

                await upload_zip_to_oss_and_by_signed_url(url, tmp.name)
                logger.debug(
                    f"Package uploaded | Size: {os.path.getsize(tmp.name)} "
                    f"bytes, Files: "
                    f"{len(self.extra_files) + 1 if self.extra_files else 1}",
                )

                self.clean_temp_files(tmp.name)

        except Exception as e:
            raise OSSUploadError(
                "Package upload failed",
                error_code=2003,
                endpoint=url or "",
            ) from e

        return

    async def get_layer(
        self,
        layer_code: str,
        api_key: Optional[str] = None,
    ) -> str:
        """Wait for an FC layer build to finish and return its final status.

        Raises FunctionLayerError when the layer fails to build, when the
        status endpoint returns an unusable response, or when the build does
        not finish within ``FC_LAYER_STATUS_TIMEOUT`` seconds.
        """
        loop = asyncio.get_running_loop()
        deadline = loop.time() + FC_LAYER_STATUS_TIMEOUT
        attempt = 0
        status = ""

        while loop.time() < deadline:
            attempt += 1
            try:
                result = await client_fc(
                    resolve_fc_api_key(api_key),
                    FC_LAYER_QUERY_API,
                    {
                        "layer_code": layer_code,
                    },
                    "GET",
                )
            except Exception as e:
                raise FunctionLayerError(
                    f"status query error | layer_code: {layer_code} | {e}",
                    error_code=2014,
                    layer_code=layer_code,
                    allow_retry=True,
                    solution=_LAYER_STATUS_QUERY_SOLUTION,
                ) from e

            if _fc_response_rejected(result):
                raise FunctionLayerError(
                    f"status query rejected by server | layer_code: "
                    f"{layer_code} | {deep_mask(result)}",
                    error_code=2016,
                    layer_code=layer_code,
                    request_id=result.get("request_id"),
                    body=result,
                    allow_retry=False,
                    solution=_LAYER_STATUS_REJECTED_SOLUTION,
                )

            status = (result.get("output") or {}).get("status", "")

            if status == "SUCCESS":
                logger.debug(
                    f"Load function layer | layer_code: {layer_code} | "
                    f"Status: {status}",
                )
                return status

            if status == "FAILED":
                raise FunctionLayerError(
                    f"build reported FAILED | layer_code: "
                    f"{layer_code} | {result}",
                    error_code=2015,
                    layer_code=layer_code,
                    request_id=result.get("request_id"),
                    body=result,
                    allow_retry=False,
                    solution=_LAYER_BUILD_FAILED_SOLUTION,
                )

            if not status:
                raise FunctionLayerError(
                    f"status query returned no status | layer_code: "
                    f"{layer_code} | {result}",
                    error_code=2016,
                    layer_code=layer_code,
                    request_id=result.get("request_id"),
                    body=result,
                    allow_retry=True,
                    solution=_LAYER_STATUS_MISSING_SOLUTION,
                )

            if attempt == 1:
                logger.info(
                    f"Waiting for function layer build | layer_code: "
                    f"{layer_code} | Status: {status} | Timeout: "
                    f"{FC_LAYER_STATUS_TIMEOUT}s",
                )
            else:
                logger.debug(
                    f"Load function layer({attempt}) | layer_code:"
                    f" {layer_code} | Status: {status}",
                )

            await asyncio.sleep(
                min(FC_LAYER_STATUS_INTERVAL, deadline - loop.time()),
            )

        raise FunctionLayerError(
            f"build timed out after {FC_LAYER_STATUS_TIMEOUT}s | "
            f"layer_code: {layer_code} | Last status: {status} | Raise "
            f"FC_LAYER_STATUS_TIMEOUT if the build needs longer",
            error_code=2017,
            layer_code=layer_code,
            allow_retry=True,
            solution=_LAYER_BUILD_TIMEOUT_SOLUTION,
        )

    def clean_temp_files(self, tmp_path: str) -> None:
        """Cleanup temporary deployment files."""
        try:
            for f in [tmp_path]:
                if os.path.exists(f):
                    if os.path.isfile(f):
                        os.remove(f)
                    else:
                        shutil.rmtree(f)
        except Exception as e:
            logger.warning(f"Temp file cleanup failed: {str(e)}")

    def split_classpath(self):
        self.filepath, self.classname = get_filepath_classname(self.classpath)

    def get_sub_function_weights(self):
        if not self.filepath and self.classpath:
            self.split_classpath()
        return get_weights_from_file(self.filepath, self.classname)


class FunctionComponentRuntime(BaseModel):
    """Runtime configuration for a function component"""

    model_config = ConfigDict(extra="forbid")

    layer_code: Optional[str] = None
    """Code of function layer"""

    cpu: Optional[float] = None
    """Number of CPU cores allocated (in vCPU units)"""

    memory_size: Optional[int] = None
    """Memory allocation size (in MB)"""

    disk_size: Optional[int] = None
    """Disk storage capacity (in MB)"""

    concurrency: Optional[int] = None
    """Maximum number of concurrent executions per instance (unitless count)"""

    capacity: Optional[int] = None
    """Current number of active instances (unitless count)"""

    max_capacity: Optional[int] = None
    """Maximum allowed instances for scaling (unitless count)"""

    min_capacity: Optional[int] = None
    """Minimum required instances for scaling (unitless count)"""

    memory_scale_threshold: Optional[float] = None
    """Memory utilization percentage threshold for scaling (0-100%)"""

    concurrency_scale_threshold: Optional[float] = None
    """Concurrency utilization percentage threshold for scaling (0-100%)"""

    enable_vpc_config: Optional[bool] = None
    """Flag indicating if VPC configuration is enabled (boolean)"""

    security_group_id: Optional[str] = None
    """ID of the security group (string identifier)"""

    switch_ids: Optional[List[str]] = None
    """List of network switch IDs (string identifiers)"""

    vpc_id: Optional[str] = None
    """Virtual Private Cloud ID (string identifier)"""

    vpc_role: Optional[str] = None
    """IAM role for VPC access (string identifier)"""

    enable_log: Optional[bool] = None
    """Flag indicating if logging is enabled (boolean)"""

    env: Optional[Dict[str, Any]] = None
    """
    Environment variables for the function runtime environment.

    Key-value pairs where:
    - Key: Environment variable name (string)
    - Value: Environment variable value (any serializable type)

    Example:
        {
            "ENABLE_TRAJECTORY": True
        }

    Best Practices:
    1. Use UPPER_SNAKE_CASE for variable names
    2. Keep values as strings when possible for maximum compatibility
    3. Avoid storing sensitive secrets directly - use secret management systems
    """


class AgenticRLFunctionComponent(Models, BaseModel):
    """Main class managing function component lifecycle operations."""

    type: FunctionType = Field(
        default=FunctionType.ROLLOUT,
        description="Type of function component",
    )
    name: Optional[str] = Field(default=None, description="Function name")
    timeout: Optional[int] = Field(
        default=None,
        description="Function timeout",
    )

    # for register
    fcmodel: Optional[FunctionComponentModel] = Field(
        default_factory=FunctionComponentModel,
        description="Function component model",
    )
    # for load
    runtime: Optional[FunctionComponentRuntime] = Field(
        default=None,
        description="Function component runtime",
    )

    entity_id: Optional[str] = Field(
        default=None,
        description="System-generated registration identifier",
    )
    instance_id: Optional[str] = Field(
        default=None,
        description="Deployed instance identifier",
    )
    instance_status: Optional[int] = Field(
        default=-1,
        description="Current instance state (-1=Unknown, 0=Initialized, "
        "1=Deploying, 2=Active)",
    )
    instance_url: Optional[str] = Field(
        default=None,
        description="Endpoint URL for deployed instance",
    )
    instance_token: Optional[str] = Field(
        default=None,
        description="Authentication token for instance access",
    )

    model_config = ConfigDict(extra="forbid")

    # pylint: disable=too-many-branches
    async def register(
        self,
        oss_id: Optional[str] = None,
        oss_url: Optional[str] = None,
        api_key: Optional[str] = None,
    ) -> ResponseFC:
        """Register function in the deployment system."""
        try:
            # Handle OSS configuration
            if oss_id and oss_url:
                self.fcmodel.oss_id = oss_id
                self.fcmodel.oss_signed_url = oss_url
            else:
                self.fcmodel.generate_id(self.type)
                await self.fcmodel.get_oss(api_key=api_key)

            # Split: classpath to filepath & classname
            if self.fcmodel.classpath:
                self.fcmodel.split_classpath()

            # Upload
            await self.fcmodel.to_oss(
                func_type=self.type,
                signed_url=self.fcmodel.oss_signed_url,
            )

            # Create function layer
            if FC_LAYER_USED:
                if self.runtime is None:
                    self.runtime = FunctionComponentRuntime()
                self.runtime.layer_code = await self.fcmodel.create_layer(
                    api_key=api_key,
                )

        except FunctionLayerError as e:
            root = e
            while root.__cause__:
                root = root.__cause__
            return ResponseFC(
                status=Status(
                    task=StatusType.FAILED,
                    name="DeploymentError",
                    code=524,
                    message=f"Function layer deployment failed: {root}",
                ),
                output={},
                request_id=e.request_id,
                body=e.body,
            )
        except Exception as e:
            root = e
            while root.__cause__:
                root = root.__cause__
            return ResponseFC(
                status=Status(
                    task=StatusType.FAILED,
                    name="DeploymentError",
                    code=525,
                    message=f"Function deployment failed: {root}",
                ),
                output={},
            )

        try:
            # Register
            request = RequestFC(
                unique_key=self.fcmodel.oss_id,
                name=self.fcmodel.filepath,
                func=self.fcmodel.classname,
                code_url=self.fcmodel.oss_signed_url,
            )

            if self.type == FunctionType.ROLLOUT:
                endpoint = FC_REGISTER_ROLLOUT_API
            elif self.type == FunctionType.REWARD:
                endpoint = FC_REGISTER_REWARD_API
            elif self.type == FunctionType.GROUP_REWARD:
                endpoint = FC_REGISTER_GROUP_REWARD_API
            else:
                raise RegistrationError(
                    f"Not exist type: {self.type.name}",
                    error_code=2011,
                )

            result = await client_fc(
                resolve_fc_api_key(api_key),
                endpoint,
                request.model_dump(),
            )
            func_type_id = get_func_type_id(self.type)
            self.entity_id = result.get("output", {}).get(func_type_id, "")

            if not self.entity_id:
                raise RegistrationError(
                    f"Empty entity ID received: {result}",
                    error_code=2012,
                )

            logger.info(
                f"Function registered | Type: {self.type.name}, "
                f"ID: {self.entity_id}, OSS: {self.fcmodel.oss_id}",
            )

            return ResponseFC(
                status=Status(
                    task=StatusType.SUCCEEDED,
                    name="FunctionRegistered",
                    code=200,
                    message=f"{self.type.name} function registered "
                    f"successfully",
                ),
                output={"entity_id": self.entity_id},
            )

        except Exception as e:
            root = e
            while root.__cause__:
                root = root.__cause__
            return ResponseFC(
                status=Status(
                    task=StatusType.FAILED,
                    name="DeploymentError",
                    code=521,
                    message=f"Full deployment failed: {root}",
                ),
                output={},
            )

    async def load(
        self,
        entity_id: Optional[str] = None,
        runtime: Optional[FunctionComponentRuntime] = None,
        warmup: bool = False,
        api_key: Optional[str] = None,
    ) -> ResponseFC:
        """Load and initialize a registered function instance."""
        runtime_obj = runtime or self.runtime
        target_entity_id = entity_id or self.entity_id
        layer_code = runtime_obj.layer_code if runtime_obj else None

        try:
            if not target_entity_id:
                raise ValueErrorWithCode(
                    "No valid registration ID provided",
                    error_code=2021,
                )

            if FC_LAYER_USED:
                if layer_code is None:
                    raise ValueErrorWithCode(
                        "layer_code is required when FC_LAYER_USED is "
                        "enabled: pass a runtime carrying layer_code, or "
                        "set FC_LAYER_USED=false",
                        error_code=2022,
                    )
                await self.fcmodel.get_layer(
                    layer_code=layer_code,
                    api_key=api_key,
                )

            # Load function instance
            runtime_dict = (
                deep_remove_none({**runtime_obj.model_dump()})
                if runtime_obj
                else {}
            )
            job_id = generate_random_id()
            url = f"{FC_LOAD_API}/jobId-{job_id}/{target_entity_id}"

            result = await client_fc(
                resolve_fc_api_key(api_key),
                url,
                runtime_dict,
            )
            if _fc_response_rejected(result):
                raise FunctionLoadError(
                    f"load rejected by server | {deep_mask(result)}",
                    error_code=2023,
                    entity_id=target_entity_id,
                    request_id=result.get("request_id"),
                    body=result,
                    allow_retry=False,
                )

            output = result.get("output") or {}
            self.instance_id = output.get("instanceId", "")
            if not self.instance_id:
                raise FunctionLoadError(
                    f"Empty instance ID received: {deep_mask(result)}",
                    error_code=2023,
                    entity_id=target_entity_id,
                    request_id=result.get("request_id"),
                    body=result,
                )

            self.instance_url = output.get("trigger_url", "")
            self.instance_token = output.get("trigger_token", "")
            if (not self.instance_url) or (not self.instance_token):
                raise FunctionLoadError(
                    "Missing instance URL or token",
                    error_code=2024,
                    entity_id=target_entity_id,
                    request_id=result.get("request_id"),
                    body=result,
                )

            logger.info(
                f"Instance initialized | EntityID: {target_entity_id}, "
                f"InstanceID: {self.instance_id}, "
                f"Endpoint: {self.instance_url}, "
                f"Response: "
                f"{result if LOG_LEVEL == 'DEBUG' else deep_mask(result)}",
            )

        except FunctionLayerError as e:
            logger.warning(
                f"Instance initialization blocked by function layer | "
                f"EntityID: {target_entity_id}, LayerCode: {layer_code}, "
                f"Error: {str(e)}",
            )
            return ResponseFC(
                status=Status(
                    task=StatusType.FAILED,
                    name="FunctionLayerError",
                    code=526,
                    message=(
                        f"Function layer not ready | EntityID: "
                        f"{target_entity_id}, LayerCode: {layer_code}, "
                        f"Error: {str(e)}"
                    ),
                ),
                output={},
                request_id=e.request_id,
                body=e.body,
            )

        except Exception as e:
            logger.warning(
                f"Instance initialization failed | EntityID:"
                f" {target_entity_id}, LayerCode: {layer_code}, "
                f"Error: {str(e)}",
            )
            return ResponseFC(
                status=Status(
                    task=StatusType.FAILED,
                    name="FunctionLoadError",
                    code=522,
                    message=(
                        f"Instance initialization failed | EntityID: "
                        f"{target_entity_id}, LayerCode: {layer_code}, "
                        f"Error: {str(e)}"
                    ),
                ),
                output={},
                request_id=getattr(e, "request_id", None),
                body=getattr(e, "body", None),
            )

        # Perform instance warmup if requested
        if warmup:
            try:
                if not self.instance_url.startswith(("http://", "https://")):
                    raise ValueErrorWithCode(
                        "Invalid instance URL format",
                        error_code=2025,
                    )

                url = f"{self.instance_url.rstrip('/')}/health"
                result = await client_fc(
                    self.instance_token,
                    url,
                    {},
                    "GET",
                )
                status = result.get("status", str(StatusType.UNKNOWN))
                if status != StatusType.HEALTH:
                    raise InstanceWarmupError(
                        f"Health check failed: {result}",
                        error_code=2026,
                        instance_url=url,
                    )

                logger.info(
                    f"Instance warmup completed | Instance:"
                    f" {self.instance_id if self.instance_id else 'N/A'}",
                )

            except Exception as e:
                logger.debug(
                    f"Warmup failed | InstanceID: {self.instance_id}, "
                    f"Error: {str(e)}",
                )
                return ResponseFC(
                    status=Status(
                        task=StatusType.FAILED,
                        name="InstanceWarmupError",
                        code=511,
                        message=f"Instance warmup failed: {str(e)}",
                    ),
                    output={"instance_id": self.instance_id},
                )

        return ResponseFC(
            status=Status(
                task=StatusType.SUCCEEDED,
                name="InstanceReady",
                code=200,
                message="Function instance ready for requests",
            ),
            output={
                "instance_id": self.instance_id,
                "endpoint": self.instance_url,
                "status": 2,  # 2 = Active status
            },
        )

    @classmethod
    async def query(
        cls,
        instance_id: str,
        api_key: Optional[str] = None,
    ) -> ResponseFC:
        """Retrieve current status of a function instance."""
        try:
            if not instance_id:
                raise InputError(
                    "No instance ID available for query",
                    error_code=2031,
                )

            url = f"{FC_QUERY_API}/{instance_id}"
            result = await client_fc(resolve_fc_api_key(api_key), url, {})
            status = result.get("output", {}).get("status", -1)
            if status == -1:
                raise InstanceQueryError(
                    f"Invalid status received: {result}",
                    error_code=2032,
                )

            logger.debug(
                f"Status query completed | InstanceID: {instance_id} | "
                f"Status: {status}.",
            )

        except Exception as e:
            logger.debug(
                f"Status query failed | InstanceID: {instance_id}, "
                f"Error: {str(e)}",
            )
            return ResponseFC(
                status=Status(
                    task=StatusType.FAILED,
                    name="InstanceQueryError",
                    code=523,
                    message=f"Status query failed: {str(e)}",
                ),
                output={"instance_id": instance_id},
            )

        return ResponseFC(
            status=Status(
                task=StatusType.SUCCEEDED,
                name="InstanceStatus",
                code=200,
                message="Instance status retrieved",
            ),
            output=result,
        )

    @classmethod
    async def verify_function(
        cls,
        input_data: Union[RolloutInput, RewardInput, GroupRewardInput],
        instance_id: Optional[str] = None,
        instance_url: Optional[str] = None,
        instance_token: Optional[str] = None,
        api_key: Optional[str] = None,
    ) -> Dict:
        """Validate deployed function functionality."""
        try:
            # Get instance metadata
            if instance_id is None:
                raise ValueErrorWithCode(
                    "instance_id is required for verification",
                    error_code=2041,
                )
            result = await cls.query(instance_id, api_key=api_key)
            if result.status.task != StatusType.SUCCEEDED:
                raise InstanceQueryError(
                    "Status query failed",
                    error_code=2042,
                )
            instance_url = instance_url or result.output.get("output", {}).get(
                "trigger_url",
                "",
            )
            instance_token = instance_token or result.output.get(
                "output",
                {},
            ).get("trigger_token", "")
            if (not instance_url) or (not instance_token):
                raise OutputError(
                    "No instance url/token provided",
                    error_code=2043,
                )

            input_data_dict = input_data.model_dump(
                mode="json",
                exclude_none=True,
            )
            if (
                "model_resource" in input_data_dict
                and "api_key" in input_data_dict["model_resource"]
            ):
                input_data_dict["model_resource"][
                    "api_key"
                ] = input_data.model_resource.api_key.get_secret_value()

            # Execute test request
            response = await client_fc(
                instance_token,
                f"{instance_url}/api/v1",
                input_data_dict,
            )

            # Validate response format
            if isinstance(input_data, RolloutInput):
                validator = RolloutOutput
            elif isinstance(input_data, RewardInput):
                validator = RewardOutput
            elif isinstance(input_data, GroupRewardInput):
                validator = GroupRewardOutput
            else:
                raise ValidationError(
                    "Unsupported input type",
                    error_code=2044,
                )

        except Exception as e:
            raise ValidationError(
                "Function verification failed",
                error_code=2045,
            ) from e

        try:
            resp_status = response.get("status", {})
            if isinstance(resp_status, dict):
                status_code = resp_status.get("code", 200)
                if status_code != 200:
                    error_msg = resp_status.get("message", "Unknown error")
                    fc_message = response.get("Message", "")
                    if fc_message:
                        match = re.search(
                            r"(\w+(?:Error|Exception|Warning): .+)",
                            fc_message,
                        )
                        if match:
                            error_msg = match.group(1)
                    raise ValidationError(
                        error_msg,
                        error_code=2046,
                    )

            validated = validator.model_validate(response)

            logger.info(
                f"Validation succeeded | Input: "
                f"{input_data_dict if LOG_LEVEL == 'DEBUG' else deep_mask(input_data_dict)}, "  # noqa: E501  # pylint: disable=line-too-long
                f"Output: {validated.model_dump_json()}, "
                f"Status: {response.get('status', StatusType.SUCCEEDED)}",
            )
            return validated.model_dump()

        except Exception as e:
            raise ValidationError(
                "Function output validation failed",
                error_code=2047,
            ) from e

    @staticmethod
    def _extract_log_page(
        result: Dict[str, Any],
    ) -> Tuple[List[str], Optional[int]]:
        """Extract log messages and total count from a log query response.

        Two payload shapes are supported. The DashScope gateway returns
        snake_case keys under "output"::

            {
              "request_id": "...",
              "output": {
                "page_number": 1,
                "page_size": 100,
                "total_count": 86,
                "log_entries": [
                  {"instance_id": "...", "message": "...",
                   "timestamp": 1699051200}
                ]
              }
            }

        while the backend service returns camelCase keys under "data"::

            {
              "success": true,
              "data": {
                "pageNumber": 1,
                "pageSize": 50,
                "totalCount": 128,
                "logEntries": [
                  {"instanceId": "...", "message": "...",
                   "timestamp": 1699051200}
                ]
              }
            }

        Only the "message" field of each log entry is kept; other fields
        are ignored.
        """
        data = result.get("output")
        if not isinstance(data, Dict):
            data = result.get("data")
        if not isinstance(data, Dict):
            return [], None

        entries = data.get("log_entries") or data.get("logEntries") or []
        logs = [
            entry.get("message", "") if isinstance(entry, Dict) else str(entry)
            for entry in entries
        ]

        total = data.get("total_count")
        if total is None:
            total = data.get("totalCount")
        if not isinstance(total, int):
            total = None

        return logs, total

    @classmethod
    async def query_function_instance_logs(
        cls,
        function_instance_id: str,
        page_number: int = 1,
        page_size: int = 100,
        start_time: Optional[int] = None,
        end_time: Optional[int] = None,
        keywords: Optional[List[str]] = None,
        api_key: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Query logs of a function (faas) instance (single page).

        Args:
            function_instance_id: Target function instance ID.
            page_number: Page number, starting from 1.
            page_size: Number of log entries per page.
            start_time: Optional start time filter (in seconds).
            end_time: Optional end time filter (in seconds).
            keywords: Optional keyword filters for log messages.

        Returns:
            Raw response dict of the log query API.
        """
        if not function_instance_id:
            raise InputError(
                "No function instance ID available for log query",
                error_code=2071,
            )

        url = f"{FC_QUERY_LOG_API}/{function_instance_id}"
        request_data: Dict[str, Any] = {
            "pageNumber": page_number,
            "pageSize": page_size,
        }
        if start_time is not None:
            request_data["startTime"] = start_time
        if end_time is not None:
            request_data["endTime"] = end_time
        if keywords:
            request_data["keywords"] = keywords

        result = await client_fc(
            resolve_fc_api_key(api_key),
            url,
            request_data,
        )
        status = result.get("status", {})
        if isinstance(status, Dict) and status.get("code", 200) != 200:
            raise InstanceQueryError(
                f"Log query failed: {result}",
                error_code=2072,
                instance_id=function_instance_id,
            )
        if result.get("success") is False:
            raise InstanceQueryError(
                f"Log query failed: {result.get('message') or result}",
                error_code=2073,
                instance_id=function_instance_id,
            )

        logger.debug(
            f"Log query completed | FunctionInstanceID: "
            f"{function_instance_id} | "
            f"Page: {page_number} | Size: {page_size}",
        )
        return result

    @classmethod
    async def query_all_function_instance_logs(
        cls,
        function_instance_id: str,
        page_size: int = 100,
        start_time: Optional[int] = None,
        end_time: Optional[int] = None,
        keywords: Optional[List[str]] = None,
        max_pages: int = 100,
        api_key: Optional[str] = None,
    ) -> List[str]:
        """Fetch all logs of a function (faas) instance with pagination.

        Iterates pages starting from page 1 until all entries are
        collected (based on the reported total count, an empty page, or
        a short page).

        Args:
            function_instance_id: Target function instance ID.
            page_size: Number of log entries per page.
            start_time: Optional start time filter (in seconds).
            end_time: Optional end time filter (in seconds).
            keywords: Optional keyword filters for log messages.
            max_pages: Safety limit on the number of pages to fetch.

        Returns:
            Aggregated list of log messages across all pages.
        """
        all_logs: List[str] = []
        page_number = 1
        while page_number <= max_pages:
            result = await cls.query_function_instance_logs(
                function_instance_id=function_instance_id,
                page_number=page_number,
                page_size=page_size,
                start_time=start_time,
                end_time=end_time,
                keywords=keywords,
                api_key=api_key,
            )
            logs, total = cls._extract_log_page(result)
            all_logs.extend(logs)

            if total is not None and len(all_logs) >= total:
                break
            if len(logs) < page_size:
                break
            page_number += 1

        logger.debug(
            f"All logs fetched | FunctionInstanceID: "
            f"{function_instance_id} | "
            f"Pages: {page_number} | Entries: {len(all_logs)}",
        )
        return all_logs

    @classmethod
    async def delete_function_instance(
        cls,
        function_instance_id: str,
        api_key: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Delete a function (faas) runtime instance.

        Args:
            function_instance_id: Target function instance ID.

        Returns:
            Raw response dict of the delete API, e.g.::

                {
                  "code": 0,
                  "message": "success",
                  "data": {
                    "status": "deleted",
                    "sandbox_code": "sandbox-xxx"
                  }
                }
        """
        if not function_instance_id:
            raise InputError(
                "No function instance ID available for deletion",
                error_code=2074,
            )

        url = f"{FC_DELETE_API}/{function_instance_id}"
        result = await client_fc(resolve_fc_api_key(api_key), url, {})
        status = result.get("status", {})
        if isinstance(status, Dict) and status.get("code", 200) != 200:
            raise InstanceQueryError(
                f"Function instance deletion failed: {result}",
                error_code=2075,
                instance_id=function_instance_id,
            )
        code = result.get("code")
        if result.get("success") is False or (
            code is not None and code not in (0, 200)
        ):
            raise InstanceQueryError(
                "Function instance deletion failed: "
                f"{result.get('message') or result}",
                error_code=2075,
                instance_id=function_instance_id,
            )

        data = result.get("data", {})
        status_value = data.get("status") if isinstance(data, Dict) else data
        logger.info(
            f"Function instance deleted | FunctionInstanceID: "
            f"{function_instance_id} | Status: {status_value}",
        )
        return result


class RolloutFunctionComponent(AgenticRLFunctionComponent):
    """Rollout function component with type fixed as ROLLOUT."""

    type: FunctionType = Field(
        default=FunctionType.ROLLOUT,
        description="Type of function component",
    )

    # PLACEHOLDER
    weight: Optional[float] = Field(
        default=None,
        description="[PLACEHOLDER] Function weight mapping. This field is "
        "currently not used by the system.",
    )
    reward_metric_weight: Optional[Dict[str, float]] = Field(
        default=None,
        description="[PLACEHOLDER] Reward metric weight mapping. This field "
        "is currently not used by the system.",
    )


class RewardFunctionComponent(AgenticRLFunctionComponent):
    """Reward function component with type fixed as REWARD."""

    type: FunctionType = Field(
        default=FunctionType.REWARD,
        description="Type of function component",
    )
    weight: Optional[float] = Field(
        default=None,
        description="Function weight",
    )
    reward_metric_weight: Optional[Dict[str, float]] = Field(
        default=None,
        description="Reward metric weight mapping",
    )

    async def register(
        self,
        oss_id: Optional[str] = None,
        oss_url: Optional[str] = None,
        api_key: Optional[str] = None,
    ) -> ResponseFC:
        if not self.reward_metric_weight:
            self.reward_metric_weight = self.fcmodel.get_sub_function_weights()
        result = await super().register(
            oss_id=oss_id,
            oss_url=oss_url,
            api_key=api_key,
        )
        return result


class GroupRewardFunctionComponent(AgenticRLFunctionComponent):
    """Group reward function component with type fixed as GROUP_REWARD."""

    type: FunctionType = Field(
        default=FunctionType.GROUP_REWARD,
        description="Type of function component",
    )
    weight: Optional[float] = Field(
        default=None,
        description="Function weight",
    )
    reward_metric_weight: Optional[Dict[str, float]] = Field(
        default=None,
        description="Reward metric weight mapping",
    )

    async def register(
        self,
        oss_id: Optional[str] = None,
        oss_url: Optional[str] = None,
        api_key: Optional[str] = None,
    ) -> ResponseFC:
        if not self.reward_metric_weight:
            self.reward_metric_weight = self.fcmodel.get_sub_function_weights()
        result = await super().register(
            oss_id=oss_id,
            oss_url=oss_url,
            api_key=api_key,
        )
        return result


_FUNCTYPE_CLASS_MAP = {
    FunctionType.ROLLOUT: RolloutFunctionComponent,
    FunctionType.REWARD: RewardFunctionComponent,
    FunctionType.GROUP_REWARD: GroupRewardFunctionComponent,
}


def _fc_discriminator(v: Any) -> str:
    if isinstance(v, dict):
        return v.get("type", "rollout")
    return getattr(v, "type", "rollout").value


FunctionComponentUnion = Annotated[
    Union[
        Annotated[RolloutFunctionComponent, Tag("rollout")],
        Annotated[RewardFunctionComponent, Tag("reward")],
        Annotated[GroupRewardFunctionComponent, Tag("group_reward")],
    ],
    Discriminator(_fc_discriminator),
]


class TuningModel(Models, BaseModel):
    """Core configuration model for managing model tuning tasks."""

    model_config = ConfigDict(extra="forbid")

    name: str = Field(default="agentic-rl", min_length=1, max_length=256)
    model: FoundationModel = FoundationModel()
    teacher_model: Optional[str] = None
    functions: List[FunctionComponentUnion] = Field(default_factory=list)
    datasets: List[Dataset] = Field(default_factory=list)
    training: Training = Training()
    observability: Optional[Observability] = Observability()

    # pylint: disable=too-many-branches
    async def register_functions(
        self,
        lazy_load: Optional[bool] = True,
        api_key: Optional[str] = None,
    ) -> tuple[
        List[str],
        List[str],
        List[str],
        List[str],
        List[str],
        List[str],
    ]:
        """Register function compute components (functions) for the tuning
        job."""
        entity_rollout_ids = []
        entity_reward_ids = []
        entity_group_reward_ids = []
        instance_rollout_ids = []
        instance_reward_ids = []
        instance_group_reward_ids = []

        try:
            for fc in self.functions:
                if fc.entity_id:
                    entity_id = fc.entity_id
                else:
                    reg_result = await fc.register(api_key=api_key)
                    if reg_result.status.success:
                        entity_id = reg_result.output.get("entity_id", "")
                        if not entity_id:
                            raise RegistrationError(
                                "Empty entity ID after registration",
                                error_code=2051,
                            )
                        logger.debug(
                            f"Registered new function component: "
                            f"Type={fc.type.value}, RegisterID={entity_id}",
                        )
                    else:
                        raise RegistrationError(
                            reg_result.status.message,
                            error_code=2052,
                            request_id=reg_result.request_id,
                            body=reg_result.body,
                        )

                if fc.type == FunctionType.ROLLOUT:
                    entity_rollout_ids.append(entity_id)
                elif fc.type == FunctionType.REWARD:
                    entity_reward_ids.append(entity_id)
                elif fc.type == FunctionType.GROUP_REWARD:
                    entity_group_reward_ids.append(entity_id)

                if not lazy_load:
                    load_result = await fc.load(
                        entity_id=entity_id,
                        api_key=api_key,
                    )
                    if load_result.status.success:
                        instance_id = load_result.output.get("instance_id", "")
                        if not instance_id:
                            raise FunctionLoadError(
                                "Empty instance ID after load",
                                error_code=2053,
                            )
                        logger.debug(
                            f"Loaded function component instance: "
                            f"RegisterID={entity_id}, InstanceID"
                            f"={instance_id}",
                        )
                        if fc.type == FunctionType.ROLLOUT:
                            instance_rollout_ids.append(instance_id)
                        elif fc.type == FunctionType.REWARD:
                            instance_reward_ids.append(instance_id)
                        elif fc.type == FunctionType.GROUP_REWARD:
                            instance_group_reward_ids.append(instance_id)
                    else:
                        raise FunctionLoadError(
                            f"Load failed: {load_result.status.message}",
                            error_code=2054,
                            entity_id=entity_id,
                            request_id=load_result.request_id,
                            body=load_result.body,
                        )

        except Exception as e:
            if hasattr(e, "error_code"):
                raise
            raise RegistrationError(
                "Function component registration failed",
                error_code=2055,
            ) from e

        return (
            entity_rollout_ids,
            entity_reward_ids,
            entity_group_reward_ids,
            instance_rollout_ids,
            instance_reward_ids,
            instance_group_reward_ids,
        )

    async def upload_datasets(
        self,
        training_files: Union[List[str], str] = None,
        validation_files: Union[List[str], str] = None,
        api_key: Optional[str] = None,
    ) -> tuple[List[str], List[str]]:
        """Register and validate training/validation datasets."""
        uploaded_training_ids = []
        uploaded_validation_ids = []
        # Normalize so that a single string path is not iterated
        # character by character and defaults do not produce [None].
        training_files = _normalize_file_param(training_files)
        validation_files = _normalize_file_param(validation_files)
        try:
            if training_files:
                self.datasets = []
                for f in training_files:
                    ds = Dataset(
                        type=DatasetsType.TRAINING,
                        data_source_type=DataSourceType.FILE_ID,
                        file_name=f,
                    )
                    self.datasets.append(ds)

                if validation_files:
                    for f in validation_files:
                        ds = Dataset(
                            type=DatasetsType.VALIDATION,
                            data_source_type=DataSourceType.FILE_ID,
                            file_name=f,
                        )
                        self.datasets.append(ds)

            # Perform dataset validation and upload
            for ds in self.datasets or []:
                ds_id = await ds.upload_dataset(api_key=api_key)
                if ds.type == DatasetsType.TRAINING and ds_id is not None:
                    uploaded_training_ids.append(ds_id)
                elif ds.type == DatasetsType.VALIDATION and ds_id is not None:
                    uploaded_validation_ids.append(ds_id)

            logger.info(
                f"Successfully datasets registration: "
                f"{len(uploaded_training_ids)} training, "
                f"{len(uploaded_validation_ids)} validation",
            )

        except AgenticRLError:
            # Keep the specific classification (code/solution/allow_retry)
            raise
        except Exception as e:
            raise OSSUploadError(
                "Dataset registration failed",
                error_code=2063,
            ) from e

        return uploaded_training_ids, uploaded_validation_ids

    def get_entity_ids(self, functype: FunctionType):
        ids = []
        for fc in self.functions:
            if functype == fc.type and fc.entity_id:
                ids.append(fc.entity_id)
        return ids

    def get_runtimes(self, functype: FunctionType):
        runtimes = []
        for fc in self.functions:
            if functype == fc.type and fc.runtime:
                runtimes.append(fc.runtime.model_dump())
        return runtimes

    def get_names(self, functype: FunctionType):
        """Get name values for function components of the given type."""
        names = []
        for fc in self.functions:
            if functype == fc.type:
                names.append(getattr(fc, "name", None))
        return names

    def set_names(self, functype: FunctionType):
        """Set name values for function components of the given type."""
        for fc in self.functions:
            if functype == fc.type and not fc.name:
                fc.name = "-".join((str(fc.type), generate_random_id()[:8]))
                logger.debug(
                    f"Generate a random name: {fc.name} for {functype}",
                )

    def get_weights(self, functype: FunctionType):
        """Get weight values for function components of the given type."""
        weights = []
        for fc in self.functions:
            if functype == fc.type:
                weights.append(getattr(fc, "weight", None))
        return weights

    def get_timeouts(self, functype: FunctionType):
        """Get timeout values for function components of the given type."""
        timeouts = []
        for fc in self.functions:
            if functype == fc.type:
                timeouts.append(getattr(fc, "timeout", None))
        return timeouts

    def get_reward_metric_weights(self, functype: FunctionType):
        """Get reward_metric_weight values for function components of the
        given type."""
        metric_weights = []
        for fc in self.functions:
            if functype == fc.type and functype == FunctionType.REWARD:
                metric_weights.append(
                    getattr(fc, "reward_metric_weight", None),
                )
        return metric_weights

    def combine_ids_runtimes(
        self,
        functype: FunctionType,
        ids: Union[List[str], str] = None,
        runtimes: Union[List[Dict[str, Any]], Dict[str, Any]] = None,
        id_str: str = None,
    ):
        if ids:
            ids = [ids] if isinstance(ids, str) else ids
        if runtimes:
            runtimes = [runtimes] if isinstance(runtimes, Dict) else runtimes
        function_ids = ids or self.get_entity_ids(functype)
        function_runtimes = runtimes or self.get_runtimes(functype) or []
        assert isinstance(
            function_runtimes,
            list,
        ), "function_runtimes must be a list"

        self.set_names(functype)
        function_names = self.get_names(functype)
        function_weights = self.get_weights(functype)
        function_timeouts = self.get_timeouts(functype)
        function_metric_weights = self.get_reward_metric_weights(functype)

        id_str = id_str or get_func_type_id(functype)
        functions = []
        for i in range(  # pylint: disable=consider-using-enumerate
            len(function_ids),
        ):
            function = {id_str: function_ids[i]}

            # Add name if present (for reward/group_reward types)
            if i < len(function_names) and function_names[i] is not None:
                function["name"] = function_names[i]

            # Add weight if present (for reward/group_reward types)
            if i < len(function_weights) and function_weights[i] is not None:
                function["weight"] = function_weights[i]

            # Add timeout if present (for reward/group_reward types)
            if i < len(function_timeouts) and function_timeouts[i] is not None:
                function["timeout"] = function_timeouts[i]

            # Add reward_metric_weight if present (for reward/group_reward
            # types)
            if (
                i < len(function_metric_weights)
                and function_metric_weights[i] is not None
            ):
                function["reward_metric_weight"] = function_metric_weights[i]

            # Merge runtime config
            if function_runtimes and i <= len(function_runtimes) - 1:
                runtime_config = function_runtimes[i].copy()
                if "env" in runtime_config and isinstance(
                    runtime_config["env"],
                    Dict,
                ):
                    for key, value in runtime_config["env"].items():
                        if isinstance(value, bool):
                            runtime_config["env"][key] = str(value).lower()

                function.update(runtime_config)

            functions.append(function)

        return functions

    def add_function_components(
        self,
        functype: FunctionType,
        classpaths: Optional[Union[List[str], str]] = None,
        entity_ids: Optional[
            Union[List[str], str]
        ] = None,  # Prefer entity_ids over classpaths when available
        runtimes: Optional[Union[List[Dict[str, Any]], Dict[str, Any]]] = None,
        names: Optional[Union[List[str], str]] = None,
        weights: Optional[Union[List[float], float]] = None,
        timeouts: Optional[Union[List[int], int]] = None,
        reward_metric_weights: Optional[
            Union[List[Dict[str, float]], Dict[str, float]]
        ] = None,
        workspace_dir: Optional[str] = "./",
    ):
        classpaths = (
            [classpaths] if isinstance(classpaths, str) else classpaths
        )
        entity_ids = (
            [entity_ids] if isinstance(entity_ids, str) else entity_ids
        )
        runtimes = [runtimes] if isinstance(runtimes, Dict) else runtimes
        names = [names] if isinstance(names, str) else names
        weights = [weights] if isinstance(weights, float) else weights
        timeouts = [timeouts] if isinstance(timeouts, int) else timeouts
        reward_metric_weights = (
            [reward_metric_weights]
            if isinstance(reward_metric_weights, Dict)
            else reward_metric_weights
        )

        len_classpaths = len(classpaths) if classpaths else 0
        len_entity_ids = len(entity_ids) if entity_ids else 0
        len_runtimes = len(runtimes) if runtimes else 0
        len_names = len(names) if names else 0
        len_weights = len(weights) if weights else 0
        len_timeouts = len(timeouts) if timeouts else 0
        len_reward_metric_weights = (
            len(reward_metric_weights) if reward_metric_weights else 0
        )

        if len_classpaths == 0 and len_entity_ids == 0:
            logger.warning(
                f"The inputs of classpaths and entity_ids for "
                f"{functype} are none.",
            )
            return []

        cls = _FUNCTYPE_CLASS_MAP.get(functype, AgenticRLFunctionComponent)

        if (
            len_entity_ids > 0
        ):  # Prefer entity_ids over classpaths when available
            assert entity_ids is not None
            for i in range(len_entity_ids):
                self.functions.append(
                    cls(
                        type=functype,
                        entity_id=entity_ids[i],
                        runtime=(
                            FunctionComponentRuntime(**runtimes[i])
                            if runtimes and i < len_runtimes
                            else None
                        ),
                        name=names[i] if names and i < len_names else None,
                        weight=(
                            weights[i] if weights and i < len_weights else None
                        ),
                        timeout=(
                            timeouts[i]
                            if timeouts and i < len_timeouts
                            else None
                        ),
                        reward_metric_weight=(
                            reward_metric_weights[i]
                            if reward_metric_weights
                            and i < len_reward_metric_weights
                            else None
                        ),
                    ),
                )
        else:
            assert classpaths is not None
            for i in range(len_classpaths):
                self.functions.append(
                    cls(
                        type=functype,
                        fcmodel=FunctionComponentModel(
                            zipdir=workspace_dir,
                            classpath=classpaths[i],
                        ),
                        runtime=(
                            FunctionComponentRuntime(**runtimes[i])
                            if runtimes and i < len_runtimes
                            else None
                        ),
                        name=names[i] if names and i < len_names else None,
                        weight=(
                            weights[i] if weights and i < len_weights else None
                        ),
                        timeout=(
                            timeouts[i]
                            if timeouts and i < len_timeouts
                            else None
                        ),
                        reward_metric_weight=(
                            reward_metric_weights[i]
                            if reward_metric_weights
                            and i < len_reward_metric_weights
                            else None
                        ),
                    ),
                )

        return self.functions

    def check_function_names(self) -> bool:
        """
        Check for duplicate function component names.

        Returns:
            True if all names are unique, False if duplicates found.
        """
        seen_names = {}
        duplicate_found = False

        for index, fc in enumerate(self.functions):
            if not hasattr(fc, "name"):
                logger.error(
                    f"Function component at index {index} is missing a "
                    f"'name' attribute",
                )
                duplicate_found = True
                continue

            name = fc.name
            if name in seen_names:
                logger.error(
                    f"Duplicate function name '{name}' found: "
                    f"Original at index {seen_names[name]}, duplicate at "
                    f"index {index}",
                )
                duplicate_found = True
            else:
                seen_names[name] = index

        if duplicate_found:
            logger.error(
                "Duplicate function names detected. All function names must "
                "be unique.",
            )
            return False

        logger.debug("All function names are unique.")
        return True


class AgenticRLTuning(Models, BaseModel):
    """Main interface class for model tuning operations."""

    tuning_id: Optional[str] = None
    tuning: TuningModel = TuningModel()
