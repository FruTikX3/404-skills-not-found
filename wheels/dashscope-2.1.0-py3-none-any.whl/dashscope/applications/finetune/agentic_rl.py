# -*- coding: utf-8 -*-
# Copyright (c) Alibaba, Inc. and its affiliates.
"""The agentic-RL workflow driver, owned by the 2.0 package.

``Client(...).rl`` is built on this class. The 1.x job-management surface
-- ``FineTunes`` / ``Deployments`` and the ``FineTune`` dataclasses --
stays at ``dashscope.legacy_1x.finetune``; the thin subclass there re-adds
those five verbs and swaps ``SubmitResult`` back for ``FineTune``.

Two deliberate differences from the 1.x class this was split out of:

- ``submit_job`` returns ``SubmitResult`` instead of a 1.x ``FineTune``
  dataclass, and posts through ``dashscope.applications.finetune._submit`` instead
  of inheriting ``CreateMixin``.
- The api key is the constructor argument or ``DASHSCOPE_API_KEY``, never
  the ``dashscope.api_key`` root global. ``set_api_key`` already writes
  the argument into that env var and raises when it cannot, so resolution
  here is unambiguous -- reading the root global could silently disagree
  with the key this instance was built with.
"""

from __future__ import annotations

import time
from typing import Union, List, Optional, ClassVar, Dict, Any
from typing_extensions import Self

from dashscope.applications.finetune import _submit
from dashscope.applications.finetune.reinforcement import (
    AgenticRLFunctionComponent,
    RolloutFunctionComponent,
    RewardFunctionComponent,
    Dataset,
    TrainingDataset,
    ValidationDataset,
)
from dashscope.applications.finetune.reinforcement import (
    AgenticRLTuning,
    TuningModel,
)
from dashscope.applications.finetune.reinforcement import (
    DASHSCOPE_HTTP_BASE_URL,
)
from dashscope.applications.finetune.reinforcement import (
    FunctionType,
    DatasetsType,
    TrainingType,
)
from dashscope.applications.finetune.reinforcement import (
    RewardInput,
    RolloutInput,
    GroupRewardInput,
)
from dashscope.applications.finetune.reinforcement import logger
from dashscope.applications.finetune.reinforcement import (
    set_api_key,
    generate_random_id,
    get_func_type_id,
    deep_remove_none,
    resolve_api_key,
)
from dashscope.applications.finetune.reinforcement.common.errors import (
    RegistrationError,
    ValidationError,
    InstanceQueryError,
    RuntimeErrorWithCode,
    ValueErrorWithCode,
    DatasetsError,
)

__all__ = ["AgenticRL", "SubmitOutput", "SubmitResult"]


def _inner_code(exc: Exception) -> str:
    return getattr(exc, "code", None) or type(exc).__name__


class SubmitOutput:
    """The ``output`` payload nested in a submit response.

    A plain attribute container on purpose: the server's job payload is
    open-ended, and ``reinforcement_learning._to_job`` flattens it with
    ``vars(output)``, which needs a ``__dict__``.
    """

    def __init__(self, **kwargs: Any):
        self.__dict__.update(kwargs)

    def __repr__(self) -> str:
        return f"{type(self).__name__}({self.__dict__!r})"


class SubmitResult:
    """The envelope ``AgenticRL.submit_job`` returns.

    Carries the same seven fields as 1.x's ``DashScopeAPIResponse``, so
    ``FineTune(**envelope)`` and ``SubmitResult(**envelope)`` accept the
    same dict. A failed submit is a non-200 ``status_code`` here rather
    than an exception, exactly as it was under ``FineTune``.
    """

    def __init__(
        self,
        status_code: int = None,
        request_id: str = "",
        code: str = None,
        message: str = "",
        output: Any = None,
        usage: Any = None,
        headers: Dict[str, Any] = None,
        **kwargs: Any,
    ):
        self.__dict__.update(kwargs)
        self.status_code = status_code
        self.request_id = request_id
        self.code = code
        self.message = message
        self.output = (
            SubmitOutput(**output) if isinstance(output, dict) else output
        )
        self.usage = usage
        self.headers = headers or {}

    def __repr__(self) -> str:
        return (
            f"{type(self).__name__}(status_code={self.status_code!r}, "
            f"request_id={self.request_id!r}, code={self.code!r}, "
            f"message={self.message!r}, output={self.output!r}, "
            f"usage={self.usage!r})"
        )


class AgenticRL(AgenticRLTuning):
    SUB_PATH: ClassVar[str] = "fine-tunes"

    def __init__(self, api_key: str = None):
        super().__init__()

        try:
            set_api_key(api_key)
        except Exception as e:
            raise ValueErrorWithCode.from_catalog(
                "sdk.InvalidApiKey",
                error_code=3001,
            ) from e

        self._api_key = api_key

    def _resolve_api_key(self) -> str:
        """The key to submit with; see the module docstring."""
        return resolve_api_key(self._api_key)

    def init(self, config_path: Optional[str] = None, **kwargs) -> Self:
        """
        Initialize an AgenticRL instance from a YAML configuration file.
        """
        self.tuning = TuningModel.load_from_yaml(config_path or "", **kwargs)

        return self

    async def register_functions(
        self,
        functions: Optional[
            Union[
                List[Union[RolloutFunctionComponent, RewardFunctionComponent]],
                RolloutFunctionComponent,
                RewardFunctionComponent,
            ]
        ] = None,
        lazy_load: Optional[bool] = True,
    ) -> tuple[
        List[str],
        List[str],
        List[str],
        List[str],
        List[str],
        List[str],
    ]:
        """Register function components and return entity/instance IDs."""
        if functions:
            self.tuning.functions = functions

        try:
            (
                rollout_entity_ids,
                reward_entity_ids,
                group_reward_entity_ids,
                rollout_instance_ids,
                reward_instance_ids,
                group_reward_instance_ids,
            ) = await self.tuning.register_functions(
                lazy_load=lazy_load,
                api_key=self._api_key,
            )
            logger.info("Function components registered")
        except Exception as e:
            if hasattr(e, "error_code"):
                raise
            raise RegistrationError.from_catalog(
                "sdk.agentic_rl.FunctionRegistrationFailed",
                error_code=3002,
                variables={"inner_code": _inner_code(e)},
            ) from e

        return (
            rollout_entity_ids,
            reward_entity_ids,
            group_reward_entity_ids,
            rollout_instance_ids,
            reward_instance_ids,
            group_reward_instance_ids,
        )

    async def upload_datasets(
        self,
        datasets: Optional[List[Dataset]] = None,
        training_files: Optional[Union[List[str], str]] = None,
        validation_files: Optional[Union[List[str], str]] = None,
    ) -> tuple[List[str], List[str]]:
        if datasets:
            self.tuning.datasets = datasets

        try:
            (
                uploaded_training_ids,
                uploaded_validation_ids,
            ) = await self.tuning.upload_datasets(
                training_files=training_files or [],
                validation_files=validation_files or [],
                api_key=self._resolve_api_key(),
            )
            logger.info("Datasets uploaded")
        except Exception as e:
            raise DatasetsError.from_catalog(
                "sdk.agentic_rl.DatasetsUploadFailed",
                error_code=3003,
                variables={"inner_code": _inner_code(e)},
            ) from e

        return uploaded_training_ids, uploaded_validation_ids

    def _build_submit_request(
        self,
        model: Optional[str] = None,
        datasets: Optional[List[Dataset]] = None,
        functions: Optional[
            Union[
                List[
                    Union[
                        RolloutFunctionComponent,
                        RewardFunctionComponent,
                        AgenticRLFunctionComponent,
                    ]
                ],
                RolloutFunctionComponent,
                RewardFunctionComponent,
                AgenticRLFunctionComponent,
            ]
        ] = None,
        hyper_parameters: Optional[Dict[str, str]] = None,
        resources: Optional[Dict[str, str]] = None,
        job_name: Optional[str] = None,
        teacher_model: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Assemble the job payload, folding the arguments into ``tuning``.

        Split out of ``submit_job`` so the 1.x surface can reuse it
        without touching the transport.
        """
        teacher_model = teacher_model or self.tuning.teacher_model

        # Resolve job name (fallback to class default)
        if job_name:
            self.tuning.name = job_name
        job_name_with_suffix = f"{self.tuning.name}-{generate_random_id()[:8]}"

        # Model name
        if model:
            self.tuning.model.name = model

        # rollouts/rewards
        if functions:
            self.tuning.functions = functions
        rollouts = self.tuning.combine_ids_runtimes(
            functype=FunctionType.ROLLOUT,
        )
        rewards = self.tuning.combine_ids_runtimes(
            functype=FunctionType.REWARD,
        )
        rewards.extend(
            self.tuning.combine_ids_runtimes(
                functype=FunctionType.GROUP_REWARD,
                id_str=get_func_type_id(FunctionType.REWARD),
            ),
        )
        # names of functions
        if not self.tuning.check_function_names():
            names = [
                getattr(fc, "name", "<missing>")
                for fc in self.tuning.functions
            ]
            duplicates = sorted(
                {name for name in names if names.count(name) > 1},
            )
            raise ValueErrorWithCode.from_catalog(
                "sdk.agentic_rl.DuplicateFunctionNames",
                error_code=3004,
                variables={"names": ", ".join(duplicates or names)},
            )

        # datasets
        if datasets:
            self.tuning.datasets = datasets
        training_datasets = [
            ds
            for ds in self.tuning.datasets
            if ds.type == DatasetsType.TRAINING
        ]
        validation_datasets = [
            ds
            for ds in self.tuning.datasets
            if ds.type == DatasetsType.VALIDATION
        ]

        # hyper_parameters
        if hyper_parameters:
            self.tuning.training.hyper_parameters = hyper_parameters

        # resources
        if resources:
            self.tuning.training.resources = resources

        training_type = self.tuning.training.type
        if teacher_model:
            training_type = TrainingType.PG_OPD
        elif training_type == TrainingType.PG_OPD:
            raise ValueErrorWithCode(
                f"teacher_model is required when training.type is {training_type}",
                error_code=3006,
            )

        request = {
            "model": self.tuning.model.name,
            "training_datasets": [ds.model_dump() for ds in training_datasets],
            "validation_datasets": [
                ds.model_dump() for ds in validation_datasets
            ],
            "rollout": rollouts[0] if rollouts else None,
            "rewards": rewards,
            "hyper_parameters": self.tuning.training.hyper_parameters,
            "resource_config": self.tuning.training.resources,
            "training_type": str(training_type),
            "teacher_model": teacher_model,
            "job_name": job_name_with_suffix,
        }
        request = deep_remove_none(request)
        logger.info(f"agentic_rl submit_job request: {request}")

        return request

    def _submit_envelope(
        self,
        model: Optional[str] = None,
        datasets: Optional[List[Dataset]] = None,
        functions: Optional[
            Union[
                List[
                    Union[
                        RolloutFunctionComponent,
                        RewardFunctionComponent,
                        AgenticRLFunctionComponent,
                    ]
                ],
                RolloutFunctionComponent,
                RewardFunctionComponent,
                AgenticRLFunctionComponent,
            ]
        ] = None,
        hyper_parameters: Optional[Dict[str, str]] = None,
        resources: Optional[Dict[str, str]] = None,
        job_name: Optional[str] = None,
        teacher_model: Optional[str] = None,
        **kwargs,
    ) -> Dict[str, Any]:
        """Build the payload, POST it, and return the raw envelope.

        Shared by both surfaces: this class wraps the result in
        ``SubmitResult``, the 1.x subclass in a ``FineTune`` dataclass.
        ``kwargs`` are forwarded to ``post_submit`` (``path``,
        ``timeout``, and overrides for ``api_key`` / ``base_url``).
        """
        request = self._build_submit_request(
            model=model,
            datasets=datasets,
            functions=functions,
            hyper_parameters=hyper_parameters,
            resources=resources,
            job_name=job_name,
            teacher_model=teacher_model,
        )

        kwargs.setdefault("api_key", self._resolve_api_key())
        kwargs.setdefault("base_url", DASHSCOPE_HTTP_BASE_URL)
        kwargs.setdefault("path", self.SUB_PATH)
        try:
            return _submit.post_submit(request, **kwargs)
        except Exception as e:
            if hasattr(e, "error_code"):
                raise
            raise RuntimeErrorWithCode.from_catalog(
                "sdk.agentic_rl.JobSubmissionFailed",
                error_code=3005,
                variables={"inner_code": _inner_code(e)},
            ) from e

    def submit_job(
        self,
        model: Optional[str] = None,
        datasets: Optional[List[Dataset]] = None,
        functions: Optional[
            Union[
                List[
                    Union[
                        RolloutFunctionComponent,
                        RewardFunctionComponent,
                        AgenticRLFunctionComponent,
                    ]
                ],
                RolloutFunctionComponent,
                RewardFunctionComponent,
                AgenticRLFunctionComponent,
            ]
        ] = None,
        hyper_parameters: Optional[Dict[str, str]] = None,
        resources: Optional[Dict[str, str]] = None,
        job_name: Optional[str] = None,
        teacher_model: Optional[str] = None,
        **kwargs,
    ) -> SubmitResult:
        """
        Submit RL tuning job to the platform.
        """
        return SubmitResult(
            **self._submit_envelope(
                model=model,
                datasets=datasets,
                functions=functions,
                hyper_parameters=hyper_parameters,
                resources=resources,
                job_name=job_name,
                teacher_model=teacher_model,
                **kwargs,
            ),
        )

    async def run(
        self,
        model: Optional[str] = None,
        # Datasets parameters
        training_datasets: Optional[List[TrainingDataset]] = None,
        validation_datasets: Optional[List[ValidationDataset]] = None,
        # Path-driven parameters (auto-register & upload)
        functions: Optional[
            Union[
                List[
                    Union[
                        RolloutFunctionComponent,
                        RewardFunctionComponent,
                        AgenticRLFunctionComponent,
                    ]
                ],
                RolloutFunctionComponent,
                RewardFunctionComponent,
                AgenticRLFunctionComponent,
            ]
        ] = None,
        # Common parameters
        hyper_parameters: Optional[Dict[str, str]] = None,
        resources: Optional[Dict[str, str]] = None,
        job_name: Optional[str] = None,
        teacher_model: Optional[str] = None,
        **kwargs,
    ) -> SubmitResult:
        """
        Execute RL tuning workflow.
        """
        try:
            logger.info(
                "Path-Driven mode: Registering functions & uploading "
                "datasets...",
            )
            await self.register_functions(
                functions=functions,
                lazy_load=True,
            )

            datasets = list(training_datasets or []) + list(
                validation_datasets or [],
            )
            await self.upload_datasets(
                datasets=datasets,
            )

            return self.submit_job(
                model=model,
                datasets=datasets,
                hyper_parameters=hyper_parameters,
                resources=resources,
                job_name=job_name,
                teacher_model=teacher_model,
                **kwargs,
            )
        except Exception as e:
            if hasattr(e, "error_code"):
                raise
            raise RuntimeErrorWithCode.from_catalog(
                "sdk.agentic_rl.WorkflowFailed",
                error_code=3006,
                variables={"inner_code": _inner_code(e)},
            ) from e

    @classmethod
    async def test_functions(
        cls,
        instance_id: str,
        functype: FunctionType,
        input_data: Dict[str, Any],
        api_key: str = None,
        pull_logs: bool = False,
        log_page_size: int = 100,
        start_time: Optional[int] = None,
        end_time: Optional[int] = None,
    ):
        """Test a deployed function instance with custom input data.

        Args:
            instance_id: Target function instance ID.
            functype: Function type (ROLLOUT/REWARD/GROUP_REWARD).
            input_data: Test input payload.
            api_key: DashScope API key (uses DASHSCOPE_API_KEY env var
                if omitted).
            pull_logs: If True, pull all logs of the function instance
                (with pagination) after verification and print them
                between separator markers.
            log_page_size: Page size used when pulling logs.
            start_time: Optional start time filter (in seconds) for log
                pulling. Defaults to 24 hours before ``end_time``.
            end_time: Optional end time filter (in seconds) for log
                pulling. Defaults to the current time (now).
        """
        try:
            set_api_key(api_key)

            if functype == FunctionType.ROLLOUT:
                value = RolloutInput.model_validate(input_data)
            elif functype == FunctionType.REWARD:
                value = RewardInput.model_validate(input_data)
            elif functype == FunctionType.GROUP_REWARD:
                value = GroupRewardInput.model_validate(input_data)
            else:
                raise ValueErrorWithCode.from_catalog(
                    "sdk.agentic_rl.UnsupportedFunctionType",
                    error_code=3007,
                    variables={"functype": str(functype)},
                )

            logger.info(
                f"Starting {str(functype)} verification",
                extra={
                    "instance_id": instance_id,
                    "input_params": value.model_dump(exclude={"api_key"}),
                },
            )

            result = await AgenticRLFunctionComponent.verify_function(
                value,
                instance_id,
                api_key=api_key,
            )

            if pull_logs:
                await cls._pull_function_instance_logs(
                    function_instance_id=instance_id,
                    page_size=log_page_size,
                    start_time=start_time,
                    end_time=end_time,
                    api_key=api_key,
                )

            return result

        except Exception as e:
            raise ValidationError.from_catalog(
                "sdk.agentic_rl.FunctionTestFailed",
                error_code=3008,
                variables={"inner_code": _inner_code(e)},
            ) from e

    @classmethod
    async def query_function_instance_logs(
        cls,
        function_instance_id: str,
        page_number: int = 1,
        page_size: int = 100,
        start_time: Optional[int] = None,
        end_time: Optional[int] = None,
        keywords: Optional[List[str]] = None,
        api_key: str = None,
    ) -> Dict[str, Any]:
        """Query one page of logs for a function (faas) instance.

        Args:
            function_instance_id: Target function instance ID.
            page_number: Page number, starting from 1.
            page_size: Number of log entries per page.
            start_time: Optional start time filter (in seconds).
            end_time: Optional end time filter (in seconds).
            keywords: Optional keyword filters for log messages.
            api_key: DashScope API key (uses DASHSCOPE_API_KEY env var
                if omitted).

        Returns:
            Raw response dict of the log query API.
        """
        try:
            set_api_key(api_key)

            fc_component = AgenticRLFunctionComponent
            return await fc_component.query_function_instance_logs(
                function_instance_id=function_instance_id,
                page_number=page_number,
                page_size=page_size,
                start_time=start_time,
                end_time=end_time,
                keywords=keywords,
                api_key=api_key,
            )

        except Exception as e:
            if hasattr(e, "error_code"):
                raise
            raise InstanceQueryError(
                "Function instance log query failed",
                error_code=3009,
            ) from e

    @classmethod
    async def query_all_function_instance_logs(
        cls,
        function_instance_id: str,
        page_size: int = 100,
        start_time: Optional[int] = None,
        end_time: Optional[int] = None,
        keywords: Optional[List[str]] = None,
        api_key: str = None,
    ) -> List[str]:
        """Fetch all logs of a function (faas) instance.

        Pages are fetched one by one via the paginated log query until
        all entries are collected.

        Args:
            function_instance_id: Target function instance ID.
            page_size: Number of log entries per page.
            start_time: Optional start time filter (in seconds).
            end_time: Optional end time filter (in seconds).
            keywords: Optional keyword filters for log messages.
            api_key: DashScope API key (uses DASHSCOPE_API_KEY env var
                if omitted).

        Returns:
            Aggregated list of log messages across all pages.
        """
        try:
            set_api_key(api_key)

            fc_component = AgenticRLFunctionComponent
            return await fc_component.query_all_function_instance_logs(
                function_instance_id=function_instance_id,
                page_size=page_size,
                start_time=start_time,
                end_time=end_time,
                keywords=keywords,
                api_key=api_key,
            )

        except Exception as e:
            if hasattr(e, "error_code"):
                raise
            raise InstanceQueryError(
                "Function instance log query failed",
                error_code=3010,
            ) from e

    @classmethod
    async def delete_function_instance(
        cls,
        function_instance_id: str,
        api_key: str = None,
    ) -> Dict[str, Any]:
        """Delete a function (faas) runtime instance.

        Args:
            function_instance_id: Target function instance ID.
            api_key: DashScope API key (uses DASHSCOPE_API_KEY env var
                if omitted).

        Returns:
            Raw response dict of the delete API, containing
            ``data.status`` (e.g. "deleted") and
            ``data.sandbox_code``.

        Raises:
            InstanceQueryError: If the deletion fails.
        """
        try:
            set_api_key(api_key)

            fc_component = AgenticRLFunctionComponent
            return await fc_component.delete_function_instance(
                function_instance_id=function_instance_id,
                api_key=api_key,
            )

        except Exception as e:
            if hasattr(e, "error_code"):
                raise
            raise InstanceQueryError(
                "Function instance deletion failed",
                error_code=3011,
            ) from e

    @classmethod
    async def _pull_function_instance_logs(
        cls,
        function_instance_id: str,
        page_size: int = 100,
        start_time: Optional[int] = None,
        end_time: Optional[int] = None,
        api_key: Optional[str] = None,
    ) -> None:
        """Pull all logs of a function instance and print them between
        separator markers (best effort, never raises).

        When ``start_time``/``end_time`` are not provided, defaults to
        pulling logs from 24 hours ago until now.
        """
        if end_time is None:
            end_time = int(time.time())
        if start_time is None:
            start_time = end_time - 24 * 60 * 60
        logger.info(
            "************start query log "
            f"(function_instance_id={function_instance_id})*******",
        )
        try:
            logs = await cls.query_all_function_instance_logs(
                function_instance_id=function_instance_id,
                page_size=page_size,
                start_time=start_time,
                end_time=end_time,
                api_key=api_key,
            )
            for entry in logs:
                logger.info(f"[function instance log] {entry}")
            logger.info(
                f"Pulled {len(logs)} log entries for function instance "
                f"{function_instance_id}",
            )
        except Exception as e:
            logger.warning(
                f"Failed to pull logs for function instance "
                f"{function_instance_id}: {e}",
            )
        finally:
            logger.info("************end query log *******")
