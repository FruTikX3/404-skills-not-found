# -*- coding: utf-8 -*-
# Copyright (c) Alibaba, Inc. and its affiliates.
"""httpx-based sync/async transports with connection pooling and retries."""

from __future__ import annotations

import asyncio
import functools
import os
import sys
import time
from typing import Any, Mapping, Optional, Union

import httpx

from dashscope._config import DEFAULT_TIMEOUT
from dashscope._logging import get_logger, request_id_from_headers
from dashscope.errors import (
    APIConnectionError,
    APITimeoutError,
    DashScopeError,
    check_response,
)
from dashscope.transport import _ident
from dashscope.transport._options import (
    RequestOptions,
    deep_merge,
    merge_query,
    resolve_max_retries,
    resolve_timeout,
)
from dashscope.transport._response import APIResponse
from dashscope.transport._retry import backoff_delay, should_retry

logger = get_logger("transport")

DEFAULT_CONNECT_TIMEOUT = 5.0
_WORKSPACE_HEADER = "X-DashScope-WorkSpace"


def _map_transport_error(
    exc: httpx.TransportError,
    request_id: Optional[str] = None,
) -> DashScopeError:
    """Map raw httpx transport failures into the SDK error hierarchy.

    The message text comes from the catalog entry behind each class
    (``sdk.Timeout`` / ``sdk.ConnectionError``), with the httpx error as
    the ``{detail}``.

    ``request_id`` is the best id the caller has for the failed request:
    the server's ``x-request-id`` when a response arrived before the
    failure, otherwise the client-generated id that went out with the
    request. A transport failure that never got a response can therefore
    only ever carry the client id -- which is still something to search
    access logs for, unlike the ``None`` it would otherwise be.
    """
    if isinstance(exc, httpx.TimeoutException):
        return APITimeoutError(detail=str(exc), request_id=request_id)
    return APIConnectionError(detail=str(exc), request_id=request_id)


def _resolve_timeout(
    timeout: Union[float, httpx.Timeout, None],
    default: float,
) -> httpx.Timeout:
    if timeout is None:
        return httpx.Timeout(default, connect=DEFAULT_CONNECT_TIMEOUT)
    if isinstance(timeout, httpx.Timeout):
        return timeout
    return httpx.Timeout(timeout, connect=DEFAULT_CONNECT_TIMEOUT)


def _build_headers(
    api_key: Optional[str],
    workspace: Optional[str],
    user_agent: Optional[str],
) -> dict:
    headers = {}
    if api_key:
        headers["Authorization"] = f"Bearer {api_key}"
    if workspace:
        headers[_WORKSPACE_HEADER] = workspace
    if user_agent:
        headers["User-Agent"] = user_agent
    return headers


def _timeout_kwarg(
    timeout: Union[float, httpx.Timeout, None],
) -> dict:
    # httpx reads an explicit timeout=None as "disable timeouts";
    # the argument must be omitted to keep the client-level default.
    return {} if timeout is None else {"timeout": timeout}


def _merge_headers(
    base: Mapping[str, str],
    overrides: Optional[Mapping[str, str]],
) -> dict:
    """``overrides`` on top of ``base``, matched case-insensitively.

    Used for every header layer (SDK identity, Client defaults, caller
    headers, ``extra_headers``), so an override spelled
    ``X-DashScope-Client-Request-Id`` replaces the lowercase default
    instead of emitting a duplicate header.
    """
    if overrides is None:
        return dict(base)
    override_keys = {key.lower() for key in overrides}
    merged = {
        key: value
        for key, value in base.items()
        if key.lower() not in override_keys
    }
    merged.update(overrides)
    return merged


def _merge_auth_headers(
    headers: Optional[Mapping[str, str]],
    api_key: Optional[str],
    workspace: Optional[str],
) -> Optional[Mapping[str, str]]:
    """Per-call ``api_key`` / ``workspace`` override the client auth.

    httpx merges request headers over the client defaults, so injecting
    ``Authorization`` / ``X-DashScope-WorkSpace`` here replaces the
    client-level credentials for this one call only.
    """
    if api_key is None and workspace is None:
        return headers
    return _merge_headers(
        headers or {},
        _build_headers(api_key, workspace, None),
    )


def _request_headers(
    defaults: Mapping[str, str],
    sdk: Mapping[str, str],
    headers: Optional[Mapping[str, str]],
    api_key: Optional[str],
    workspace: Optional[str],
    options: Optional[RequestOptions] = None,
) -> dict:
    """Merge Client defaults, SDK identity and per-call overrides.

    This is deliberately request-scoped so an injected ``http_client`` still
    receives the Client's credentials and user agent.

    Precedence, lowest to highest: SDK identity headers, Client defaults,
    caller ``headers``, the per-call ``api_key`` / ``workspace``, then
    ``options.extra_headers``. The auth-over-headers step is what makes
    ``api_key=`` mean "use this key" even when a client-level
    ``Authorization`` is still in ``headers``; ``extra_headers`` sits above
    everything because it is the narrowest, most explicit statement of
    intent a caller can make about one request. All of it is matched
    case-insensitively.
    """
    per_call = _merge_auth_headers(headers, api_key, workspace)
    configured = _merge_headers(defaults, per_call)
    merged = _merge_headers(sdk, configured)
    if options is not None and options.extra_headers:
        merged = _merge_headers(merged, options.extra_headers)
    return merged


def _with_extra_body(
    body: Any,
    options: Optional[RequestOptions],
    method: str,
    path: str,
    *,
    has_other_body: bool = False,
) -> Any:
    """Deep-merge ``options.extra_body`` into a JSON object body.

    A request whose body is something other than a JSON object -- raw
    ``content`` bytes, a multipart ``files`` upload -- has nothing to
    merge into, so it is left alone and the drop is reported: silently
    discarding what a caller asked to send is worse than the warning.
    ``has_other_body`` covers the case where ``json`` is absent only
    because another body channel is carrying the payload; httpx would
    drop the JSON silently, so the warning has to come from here.

    A missing body with no other channel is different: ``extra_body``
    alone becomes the JSON object, which is what a caller adding fields
    to a body-less request means.
    """
    if options is None or not options.extra_body:
        return body
    foreign_body = body is not None and not isinstance(body, dict)
    if has_other_body or foreign_body:
        logger.warning(
            "ignoring extra_body for %s %s: body is %s, not a JSON object",
            method,
            path,
            "another body channel" if has_other_body else type(body).__name__,
        )
        return body
    return deep_merge(body or {}, options.extra_body)


def _abs_url(base_url: Optional[str], path: str) -> str:
    # Per-request base_url override: an absolute URL replaces the
    # client-level base_url in httpx's URL merging. Used by the
    # protocol-adapted chat family, whose default endpoint differs
    # from the native gateway the transport is built with.
    if base_url is None:
        return path
    return f"{base_url.rstrip('/')}/{path.lstrip('/')}"


def default_user_agent(suffix: Optional[str] = None) -> str:
    """Base User-Agent, optionally tagged with the calling surface.

    ``suffix`` lets an embedder (the bundled CLI, a notebook kernel) mark
    its traffic so the service can attribute requests to a surface without
    a separate header. It is appended as a space-separated token, the
    conventional place for a product comment in a User-Agent.
    """
    try:
        from dashscope.version import __version__
    except Exception:
        __version__ = "0.0.0"
    agent = f"dashscope-sdk-python/{__version__}"
    return f"{agent} {suffix}" if suffix else agent


_DEV_MODE_ENV = "DASHSCOPE_DEV_MOCK"


def _dev_mock_requested() -> bool:
    """Whether the dev mock is on, checked before every send.

    Near-zero overhead when disabled: one env lookup plus a
    ``sys.modules`` probe that never imports :mod:`dashscope.devkit` on
    the production path. Callers check this *before* building the
    ``real`` partial, so an ordinary request pays no allocation for the
    mock seam. The devkit module is only imported once this is True.
    """
    if os.environ.get(_DEV_MODE_ENV):
        return True
    devkit = sys.modules.get("dashscope.devkit")
    return devkit is not None and devkit.is_active()


class SyncTransport:
    def __init__(
        self,
        *,
        base_url: str,
        api_key: Optional[str] = None,
        workspace: Optional[str] = None,
        user_agent: Optional[str] = None,
        timeout: Union[float, httpx.Timeout, None] = None,
        default_timeout: float = DEFAULT_TIMEOUT,
        max_retries: int = 2,
        http_client: Optional[httpx.Client] = None,
        limits: Optional[httpx.Limits] = None,
    ) -> None:
        self._owns_client = http_client is None
        self._base_url = base_url.rstrip("/")
        self._default_headers = _build_headers(api_key, workspace, user_agent)
        self._default_timeout = _resolve_timeout(timeout, default_timeout)
        self._request_timeout = (
            None
            if http_client is not None and timeout is None
            else self._default_timeout
        )
        self._client = http_client or httpx.Client(
            base_url=self._base_url,
            headers=self._default_headers,
            timeout=self._default_timeout,
            **({"limits": limits} if limits is not None else {}),
        )
        self._max_retries = max(max_retries, 0)

    @property
    def http_client(self) -> httpx.Client:
        """The underlying httpx client (shared by ``with_options``)."""
        return self._client

    @property
    def user_agent(self) -> Optional[str]:
        """This transport's User-Agent, for seeding non-HTTP channels.

        Websocket sessions do not ride this transport, so ``Client``
        reads the value back here to keep one identity across both.
        """
        return self._default_headers.get("User-Agent")

    def request(
        self,
        method: str,
        path: str,
        *,
        json: Any = None,
        content: Optional[bytes] = None,
        data: Optional[Mapping[str, Any]] = None,
        files: Any = None,
        params: Optional[Mapping[str, Any]] = None,
        headers: Optional[Mapping[str, str]] = None,
        base_url: Optional[str] = None,
        timeout: Union[float, httpx.Timeout, None] = None,
        api_key: Optional[str] = None,
        workspace: Optional[str] = None,
        sdk_module: Optional[str] = None,
        options: Optional[RequestOptions] = None,
    ) -> httpx.Response:
        if not _dev_mock_requested():
            return self._request_impl(
                method,
                path,
                json=json,
                content=content,
                data=data,
                files=files,
                params=params,
                headers=headers,
                base_url=base_url,
                timeout=timeout,
                api_key=api_key,
                workspace=workspace,
                sdk_module=sdk_module,
                options=options,
            )
        real = functools.partial(
            self._request_impl,
            method,
            path,
            json=json,
            content=content,
            data=data,
            files=files,
            params=params,
            headers=headers,
            base_url=base_url,
            timeout=timeout,
            api_key=api_key,
            workspace=workspace,
            sdk_module=sdk_module,
            options=options,
        )
        from dashscope import devkit

        return devkit.intercept(
            method=method,
            path=path,
            json_body=json,
            content=content,
            data=data,
            files=files,
            params=params,
            headers=headers,
            base_url=base_url or self._base_url,
            stream=False,
            real=real,
        )

    def _request_impl(
        self,
        method: str,
        path: str,
        *,
        json: Any = None,
        content: Optional[bytes] = None,
        data: Optional[Mapping[str, Any]] = None,
        files: Any = None,
        params: Optional[Mapping[str, Any]] = None,
        headers: Optional[Mapping[str, str]] = None,
        base_url: Optional[str] = None,
        timeout: Union[float, httpx.Timeout, None] = None,
        api_key: Optional[str] = None,
        workspace: Optional[str] = None,
        sdk_module: Optional[str] = None,
        options: Optional[RequestOptions] = None,
    ) -> httpx.Response:
        url = _abs_url(base_url or self._base_url, path)
        client_request_id = _ident.client_request_id()
        max_retries = resolve_max_retries(self._max_retries, options)
        params = merge_query(params, options)
        json = _with_extra_body(
            json,
            options,
            method,
            path,
            has_other_body=any(x is not None for x in (content, data, files)),
        )
        timeout = resolve_timeout(timeout, options)
        for attempt in range(max_retries + 1):
            response = None
            try:
                response = self._client.send(
                    self._client.build_request(
                        method,
                        url,
                        json=json,
                        content=content,
                        data=data,
                        files=files,
                        params=params,
                        headers=_request_headers(
                            self._default_headers,
                            _ident.sdk_headers(sdk_module, client_request_id),
                            headers,
                            api_key,
                            workspace,
                            options,
                        ),
                        **_timeout_kwarg(
                            (
                                self._request_timeout
                                if timeout is None
                                else timeout
                            ),
                        ),
                    ),
                    stream=True,
                )
                try:
                    response.read()
                finally:
                    response.close()
            except httpx.TransportError as exc:
                request_id = (
                    request_id_from_headers(response.headers)
                    if response is not None
                    else None
                )
                context = (
                    f" (request_id={request_id or 'unknown'})"
                    if response is not None
                    else ""
                )
                if attempt >= max_retries:
                    logger.warning(
                        "request %s %s failed after %d attempt(s)"
                        " (client_request_id=%s): %s%s",
                        method,
                        path,
                        attempt + 1,
                        client_request_id,
                        exc,
                        context,
                    )
                    raise _map_transport_error(
                        exc,
                        request_id or client_request_id,
                    ) from exc
                delay = backoff_delay(attempt, None)
                logger.info(
                    "retrying %s %s in %.2fs (attempt %d/%d): %s: %s%s",
                    method,
                    path,
                    delay,
                    attempt + 1,
                    max_retries,
                    type(exc).__name__,
                    exc,
                    context,
                )
                _sleep(delay)
                continue
            request_id = request_id_from_headers(response.headers) or "unknown"
            logger.debug(
                "request %s %s -> %d (client_request_id=%s, request_id=%s)",
                method,
                path,
                response.status_code,
                client_request_id,
                request_id,
            )
            if not should_retry(response.status_code, response.headers):
                return response
            if attempt >= max_retries:
                return response
            delay = backoff_delay(attempt, response.headers)
            logger.info(
                "retrying %s %s in %.2fs (attempt %d/%d): status %d"
                " (request_id=%s)",
                method,
                path,
                delay,
                attempt + 1,
                max_retries,
                response.status_code,
                request_id,
            )
            _sleep(delay)
        return response

    def request_api(
        self,
        method: str,
        path: str,
        *,
        json: Any = None,
        content: Optional[bytes] = None,
        data: Optional[Mapping[str, Any]] = None,
        files: Any = None,
        params: Optional[Mapping[str, Any]] = None,
        headers: Optional[Mapping[str, str]] = None,
        base_url: Optional[str] = None,
        timeout: Union[float, httpx.Timeout, None] = None,
        api_key: Optional[str] = None,
        workspace: Optional[str] = None,
        sdk_module: Optional[str] = None,
        options: Optional[RequestOptions] = None,
        client: Any = None,
    ) -> APIResponse:
        """``request()`` wrapped in an :class:`APIResponse`.

        A thin convenience layer: it reuses :meth:`request` (and therefore
        the same retry/backoff behavior) and only adds the response
        wrapper. ``client`` seeds the wrapper's ``strict`` /
        ``raise_on_error`` behavior and is optional.
        """
        response = self.request(
            method,
            path,
            json=json,
            content=content,
            data=data,
            files=files,
            params=params,
            headers=headers,
            base_url=base_url,
            timeout=timeout,
            api_key=api_key,
            workspace=workspace,
            sdk_module=sdk_module,
            options=options,
        )
        return APIResponse(response, client=client)

    def open_stream(
        self,
        method: str,
        path: str,
        *,
        json: Any = None,
        params: Optional[Mapping[str, Any]] = None,
        headers: Optional[Mapping[str, str]] = None,
        base_url: Optional[str] = None,
        timeout: Union[float, httpx.Timeout, None] = None,
        api_key: Optional[str] = None,
        workspace: Optional[str] = None,
        sdk_module: Optional[str] = None,
        options: Optional[RequestOptions] = None,
    ) -> httpx.Response:
        """Open a stream, retrying only before a successful stream exists.

        Initial connection failures and retryable HTTP statuses are safe to
        replay because no event has reached the caller yet. Once a successful
        response is returned, ownership transfers to the caller and the SDK
        never retries or replays stream contents.
        """
        if not _dev_mock_requested():
            return self._open_stream_impl(
                method,
                path,
                json=json,
                params=params,
                headers=headers,
                base_url=base_url,
                timeout=timeout,
                api_key=api_key,
                workspace=workspace,
                sdk_module=sdk_module,
                options=options,
            )
        real = functools.partial(
            self._open_stream_impl,
            method,
            path,
            json=json,
            params=params,
            headers=headers,
            base_url=base_url,
            timeout=timeout,
            api_key=api_key,
            workspace=workspace,
            sdk_module=sdk_module,
            options=options,
        )
        from dashscope import devkit

        return devkit.intercept(
            method=method,
            path=path,
            json_body=json,
            params=params,
            headers=headers,
            base_url=base_url or self._base_url,
            stream=True,
            real=real,
        )

    def _open_stream_impl(
        self,
        method: str,
        path: str,
        *,
        json: Any = None,
        params: Optional[Mapping[str, Any]] = None,
        headers: Optional[Mapping[str, str]] = None,
        base_url: Optional[str] = None,
        timeout: Union[float, httpx.Timeout, None] = None,
        api_key: Optional[str] = None,
        workspace: Optional[str] = None,
        sdk_module: Optional[str] = None,
        options: Optional[RequestOptions] = None,
    ) -> httpx.Response:
        url = _abs_url(base_url or self._base_url, path)
        client_request_id = _ident.client_request_id()
        max_retries = resolve_max_retries(self._max_retries, options)
        params = merge_query(params, options)
        json = _with_extra_body(json, options, method, path)
        timeout = resolve_timeout(timeout, options)
        for attempt in range(max_retries + 1):
            try:
                response = self._client.send(
                    self._client.build_request(
                        method,
                        url,
                        json=json,
                        params=params,
                        headers=_request_headers(
                            self._default_headers,
                            _ident.sdk_headers(sdk_module, client_request_id),
                            headers,
                            api_key,
                            workspace,
                            options,
                        ),
                        **_timeout_kwarg(
                            (
                                self._request_timeout
                                if timeout is None
                                else timeout
                            ),
                        ),
                    ),
                    stream=True,
                )
            except httpx.TransportError as exc:
                if attempt >= max_retries:
                    raise _map_transport_error(
                        exc,
                        client_request_id,
                    ) from exc
                delay = backoff_delay(attempt, None)
                logger.info(
                    "retrying stream %s %s in %.2fs (attempt %d/%d): %s: %s",
                    method,
                    path,
                    delay,
                    attempt + 1,
                    max_retries,
                    type(exc).__name__,
                    exc,
                )
                _sleep(delay)
                continue

            if should_retry(response.status_code, response.headers) and (
                attempt < max_retries
            ):
                delay = backoff_delay(attempt, response.headers)
                request_id = (
                    request_id_from_headers(response.headers) or "unknown"
                )
                try:
                    response.read()
                except httpx.TransportError:
                    # The response was never exposed to the caller; a broken
                    # retryable error body does not make replay unsafe.
                    pass
                finally:
                    response.close()
                logger.info(
                    "retrying stream %s %s in %.2fs (attempt %d/%d): "
                    "status %d (request_id=%s)",
                    method,
                    path,
                    delay,
                    attempt + 1,
                    max_retries,
                    response.status_code,
                    request_id,
                )
                _sleep(delay)
                continue

            if response.status_code >= 400:
                try:
                    response.read()
                    check_response(response)
                except httpx.TransportError as exc:
                    request_id = request_id_from_headers(response.headers)
                    logger.error(
                        "Failed to read HTTP response, request_id=%s",
                        request_id or "unknown",
                    )
                    raise _map_transport_error(
                        exc,
                        request_id or client_request_id,
                    ) from exc
                finally:
                    response.close()
            logger.debug(
                "stream %s %s -> %d (client_request_id=%s, request_id=%s)",
                method,
                path,
                response.status_code,
                client_request_id,
                request_id_from_headers(response.headers) or "unknown",
            )
            return response
        raise AssertionError("unreachable")

    def close(self) -> None:
        if self._owns_client:
            self._client.close()


class AsyncTransport:
    def __init__(
        self,
        *,
        base_url: str,
        api_key: Optional[str] = None,
        workspace: Optional[str] = None,
        user_agent: Optional[str] = None,
        timeout: Union[float, httpx.Timeout, None] = None,
        default_timeout: float = DEFAULT_TIMEOUT,
        max_retries: int = 2,
        http_client: Optional[httpx.AsyncClient] = None,
        limits: Optional[httpx.Limits] = None,
    ) -> None:
        self._owns_client = http_client is None
        self._base_url = base_url.rstrip("/")
        self._default_headers = _build_headers(api_key, workspace, user_agent)
        self._default_timeout = _resolve_timeout(timeout, default_timeout)
        self._request_timeout = (
            None
            if http_client is not None and timeout is None
            else self._default_timeout
        )
        self._client = http_client or httpx.AsyncClient(
            base_url=self._base_url,
            headers=self._default_headers,
            timeout=self._default_timeout,
            **({"limits": limits} if limits is not None else {}),
        )
        self._max_retries = max(max_retries, 0)

    @property
    def http_client(self) -> httpx.AsyncClient:
        """The underlying httpx client (shared by ``with_options``)."""
        return self._client

    @property
    def user_agent(self) -> Optional[str]:
        """This transport's User-Agent; see ``SyncTransport.user_agent``."""
        return self._default_headers.get("User-Agent")

    async def request(
        self,
        method: str,
        path: str,
        *,
        json: Any = None,
        content: Optional[bytes] = None,
        data: Optional[Mapping[str, Any]] = None,
        files: Any = None,
        params: Optional[Mapping[str, Any]] = None,
        headers: Optional[Mapping[str, str]] = None,
        base_url: Optional[str] = None,
        timeout: Union[float, httpx.Timeout, None] = None,
        api_key: Optional[str] = None,
        workspace: Optional[str] = None,
        sdk_module: Optional[str] = None,
        options: Optional[RequestOptions] = None,
    ) -> httpx.Response:
        if not _dev_mock_requested():
            return await self._arequest_impl(
                method,
                path,
                json=json,
                content=content,
                data=data,
                files=files,
                params=params,
                headers=headers,
                base_url=base_url,
                timeout=timeout,
                api_key=api_key,
                workspace=workspace,
                sdk_module=sdk_module,
                options=options,
            )
        real = functools.partial(
            self._arequest_impl,
            method,
            path,
            json=json,
            content=content,
            data=data,
            files=files,
            params=params,
            headers=headers,
            base_url=base_url,
            timeout=timeout,
            api_key=api_key,
            workspace=workspace,
            sdk_module=sdk_module,
            options=options,
        )
        from dashscope import devkit

        return await devkit.aintercept(
            method=method,
            path=path,
            json_body=json,
            content=content,
            data=data,
            files=files,
            params=params,
            headers=headers,
            base_url=base_url or self._base_url,
            stream=False,
            real=real,
        )

    async def _arequest_impl(
        self,
        method: str,
        path: str,
        *,
        json: Any = None,
        content: Optional[bytes] = None,
        data: Optional[Mapping[str, Any]] = None,
        files: Any = None,
        params: Optional[Mapping[str, Any]] = None,
        headers: Optional[Mapping[str, str]] = None,
        base_url: Optional[str] = None,
        timeout: Union[float, httpx.Timeout, None] = None,
        api_key: Optional[str] = None,
        workspace: Optional[str] = None,
        sdk_module: Optional[str] = None,
        options: Optional[RequestOptions] = None,
    ) -> httpx.Response:
        url = _abs_url(base_url or self._base_url, path)
        client_request_id = _ident.client_request_id()
        max_retries = resolve_max_retries(self._max_retries, options)
        params = merge_query(params, options)
        json = _with_extra_body(
            json,
            options,
            method,
            path,
            has_other_body=any(x is not None for x in (content, data, files)),
        )
        timeout = resolve_timeout(timeout, options)
        for attempt in range(max_retries + 1):
            response = None
            try:
                response = await self._client.send(
                    self._client.build_request(
                        method,
                        url,
                        json=json,
                        content=content,
                        data=data,
                        files=files,
                        params=params,
                        headers=_request_headers(
                            self._default_headers,
                            _ident.sdk_headers(sdk_module, client_request_id),
                            headers,
                            api_key,
                            workspace,
                            options,
                        ),
                        **_timeout_kwarg(
                            (
                                self._request_timeout
                                if timeout is None
                                else timeout
                            ),
                        ),
                    ),
                    stream=True,
                )
                try:
                    await response.aread()
                finally:
                    await response.aclose()
            except httpx.TransportError as exc:
                request_id = (
                    request_id_from_headers(response.headers)
                    if response is not None
                    else None
                )
                context = (
                    f" (request_id={request_id or 'unknown'})"
                    if response is not None
                    else ""
                )
                if attempt >= max_retries:
                    logger.warning(
                        "request %s %s failed after %d attempt(s)"
                        " (client_request_id=%s): %s%s",
                        method,
                        path,
                        attempt + 1,
                        client_request_id,
                        exc,
                        context,
                    )
                    raise _map_transport_error(
                        exc,
                        request_id or client_request_id,
                    ) from exc
                delay = backoff_delay(attempt, None)
                logger.info(
                    "retrying %s %s in %.2fs (attempt %d/%d): %s: %s%s",
                    method,
                    path,
                    delay,
                    attempt + 1,
                    max_retries,
                    type(exc).__name__,
                    exc,
                    context,
                )
                await _asleep(delay)
                continue
            request_id = request_id_from_headers(response.headers) or "unknown"
            logger.debug(
                "request %s %s -> %d (client_request_id=%s, request_id=%s)",
                method,
                path,
                response.status_code,
                client_request_id,
                request_id,
            )
            if not should_retry(response.status_code, response.headers):
                return response
            if attempt >= max_retries:
                return response
            delay = backoff_delay(attempt, response.headers)
            logger.info(
                "retrying %s %s in %.2fs (attempt %d/%d): status %d"
                " (request_id=%s)",
                method,
                path,
                delay,
                attempt + 1,
                max_retries,
                response.status_code,
                request_id,
            )
            await _asleep(delay)
        return response

    async def request_api(
        self,
        method: str,
        path: str,
        *,
        json: Any = None,
        content: Optional[bytes] = None,
        data: Optional[Mapping[str, Any]] = None,
        files: Any = None,
        params: Optional[Mapping[str, Any]] = None,
        headers: Optional[Mapping[str, str]] = None,
        base_url: Optional[str] = None,
        timeout: Union[float, httpx.Timeout, None] = None,
        api_key: Optional[str] = None,
        workspace: Optional[str] = None,
        sdk_module: Optional[str] = None,
        options: Optional[RequestOptions] = None,
        client: Any = None,
    ) -> APIResponse:
        """Async :meth:`SyncTransport.request_api`."""
        response = await self.request(
            method,
            path,
            json=json,
            content=content,
            data=data,
            files=files,
            params=params,
            headers=headers,
            base_url=base_url,
            timeout=timeout,
            api_key=api_key,
            workspace=workspace,
            sdk_module=sdk_module,
            options=options,
        )
        return APIResponse(response, client=client)

    async def open_stream(
        self,
        method: str,
        path: str,
        *,
        json: Any = None,
        params: Optional[Mapping[str, Any]] = None,
        headers: Optional[Mapping[str, str]] = None,
        base_url: Optional[str] = None,
        timeout: Union[float, httpx.Timeout, None] = None,
        api_key: Optional[str] = None,
        workspace: Optional[str] = None,
        sdk_module: Optional[str] = None,
        options: Optional[RequestOptions] = None,
    ) -> httpx.Response:
        """Async twin of :meth:`SyncTransport.open_stream`."""
        if not _dev_mock_requested():
            return await self._aopen_stream_impl(
                method,
                path,
                json=json,
                params=params,
                headers=headers,
                base_url=base_url,
                timeout=timeout,
                api_key=api_key,
                workspace=workspace,
                sdk_module=sdk_module,
                options=options,
            )
        real = functools.partial(
            self._aopen_stream_impl,
            method,
            path,
            json=json,
            params=params,
            headers=headers,
            base_url=base_url,
            timeout=timeout,
            api_key=api_key,
            workspace=workspace,
            sdk_module=sdk_module,
            options=options,
        )
        from dashscope import devkit

        return await devkit.aintercept(
            method=method,
            path=path,
            json_body=json,
            params=params,
            headers=headers,
            base_url=base_url or self._base_url,
            stream=True,
            real=real,
        )

    async def _aopen_stream_impl(
        self,
        method: str,
        path: str,
        *,
        json: Any = None,
        params: Optional[Mapping[str, Any]] = None,
        headers: Optional[Mapping[str, str]] = None,
        base_url: Optional[str] = None,
        timeout: Union[float, httpx.Timeout, None] = None,
        api_key: Optional[str] = None,
        workspace: Optional[str] = None,
        sdk_module: Optional[str] = None,
        options: Optional[RequestOptions] = None,
    ) -> httpx.Response:
        url = _abs_url(base_url or self._base_url, path)
        client_request_id = _ident.client_request_id()
        max_retries = resolve_max_retries(self._max_retries, options)
        params = merge_query(params, options)
        json = _with_extra_body(json, options, method, path)
        timeout = resolve_timeout(timeout, options)
        for attempt in range(max_retries + 1):
            request = self._client.build_request(
                method,
                url,
                json=json,
                params=params,
                headers=_request_headers(
                    self._default_headers,
                    _ident.sdk_headers(sdk_module, client_request_id),
                    headers,
                    api_key,
                    workspace,
                    options,
                ),
                **_timeout_kwarg(
                    self._request_timeout if timeout is None else timeout,
                ),
            )
            try:
                response = await self._client.send(request, stream=True)
            except httpx.TransportError as exc:
                if attempt >= max_retries:
                    raise _map_transport_error(
                        exc,
                        client_request_id,
                    ) from exc
                delay = backoff_delay(attempt, None)
                logger.info(
                    "retrying stream %s %s in %.2fs (attempt %d/%d): %s: %s",
                    method,
                    path,
                    delay,
                    attempt + 1,
                    max_retries,
                    type(exc).__name__,
                    exc,
                )
                await _asleep(delay)
                continue

            if should_retry(response.status_code, response.headers) and (
                attempt < max_retries
            ):
                delay = backoff_delay(attempt, response.headers)
                request_id = (
                    request_id_from_headers(response.headers) or "unknown"
                )
                try:
                    await response.aread()
                except httpx.TransportError:
                    pass
                finally:
                    await response.aclose()
                logger.info(
                    "retrying stream %s %s in %.2fs (attempt %d/%d): "
                    "status %d (request_id=%s)",
                    method,
                    path,
                    delay,
                    attempt + 1,
                    max_retries,
                    response.status_code,
                    request_id,
                )
                await _asleep(delay)
                continue

            if response.status_code >= 400:
                try:
                    await response.aread()
                    check_response(response)
                except httpx.TransportError as exc:
                    request_id = request_id_from_headers(response.headers)
                    logger.error(
                        "Failed to read HTTP response, request_id=%s",
                        request_id or "unknown",
                    )
                    raise _map_transport_error(
                        exc,
                        request_id or client_request_id,
                    ) from exc
                finally:
                    await response.aclose()
            logger.debug(
                "stream %s %s -> %d (client_request_id=%s, request_id=%s)",
                method,
                path,
                response.status_code,
                client_request_id,
                request_id_from_headers(response.headers) or "unknown",
            )
            return response
        raise AssertionError("unreachable")

    async def aclose(self) -> None:
        if self._owns_client:
            await self._client.aclose()


def _sleep(seconds: float) -> None:
    time.sleep(seconds)


async def _asleep(seconds: float) -> None:
    await asyncio.sleep(seconds)
