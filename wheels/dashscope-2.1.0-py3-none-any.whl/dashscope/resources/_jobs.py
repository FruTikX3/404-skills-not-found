# -*- coding: utf-8 -*-
# Copyright (c) Alibaba, Inc. and its affiliates.
"""Unified async-task (Job) infrastructure (design doc M3 3.2).

Long-running services (images, videos, transcription, ...) share the
``X-DashScope-Async`` pattern: submit returns a ``task_id``, then the
task is fetched from ``/tasks/{task_id}`` until it reaches a terminal
status. ``Jobs`` / ``AsyncJobs`` wrap that pattern with exponential
backoff polling; resources mount them as ``jobs.create/fetch/wait``.
"""

from __future__ import annotations

import asyncio
import time
from typing import (
    TYPE_CHECKING,
    Any,
    Awaitable,
    Callable,
    Dict,
    List,
    Mapping,
    Optional,
    Union,
    cast,
)

from pydantic import (
    AliasChoices,
    BaseModel,
    ConfigDict,
    Field,
    PrivateAttr,
)

from dashscope.errors import (
    DashScopeError,
    error_from_business_code,
    response_json,
)
from dashscope.transport._options import request_options
from dashscope.types._parse import parse_model
from dashscope.types.common import (
    ResponseBase,
    Usage,
    flatten_envelope,
    response_envelope,
    with_headers,
)
from dashscope.types.pagination import BasePage

if TYPE_CHECKING:
    import httpx

    from dashscope.transport._response import APIResponse

__all__ = [
    "AsyncJobs",
    "CANCELED",
    "FAILED",
    "Job",
    "JobList",
    "JobResult",
    "Jobs",
    "PENDING",
    "RUNNING",
    "SUCCEEDED",
    "UNKNOWN",
]

PENDING = "PENDING"
RUNNING = "RUNNING"
SUCCEEDED = "SUCCEEDED"
FAILED = "FAILED"
CANCELED = "CANCELED"
UNKNOWN = "UNKNOWN"

# UNKNOWN counts as terminal even though it reads like an indeterminate
# state: the gateway answers ``GET /tasks/{task_id}`` with HTTP 200 and
# ``task_status: UNKNOWN`` for a task that does not exist (or is not
# visible to this api key/workspace), so it never resolves. Treating it as
# non-terminal would make ``wait()`` re-poll a permanently-dead id until
# the timeout — 24h by default — and then report it as a wait timeout,
# hiding the real cause. 1.x stops on it for the same reason
# (client/base_api.py lists TaskStatus.UNKNOWN alongside SUCCEEDED /
# FAILED / CANCELED); the fine-tune plane deliberately does not, and
# ``fine_tunes._TERMINAL`` mirrors that narrower 1.x rule.
_TERMINAL = frozenset({SUCCEEDED, FAILED, CANCELED, UNKNOWN})

ASYNC_HEADER = {"X-DashScope-Async": "enable"}


def _image_choices(output: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Image parts of a choices-style output (multimodal-generation).

    Image models on the multimodal-generation protocol answer with
    chat-style ``choices`` instead of ``results``; lift every ``image``
    part so the typed views (``results`` / ``image_urls``) read the same
    for both output shapes.
    """
    results: List[Dict[str, Any]] = []
    for choice in output.get("choices") or []:
        if not isinstance(choice, dict):
            continue
        message = choice.get("message") or {}
        for part in message.get("content") or []:
            if isinstance(part, dict) and part.get("image"):
                results.append({"url": part["image"]})
    return results


DEFAULT_POLL_INTERVAL = 1.0
DEFAULT_MAX_INTERVAL = 8.0
# 1.x waits indefinitely; 2.0 caps the default at 24h so a stuck task
# cannot hang a process forever (recorded for the M7 migration guide).
DEFAULT_WAIT_TIMEOUT = 86400.0  # 24 hours


class JobResult(BaseModel):
    """One artifact a finished task produced.

    Image tasks answer with ``url``, transcription tasks with
    ``transcription_url``; anything else a service adds stays readable as an
    attribute.
    """

    model_config = ConfigDict(extra="allow")

    url: Optional[str] = None
    transcription_url: Optional[str] = None


class Job(ResponseBase):
    """One async task snapshot (submit or fetch result)."""

    task_id: str = ""
    status: str = Field(
        "",
        validation_alias=AliasChoices("status", "task_status"),
    )
    submitted_at: Optional[str] = Field(
        None,
        validation_alias=AliasChoices("submitted_at", "submit_time"),
    )
    scheduled_at: Optional[str] = Field(
        None,
        validation_alias=AliasChoices("scheduled_at", "scheduled_time"),
    )
    finished_at: Optional[str] = Field(
        None,
        validation_alias=AliasChoices("finished_at", "end_time"),
    )
    # Raw task payload: result fields differ per service, so the dict stays.
    # ``results`` / ``image_urls`` / ``video_url`` / ``result_url`` are the
    # typed views over it.
    output: Optional[Dict[str, Any]] = None
    usage: Optional[Usage] = None

    # ``output`` is an untyped dict, so the parse boundary that built this
    # Job validates the envelope but never looks inside it. Carrying the
    # mode here is what lets ``results`` be as strict as that boundary was,
    # instead of silently degrading under ``strict_validation=True``.
    _strict_validation: bool = PrivateAttr(default=False)
    _response: Optional["httpx.Response"] = PrivateAttr(default=None)

    @property
    def job_id(self) -> str:
        """``FineTune`` spells the same identifier ``job_id``."""
        return self.task_id

    @property
    def succeeded(self) -> bool:
        return self.status == SUCCEEDED

    @property
    def finished(self) -> bool:
        return self.status in _TERMINAL

    @property
    def results(self) -> List[JobResult]:
        """Artifacts the task produced.

        Parsed with the strictness and the response this Job was built
        with (see :meth:`from_payload`), so under ``strict_validation``
        a drifted artifact raises here rather than degrading to ``None``.
        A Job built directly rather than through ``from_payload`` has
        neither and gets the lenient default.
        """
        output = self.output or {}
        items = output.get("results")
        if not isinstance(items, list):
            items = []
        if not items:
            items = _image_choices(output)
        return [
            parse_model(
                JobResult,
                item,
                strict=self._strict_validation,
                response=self._response,
            )
            for item in items
            if isinstance(item, dict)
        ]

    @property
    def image_urls(self) -> List[str]:
        return [result.url for result in self.results if result.url]

    @property
    def video_url(self) -> Optional[str]:
        return (self.output or {}).get("video_url")

    @property
    def result_url(self) -> Optional[str]:
        """The single artifact of a one-result task."""
        urls = self.image_urls
        if urls:
            return urls[0]
        output = self.output or {}
        return output.get("url") or self.video_url

    @classmethod
    def from_payload(
        cls,
        body: Dict[str, Any],
        *,
        strict: bool = False,
        response: Optional[httpx.Response] = None,
    ) -> "Job":
        output = body.get("output")
        payload = flatten_envelope(body)
        payload["output"] = output if isinstance(output, dict) else None
        if not isinstance(payload.get("usage"), dict):
            payload.pop("usage", None)
        job = parse_model(
            cls,
            payload,
            strict=strict,
            response=response,
        )
        # Post-hoc: private attrs are not fields, so parse_model cannot
        # carry them through validation or through its construct fallback.
        # pylint: disable=protected-access
        job._strict_validation = strict
        job._response = response
        # pylint: enable=protected-access
        return job


class JobList(BasePage[Job]):
    """One page of async tasks, from ``jobs.list`` (1.x ``GET /tasks``).

    Each entry in ``tasks`` parses with the same aliases as a fetched
    :class:`Job`; a FAILED task inside the list is data, not an error.

    ``page_no`` / ``page_size`` / ``total_count`` come from
    :class:`~dashscope.types.pagination.BasePage`; iterate the page directly
    or cross pages with ``iter_pages()`` / ``next_page()``. The wire reports
    the total as ``total``, which is aliased onto ``total_count`` and also
    readable through the :attr:`total` property.
    """

    tasks: List[Job] = []

    @property
    def items(self) -> List[Job]:
        return self.tasks

    @property
    def total(self) -> int:
        """Alias of ``total_count``, keeping the historical field name readable."""
        return self.total_count

    @classmethod
    def from_payload(
        cls,
        body: Dict[str, Any],
        *,
        strict: bool = False,
        response: Optional[httpx.Response] = None,
    ) -> "JobList":
        # The list endpoint answers flat (no ``output`` wrapper), but
        # flatten_envelope also accepts an output-wrapped variant.
        data = flatten_envelope(body)
        tasks = data.pop("tasks", None)
        # A retyped ``tasks`` would blow up in the comprehension below,
        # ahead of the model layer that repairs the field.
        if not isinstance(tasks, list):
            tasks = []
        items = [task for task in tasks if isinstance(task, dict)]
        return parse_model(
            cls,
            {
                "page_no": data.get("page_no", 1),
                "page_size": data.get("page_size", 10),
                "total_count": data.get("total", len(items)),
                "tasks": items,
                **response_envelope(data),
            },
            strict=strict,
            response=response,
        )


def _list_params(
    start_time: Optional[str],
    end_time: Optional[str],
    model_name: Optional[str],
    api_key_id: Optional[str],
    region: Optional[str],
    status: Optional[str],
    page_no: int,
    page_size: int,
) -> Dict[str, Any]:
    """Query params of 1.x ``GET /tasks``: pagination always, filters when set."""
    params: Dict[str, Any] = {"page_no": page_no, "page_size": page_size}
    for key, value in (
        ("start_time", start_time),
        ("end_time", end_time),
        ("model_name", model_name),
        ("api_key_id", api_key_id),
        ("region", region),
        ("status", status),
    ):
        if value is not None:
            params[key] = value
    return params


class Jobs:
    """Sync async-task helper for one service (images, videos, ...).

    ``raw`` is a plain ``bool`` here, not a ``Literal`` overload pair: this
    class is only ever held in a resource's private attribute, and every
    public ``.jobs`` wrapper (``ImageJobs``, ``VideoJobs``, ``EmbeddingJobs``,
    ``TranscriptionJobs``) carries the overloads that give callers a precise
    return type. Overloading this one instead would leave the wrappers unable
    to forward a ``raw`` they only know at runtime.
    """

    def __init__(
        self,
        client,
        service: str,
        module: Optional[str] = None,
    ) -> None:
        self._client = client
        self._service = service
        # Functional-area tag for x-dashscope-sdk-client (see _ident);
        # the resource that mounts this helper passes its own module.
        self._module = module

    @property
    def submit_path(self) -> str:
        return f"/services/{self._service}"

    def create(  # pylint: disable=redefined-builtin
        self,
        *,
        model: str,
        input: Dict[str, Any],
        parameters: Optional[Dict[str, Any]] = None,
        headers: Optional[Dict[str, str]] = None,
        resources: Optional[List[Dict[str, Any]]] = None,
        timeout: Optional[float] = None,
        api_key: Optional[str] = None,
        workspace: Optional[str] = None,
        extra_headers: Optional[Mapping[str, str]] = None,
        extra_query: Optional[Mapping[str, Any]] = None,
        extra_body: Optional[Mapping[str, Any]] = None,
        max_retries: Optional[int] = None,
        raw: bool = False,
    ) -> Union[Job, "APIResponse"]:
        """Submit a task; returns immediately with a PENDING/RUNNING Job.

        ``raw=True`` returns the :class:`~dashscope.transport.APIResponse`
        before any error check, so a caller can read the status, headers and
        ``elapsed`` of the response or re-parse it itself.
        """
        body: Dict[str, Any] = {"model": model, "input": input}
        if parameters is not None:
            body["parameters"] = parameters
        if resources is not None:
            body["resources"] = resources
        submit_headers = dict(ASYNC_HEADER)
        if headers:
            submit_headers.update(headers)
        resp = self._client.transport.request_api(
            "POST",
            self.submit_path,
            json=body,
            headers=submit_headers,
            timeout=timeout,
            sdk_module=self._module,
            api_key=api_key,
            workspace=workspace,
            options=request_options(
                extra_headers,
                extra_query,
                extra_body,
                max_retries=max_retries,
            ),
            client=self._client,
        )
        if raw:
            return resp
        resp.raise_for_status()
        return self._parse(resp.http_response)

    def fetch(
        self,
        task_id: str,
        *,
        timeout: Optional[float] = None,
        api_key: Optional[str] = None,
        workspace: Optional[str] = None,
        extra_headers: Optional[Mapping[str, str]] = None,
        extra_query: Optional[Mapping[str, Any]] = None,
        extra_body: Optional[Mapping[str, Any]] = None,
        max_retries: Optional[int] = None,
        raw: bool = False,
    ) -> Union[Job, "APIResponse"]:
        """Fetch one task snapshot; raises on FAILED status.

        ``raw=True`` returns the :class:`~dashscope.transport.APIResponse`
        before any error check, so a caller can read the status, headers and
        ``elapsed`` of the response or re-parse it itself. It also skips the
        FAILED-status raise, which belongs to the parsed :class:`Job`.
        """
        resp = self._client.transport.request_api(
            "GET",
            f"/tasks/{task_id}",
            timeout=timeout,
            sdk_module=self._module,
            api_key=api_key,
            workspace=workspace,
            options=request_options(
                extra_headers,
                extra_query,
                extra_body,
                max_retries=max_retries,
            ),
            client=self._client,
        )
        if raw:
            return resp
        resp.raise_for_status()
        return self._parse(resp.http_response)

    def cancel(
        self,
        task_id: str,
        *,
        timeout: Optional[float] = None,
        api_key: Optional[str] = None,
        workspace: Optional[str] = None,
        extra_headers: Optional[Mapping[str, str]] = None,
        extra_query: Optional[Mapping[str, Any]] = None,
        extra_body: Optional[Mapping[str, Any]] = None,
        max_retries: Optional[int] = None,
        raw: bool = False,
    ) -> Union[Job, "APIResponse"]:
        """Cancel a PENDING task (1.x: ``POST /tasks/{task_id}/cancel``).

        ``raw=True`` returns the :class:`~dashscope.transport.APIResponse`
        before any error check, so a caller can read the status, headers and
        ``elapsed`` of the response or re-parse it itself.
        """
        resp = self._client.transport.request_api(
            "POST",
            f"/tasks/{task_id}/cancel",
            timeout=timeout,
            sdk_module=self._module,
            api_key=api_key,
            workspace=workspace,
            options=request_options(
                extra_headers,
                extra_query,
                extra_body,
                max_retries=max_retries,
            ),
            client=self._client,
        )
        if raw:
            return resp
        resp.raise_for_status()
        return self._parse(resp.http_response)

    def list(  # pylint: disable=redefined-builtin
        self,
        *,
        start_time: Optional[str] = None,
        end_time: Optional[str] = None,
        model_name: Optional[str] = None,
        api_key_id: Optional[str] = None,
        region: Optional[str] = None,
        status: Optional[str] = None,
        page_no: int = 1,
        page_size: int = 10,
        timeout: Optional[float] = None,
        api_key: Optional[str] = None,
        workspace: Optional[str] = None,
        extra_headers: Optional[Mapping[str, str]] = None,
        extra_query: Optional[Mapping[str, Any]] = None,
        extra_body: Optional[Mapping[str, Any]] = None,
        max_retries: Optional[int] = None,
        raw: bool = False,
    ) -> Union[JobList, "APIResponse"]:
        """List async tasks (1.x: ``GET /tasks`` with page_no/page_size).

        ``raw=True`` returns the :class:`~dashscope.transport.APIResponse`
        before any error check, so a caller can read the status, headers and
        ``elapsed`` of the response or re-parse it itself. Such a response
        carries no pagination callback; use ``next_page()`` on a parsed
        :class:`JobList` to walk the catalog.
        """
        resp = self._client.transport.request_api(
            "GET",
            "/tasks",
            params=_list_params(
                start_time,
                end_time,
                model_name,
                api_key_id,
                region,
                status,
                page_no,
                page_size,
            ),
            timeout=timeout,
            sdk_module=self._module,
            api_key=api_key,
            workspace=workspace,
            options=request_options(
                extra_headers,
                extra_query,
                extra_body,
                max_retries=max_retries,
            ),
            client=self._client,
        )
        if raw:
            return resp
        resp.raise_for_status()
        result = JobList.from_payload(
            resp.json(),
            strict=self._client.config.strict_validation,
            response=resp.http_response,
        )
        result.bind_pagination(
            lambda next_no, next_size: self.list(
                start_time=start_time,
                end_time=end_time,
                model_name=model_name,
                api_key_id=api_key_id,
                region=region,
                status=status,
                page_no=next_no,
                page_size=next_size,
                timeout=timeout,
                api_key=api_key,
                workspace=workspace,
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                max_retries=max_retries,
            ),
            requested_page_no=page_no,
            requested_page_size=page_size,
        )
        return with_headers(result, resp.http_response)

    def wait(
        self,
        job: Union[Job, str],
        *,
        poll_interval: float = DEFAULT_POLL_INTERVAL,
        max_interval: float = DEFAULT_MAX_INTERVAL,
        timeout: float = DEFAULT_WAIT_TIMEOUT,
        api_key: Optional[str] = None,
        workspace: Optional[str] = None,
        extra_headers: Optional[Mapping[str, str]] = None,
        extra_query: Optional[Mapping[str, Any]] = None,
        extra_body: Optional[Mapping[str, Any]] = None,
        max_retries: Optional[int] = None,
        _sleep: Optional[Callable[[float], Any]] = None,
    ) -> Job:
        """Poll with exponential backoff until the task finishes.

        With ``raise_on_error=False`` a terminal FAILED/CANCELED task (or
        a transport-level failure) comes back as the :class:`Job` envelope
        instead of raising; check ``job.status`` / ``job.is_error``.

        An ``UNKNOWN`` status is terminal too and is returned, not raised:
        the gateway reports it for a task id that does not exist, so
        polling again could never resolve it. Callers that care about the
        difference between "succeeded" and "no such task" should check
        ``job.succeeded`` rather than relying on ``wait()`` to raise.

        ``_sleep`` is a test seam — it replaces the pause between polls.
        """
        task_id = job.task_id if isinstance(job, Job) else job
        sleep_fn = _sleep or time.sleep
        deadline = time.monotonic() + timeout
        # ``wait`` never sets ``raw``, so every ``fetch`` below is a Job.
        # ``fetch``'s declared return is the wider union only because it also
        # serves the raw escape hatch.
        current: Job = (
            job
            if isinstance(job, Job)
            else cast(
                Job,
                self.fetch(
                    task_id,
                    api_key=api_key,
                    workspace=workspace,
                    extra_headers=extra_headers,
                    extra_query=extra_query,
                    extra_body=extra_body,
                    max_retries=max_retries,
                ),
            )
        )
        interval = poll_interval
        while not current.finished:
            # Compat mode (raise_on_error=False): a transport-level failure
            # comes back as an error envelope with no task status, which
            # would otherwise poll until the timeout.
            if current.is_error:
                return current
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise DashScopeError(
                    f"timed out after {timeout}s waiting for task {task_id}",
                )
            sleep_fn(min(interval, remaining))
            interval = min(interval * 2, max_interval)
            current = cast(
                Job,
                self.fetch(
                    task_id,
                    api_key=api_key,
                    workspace=workspace,
                    extra_headers=extra_headers,
                    extra_query=extra_query,
                    extra_body=extra_body,
                    max_retries=max_retries,
                ),
            )
        return self._check_canceled(current)

    def _parse(self, response: Any) -> Job:
        payload = response_json(response)
        job = with_headers(
            Job.from_payload(
                payload,
                strict=self._client.config.strict_validation,
                response=response,
            ),
            response,
        )
        if job.status == FAILED and self._client.raise_on_error:
            raise error_from_business_code(
                message=job.message or f"task {job.task_id} failed",
                code=job.code,
                body=payload,
                headers=response.headers,
            )
        return job

    def _check_canceled(self, job: Job) -> Job:
        if job.status == CANCELED and self._client.raise_on_error:
            raise DashScopeError(
                f"task {job.task_id} was canceled while waiting",
                request_id=job.request_id,
            )
        return job


class AsyncJobs:
    """Async async-task helper for one service (images, videos, ...).

    ``raw`` is a plain ``bool`` here for the reason given on :class:`Jobs`.
    """

    def __init__(
        self,
        client,
        service: str,
        module: Optional[str] = None,
    ) -> None:
        self._client = client
        self._service = service
        self._module = module

    @property
    def submit_path(self) -> str:
        return f"/services/{self._service}"

    async def create(  # pylint: disable=redefined-builtin
        self,
        *,
        model: str,
        input: Dict[str, Any],
        parameters: Optional[Dict[str, Any]] = None,
        headers: Optional[Dict[str, str]] = None,
        resources: Optional[List[Dict[str, Any]]] = None,
        timeout: Optional[float] = None,
        api_key: Optional[str] = None,
        workspace: Optional[str] = None,
        extra_headers: Optional[Mapping[str, str]] = None,
        extra_query: Optional[Mapping[str, Any]] = None,
        extra_body: Optional[Mapping[str, Any]] = None,
        max_retries: Optional[int] = None,
        raw: bool = False,
    ) -> Union[Job, "APIResponse"]:
        """Async twin of :meth:`Jobs.create`."""
        body: Dict[str, Any] = {"model": model, "input": input}
        if parameters is not None:
            body["parameters"] = parameters
        if resources is not None:
            body["resources"] = resources
        submit_headers = dict(ASYNC_HEADER)
        if headers:
            submit_headers.update(headers)
        resp = await self._client.transport.request_api(
            "POST",
            self.submit_path,
            json=body,
            headers=submit_headers,
            timeout=timeout,
            sdk_module=self._module,
            api_key=api_key,
            workspace=workspace,
            options=request_options(
                extra_headers,
                extra_query,
                extra_body,
                max_retries=max_retries,
            ),
            client=self._client,
        )
        if raw:
            return resp
        resp.raise_for_status()
        return self._parse(resp.http_response)

    async def fetch(
        self,
        task_id: str,
        *,
        timeout: Optional[float] = None,
        api_key: Optional[str] = None,
        workspace: Optional[str] = None,
        extra_headers: Optional[Mapping[str, str]] = None,
        extra_query: Optional[Mapping[str, Any]] = None,
        extra_body: Optional[Mapping[str, Any]] = None,
        max_retries: Optional[int] = None,
        raw: bool = False,
    ) -> Union[Job, "APIResponse"]:
        """Async twin of :meth:`Jobs.fetch`."""
        resp = await self._client.transport.request_api(
            "GET",
            f"/tasks/{task_id}",
            timeout=timeout,
            sdk_module=self._module,
            api_key=api_key,
            workspace=workspace,
            options=request_options(
                extra_headers,
                extra_query,
                extra_body,
                max_retries=max_retries,
            ),
            client=self._client,
        )
        if raw:
            return resp
        resp.raise_for_status()
        return self._parse(resp.http_response)

    async def cancel(
        self,
        task_id: str,
        *,
        timeout: Optional[float] = None,
        api_key: Optional[str] = None,
        workspace: Optional[str] = None,
        extra_headers: Optional[Mapping[str, str]] = None,
        extra_query: Optional[Mapping[str, Any]] = None,
        extra_body: Optional[Mapping[str, Any]] = None,
        max_retries: Optional[int] = None,
        raw: bool = False,
    ) -> Union[Job, "APIResponse"]:
        """Async twin of :meth:`Jobs.cancel`."""
        resp = await self._client.transport.request_api(
            "POST",
            f"/tasks/{task_id}/cancel",
            timeout=timeout,
            sdk_module=self._module,
            api_key=api_key,
            workspace=workspace,
            options=request_options(
                extra_headers,
                extra_query,
                extra_body,
                max_retries=max_retries,
            ),
            client=self._client,
        )
        if raw:
            return resp
        resp.raise_for_status()
        return self._parse(resp.http_response)

    async def list(  # pylint: disable=redefined-builtin
        self,
        *,
        start_time: Optional[str] = None,
        end_time: Optional[str] = None,
        model_name: Optional[str] = None,
        api_key_id: Optional[str] = None,
        region: Optional[str] = None,
        status: Optional[str] = None,
        page_no: int = 1,
        page_size: int = 10,
        timeout: Optional[float] = None,
        api_key: Optional[str] = None,
        workspace: Optional[str] = None,
        extra_headers: Optional[Mapping[str, str]] = None,
        extra_query: Optional[Mapping[str, Any]] = None,
        extra_body: Optional[Mapping[str, Any]] = None,
        max_retries: Optional[int] = None,
        raw: bool = False,
    ) -> Union[JobList, "APIResponse"]:
        """Async twin of :meth:`Jobs.list`."""
        resp = await self._client.transport.request_api(
            "GET",
            "/tasks",
            params=_list_params(
                start_time,
                end_time,
                model_name,
                api_key_id,
                region,
                status,
                page_no,
                page_size,
            ),
            timeout=timeout,
            sdk_module=self._module,
            api_key=api_key,
            workspace=workspace,
            options=request_options(
                extra_headers,
                extra_query,
                extra_body,
                max_retries=max_retries,
            ),
            client=self._client,
        )
        if raw:
            return resp
        resp.raise_for_status()
        result = JobList.from_payload(
            resp.json(),
            strict=self._client.config.strict_validation,
            response=resp.http_response,
        )
        result.bind_pagination(
            lambda next_no, next_size: self.list(
                start_time=start_time,
                end_time=end_time,
                model_name=model_name,
                api_key_id=api_key_id,
                region=region,
                status=status,
                page_no=next_no,
                page_size=next_size,
                timeout=timeout,
                api_key=api_key,
                workspace=workspace,
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                max_retries=max_retries,
            ),
            requested_page_no=page_no,
            requested_page_size=page_size,
        )
        return with_headers(result, resp.http_response)

    async def wait(
        self,
        job: Union[Job, str],
        *,
        poll_interval: float = DEFAULT_POLL_INTERVAL,
        max_interval: float = DEFAULT_MAX_INTERVAL,
        timeout: float = DEFAULT_WAIT_TIMEOUT,
        api_key: Optional[str] = None,
        workspace: Optional[str] = None,
        extra_headers: Optional[Mapping[str, str]] = None,
        extra_query: Optional[Mapping[str, Any]] = None,
        extra_body: Optional[Mapping[str, Any]] = None,
        max_retries: Optional[int] = None,
        _sleep: Optional[Callable[[float], Awaitable[None]]] = None,
    ) -> Job:
        """Async twin of :meth:`Jobs.wait`, same compat-mode contract."""
        task_id = job.task_id if isinstance(job, Job) else job
        sleep_fn = _sleep or asyncio.sleep
        deadline = time.monotonic() + timeout
        current: Job = (
            job
            if isinstance(job, Job)
            else cast(
                Job,
                await self.fetch(
                    task_id,
                    api_key=api_key,
                    workspace=workspace,
                    extra_headers=extra_headers,
                    extra_query=extra_query,
                    extra_body=extra_body,
                    max_retries=max_retries,
                ),
            )
        )
        interval = poll_interval
        while not current.finished:
            # Compat mode (raise_on_error=False): a transport-level failure
            # comes back as an error envelope with no task status, which
            # would otherwise poll until the timeout.
            if current.is_error:
                return current
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise DashScopeError(
                    f"timed out after {timeout}s waiting for task {task_id}",
                )
            await sleep_fn(min(interval, remaining))
            interval = min(interval * 2, max_interval)
            current = cast(
                Job,
                await self.fetch(
                    task_id,
                    api_key=api_key,
                    workspace=workspace,
                    extra_headers=extra_headers,
                    extra_query=extra_query,
                    extra_body=extra_body,
                    max_retries=max_retries,
                ),
            )
        return self._check_canceled(current)

    def _parse(self, response: Any) -> Job:
        payload = response_json(response)
        job = with_headers(
            Job.from_payload(
                payload,
                strict=self._client.config.strict_validation,
                response=response,
            ),
            response,
        )
        if job.status == FAILED and self._client.raise_on_error:
            raise error_from_business_code(
                message=job.message or f"task {job.task_id} failed",
                code=job.code,
                body=payload,
                headers=response.headers,
            )
        return job

    def _check_canceled(self, job: Job) -> Job:
        if job.status == CANCELED and self._client.raise_on_error:
            raise DashScopeError(
                f"task {job.task_id} was canceled while waiting",
                request_id=job.request_id,
            )
        return job
