# -*- coding: utf-8 -*-
# Copyright (c) Alibaba, Inc. and its affiliates.
"""client.embeddings resource (native text embedding + batch jobs).

Multimodal embedding lives at ``client.multimodal.embeddings``.
"""

# "input" is the public API parameter name (mirrors OpenAI embeddings).
# pylint: disable=redefined-builtin

from __future__ import annotations

from typing import (
    TYPE_CHECKING,
    Any,
    Awaitable,
    Callable,
    Dict,
    List,
    Literal,
    Mapping,
    Optional,
    Union,
    overload,
)

from pydantic import AliasChoices, BaseModel, ConfigDict, Field

from dashscope.resources._jobs import (
    DEFAULT_MAX_INTERVAL,
    DEFAULT_POLL_INTERVAL,
    DEFAULT_WAIT_TIMEOUT,
    AsyncJobs,
    Job,
    JobList,
    Jobs,
)
from dashscope.transport._options import request_options
from dashscope.types._parse import parse_model
from dashscope.types.common import (
    ResponseBase,
    Usage,
    response_envelope,
    with_headers,
)

if TYPE_CHECKING:
    import httpx

    from dashscope.transport._response import APIResponse

_PATH = "/services/embeddings/text-embedding/text-embedding"
_BATCH_SERVICE = "embeddings/text-embedding/text-embedding"
# Functional-area tag for x-dashscope-sdk-client (matches 1.x ``embeddings``).
MODULE = "embeddings"

__all__ = [
    "AsyncEmbeddings",
    "Embedding",
    "EmbeddingResponse",
    "Embeddings",
]


class Embedding(BaseModel):
    """One embedding vector; ``type`` says which modality produced it."""

    model_config = ConfigDict(extra="allow")

    # The text endpoint reports the position as "text_index"; every other
    # endpoint calls it "index". One public name, both wire spellings.
    index: int = Field(0, validation_alias=AliasChoices("index", "text_index"))
    type: Optional[str] = None
    embedding: List[float] = []


class EmbeddingResponse(ResponseBase):
    embeddings: List[Embedding] = []
    usage: Optional[Usage] = None


def parse_embedding_response(
    body: Dict[str, Any],
    *,
    strict: bool = False,
    response: Optional[httpx.Response] = None,
) -> EmbeddingResponse:
    """Shared by the text and multimodal endpoints: one response shape.

    Built through :func:`~dashscope.types._parse.parse_model` like every
    other v2 response parser, so a drifted field degrades instead of
    raising a bare ``ValidationError`` -- and ``strict`` reaches it, which
    is what makes ``strict_validation`` mean the same thing here as on
    ``models`` / ``files`` / ``jobs``. Both endpoints forward the
    client's setting, including ``multimodal.embeddings`` on the
    pre-``request_api`` transport path, whose ``request`` returns the
    same ``httpx.Response``.
    """
    output = body.get("output")
    if not isinstance(output, dict):
        output = {}
    embeddings = output.get("embeddings") or []
    if not embeddings and output.get("embedding"):
        # multimodal-embedding-one-peace-v1 predates the plural list: it
        # fuses every content into one vector returned as output.embedding.
        # Surface it as item 0 of the canonical list so callers read one
        # shape regardless of model generation. 1.x exposed the raw key via
        # response.output["embedding"]; v2 normalizes instead.
        embeddings = [{"index": 0, "embedding": output["embedding"]}]
    return parse_model(
        EmbeddingResponse,
        {
            "embeddings": embeddings,
            "usage": body.get("usage"),
            **response_envelope(body),
        },
        strict=strict,
        response=response,
    )


def _build_body(
    *,
    model: str,
    input: Union[str, List[str]],
    text_type: Optional[str],
    dimension: Optional[int],
    output_type: Optional[str],
    instruct: Optional[str],
    parameters: Optional[Dict[str, Any]],
) -> Dict[str, Any]:
    texts = [input] if isinstance(input, str) else list(input)
    if not texts:
        raise ValueError("input must not be empty")
    merged: Dict[str, Any] = {}
    for key, value in (
        ("text_type", text_type),
        ("dimension", dimension),
        ("output_type", output_type),
        ("instruct", instruct),
    ):
        if value is not None:
            merged[key] = value
    if parameters:
        merged.update(parameters)
    return {
        "model": model,
        "input": {"texts": texts},
        "parameters": merged,
    }


class EmbeddingJobs:
    """Async batch embedding task facade over the Jobs infra."""

    def __init__(self, client) -> None:
        self._jobs = Jobs(client, _BATCH_SERVICE, MODULE)

    @overload
    def create(
        self,
        *,
        model: str,
        file_url: str,
        text_type: Optional[str] = None,
        parameters: Optional[Dict[str, Any]] = None,
        timeout: Optional[float] = None,
        api_key: Optional[str] = None,
        workspace: Optional[str] = None,
        extra_headers: Optional[Mapping[str, str]] = None,
        extra_query: Optional[Mapping[str, Any]] = None,
        extra_body: Optional[Mapping[str, Any]] = None,
        max_retries: Optional[int] = None,
        raw: Literal[False] = False,
    ) -> Job:
        ...

    @overload
    def create(
        self,
        *,
        model: str,
        file_url: str,
        text_type: Optional[str] = None,
        parameters: Optional[Dict[str, Any]] = None,
        timeout: Optional[float] = None,
        api_key: Optional[str] = None,
        workspace: Optional[str] = None,
        extra_headers: Optional[Mapping[str, str]] = None,
        extra_query: Optional[Mapping[str, Any]] = None,
        extra_body: Optional[Mapping[str, Any]] = None,
        max_retries: Optional[int] = None,
        raw: Literal[True],
    ) -> "APIResponse":
        ...

    def create(
        self,
        *,
        model: str,
        file_url: str,
        text_type: Optional[str] = None,
        parameters: Optional[Dict[str, Any]] = None,
        timeout: Optional[float] = None,
        api_key: Optional[str] = None,
        workspace: Optional[str] = None,
        extra_headers: Optional[Mapping[str, str]] = None,
        extra_query: Optional[Mapping[str, Any]] = None,
        extra_body: Optional[Mapping[str, Any]] = None,
        max_retries: Optional[int] = None,
        raw: bool = False,
    ) -> Union[Job, "APIResponse"]:
        """Submit a batch task over one file whose lines are the texts.

        Singular, unlike ``asr.transcribe(file_urls=)``: this endpoint
        accepts exactly one file.

        ``raw=True`` returns the :class:`~dashscope.transport.APIResponse`
        of the underlying call before any error check.
        """
        if not file_url:
            raise ValueError("file_url must not be empty")
        merged = dict(parameters or {})
        if text_type is not None:
            merged["text_type"] = text_type
        return self._jobs.create(
            model=model,
            input={"url": file_url},
            parameters=merged or None,
            api_key=api_key,
            workspace=workspace,
            timeout=timeout,
            extra_headers=extra_headers,
            extra_query=extra_query,
            extra_body=extra_body,
            max_retries=max_retries,
            raw=raw,
        )

    @overload
    def fetch(
        self,
        task_id: str,
        *,
        timeout: Optional[float] = None,
        api_key: Optional[str] = None,
        workspace: Optional[str] = None,
        extra_headers: Optional[Mapping[str, str]] = None,
        extra_query: Optional[Mapping[str, Any]] = None,
        extra_body: Optional[Mapping[str, Any]] = None,
        max_retries: Optional[int] = None,
        raw: Literal[False] = False,
    ) -> Job:
        ...

    @overload
    def fetch(
        self,
        task_id: str,
        *,
        timeout: Optional[float] = None,
        api_key: Optional[str] = None,
        workspace: Optional[str] = None,
        extra_headers: Optional[Mapping[str, str]] = None,
        extra_query: Optional[Mapping[str, Any]] = None,
        extra_body: Optional[Mapping[str, Any]] = None,
        max_retries: Optional[int] = None,
        raw: Literal[True],
    ) -> "APIResponse":
        ...

    def fetch(
        self,
        task_id: str,
        *,
        timeout: Optional[float] = None,
        api_key: Optional[str] = None,
        workspace: Optional[str] = None,
        extra_headers: Optional[Mapping[str, str]] = None,
        extra_query: Optional[Mapping[str, Any]] = None,
        extra_body: Optional[Mapping[str, Any]] = None,
        max_retries: Optional[int] = None,
        raw: bool = False,
    ) -> Union[Job, "APIResponse"]:
        """Fetch one task snapshot.

        ``raw=True`` returns the :class:`~dashscope.transport.APIResponse`
        of the underlying call before any error check.
        """
        return self._jobs.fetch(
            task_id,
            api_key=api_key,
            workspace=workspace,
            timeout=timeout,
            extra_headers=extra_headers,
            extra_query=extra_query,
            extra_body=extra_body,
            max_retries=max_retries,
            raw=raw,
        )

    @overload
    def cancel(
        self,
        task_id: str,
        *,
        timeout: Optional[float] = None,
        api_key: Optional[str] = None,
        workspace: Optional[str] = None,
        extra_headers: Optional[Mapping[str, str]] = None,
        extra_query: Optional[Mapping[str, Any]] = None,
        extra_body: Optional[Mapping[str, Any]] = None,
        max_retries: Optional[int] = None,
        raw: Literal[False] = False,
    ) -> Job:
        ...

    @overload
    def cancel(
        self,
        task_id: str,
        *,
        timeout: Optional[float] = None,
        api_key: Optional[str] = None,
        workspace: Optional[str] = None,
        extra_headers: Optional[Mapping[str, str]] = None,
        extra_query: Optional[Mapping[str, Any]] = None,
        extra_body: Optional[Mapping[str, Any]] = None,
        max_retries: Optional[int] = None,
        raw: Literal[True],
    ) -> "APIResponse":
        ...

    def cancel(
        self,
        task_id: str,
        *,
        timeout: Optional[float] = None,
        api_key: Optional[str] = None,
        workspace: Optional[str] = None,
        extra_headers: Optional[Mapping[str, str]] = None,
        extra_query: Optional[Mapping[str, Any]] = None,
        extra_body: Optional[Mapping[str, Any]] = None,
        max_retries: Optional[int] = None,
        raw: bool = False,
    ) -> Union[Job, "APIResponse"]:
        """Cancel a PENDING task (``POST /tasks/{task_id}/cancel``).

        ``raw=True`` returns the :class:`~dashscope.transport.APIResponse`
        of the underlying call before any error check.
        """
        return self._jobs.cancel(
            task_id,
            api_key=api_key,
            workspace=workspace,
            timeout=timeout,
            extra_headers=extra_headers,
            extra_query=extra_query,
            extra_body=extra_body,
            max_retries=max_retries,
            raw=raw,
        )

    @overload
    def list(  # pylint: disable=redefined-builtin
        self,
        *,
        start_time: Optional[str] = None,
        end_time: Optional[str] = None,
        model_name: Optional[str] = None,
        api_key_id: Optional[str] = None,
        region: Optional[str] = None,
        status: Optional[str] = None,
        page_no: int = 1,
        page_size: int = 10,
        timeout: Optional[float] = None,
        api_key: Optional[str] = None,
        workspace: Optional[str] = None,
        extra_headers: Optional[Mapping[str, str]] = None,
        extra_query: Optional[Mapping[str, Any]] = None,
        extra_body: Optional[Mapping[str, Any]] = None,
        max_retries: Optional[int] = None,
        raw: Literal[False] = False,
    ) -> JobList:
        ...

    @overload
    def list(  # pylint: disable=redefined-builtin
        self,
        *,
        start_time: Optional[str] = None,
        end_time: Optional[str] = None,
        model_name: Optional[str] = None,
        api_key_id: Optional[str] = None,
        region: Optional[str] = None,
        status: Optional[str] = None,
        page_no: int = 1,
        page_size: int = 10,
        timeout: Optional[float] = None,
        api_key: Optional[str] = None,
        workspace: Optional[str] = None,
        extra_headers: Optional[Mapping[str, str]] = None,
        extra_query: Optional[Mapping[str, Any]] = None,
        extra_body: Optional[Mapping[str, Any]] = None,
        max_retries: Optional[int] = None,
        raw: Literal[True],
    ) -> "APIResponse":
        ...

    def list(  # pylint: disable=redefined-builtin
        self,
        *,
        start_time: Optional[str] = None,
        end_time: Optional[str] = None,
        model_name: Optional[str] = None,
        api_key_id: Optional[str] = None,
        region: Optional[str] = None,
        status: Optional[str] = None,
        page_no: int = 1,
        page_size: int = 10,
        timeout: Optional[float] = None,
        api_key: Optional[str] = None,
        workspace: Optional[str] = None,
        extra_headers: Optional[Mapping[str, str]] = None,
        extra_query: Optional[Mapping[str, Any]] = None,
        extra_body: Optional[Mapping[str, Any]] = None,
        max_retries: Optional[int] = None,
        raw: bool = False,
    ) -> Union[JobList, "APIResponse"]:
        """List async tasks (``GET /tasks``).

        ``raw=True`` returns the :class:`~dashscope.transport.APIResponse`
        of the underlying call before any error check.
        """
        return self._jobs.list(
            start_time=start_time,
            end_time=end_time,
            model_name=model_name,
            api_key_id=api_key_id,
            region=region,
            status=status,
            page_no=page_no,
            page_size=page_size,
            api_key=api_key,
            workspace=workspace,
            timeout=timeout,
            extra_headers=extra_headers,
            extra_query=extra_query,
            extra_body=extra_body,
            max_retries=max_retries,
            raw=raw,
        )

    def wait(
        self,
        job: Union[Job, str],
        *,
        poll_interval: float = DEFAULT_POLL_INTERVAL,
        max_interval: float = DEFAULT_MAX_INTERVAL,
        timeout: float = DEFAULT_WAIT_TIMEOUT,
        api_key: Optional[str] = None,
        workspace: Optional[str] = None,
        extra_headers: Optional[Mapping[str, str]] = None,
        extra_query: Optional[Mapping[str, Any]] = None,
        extra_body: Optional[Mapping[str, Any]] = None,
        max_retries: Optional[int] = None,
        _sleep: Optional[Callable[[float], Any]] = None,
    ) -> Job:
        return self._jobs.wait(
            job,
            poll_interval=poll_interval,
            max_interval=max_interval,
            timeout=timeout,
            api_key=api_key,
            workspace=workspace,
            extra_headers=extra_headers,
            extra_query=extra_query,
            extra_body=extra_body,
            max_retries=max_retries,
            _sleep=_sleep,
        )


class AsyncEmbeddingJobs:
    def __init__(self, client) -> None:
        self._jobs = AsyncJobs(client, _BATCH_SERVICE, MODULE)

    @overload
    async def create(
        self,
        *,
        model: str,
        file_url: str,
        text_type: Optional[str] = None,
        parameters: Optional[Dict[str, Any]] = None,
        timeout: Optional[float] = None,
        api_key: Optional[str] = None,
        workspace: Optional[str] = None,
        extra_headers: Optional[Mapping[str, str]] = None,
        extra_query: Optional[Mapping[str, Any]] = None,
        extra_body: Optional[Mapping[str, Any]] = None,
        max_retries: Optional[int] = None,
        raw: Literal[False] = False,
    ) -> Job:
        ...

    @overload
    async def create(
        self,
        *,
        model: str,
        file_url: str,
        text_type: Optional[str] = None,
        parameters: Optional[Dict[str, Any]] = None,
        timeout: Optional[float] = None,
        api_key: Optional[str] = None,
        workspace: Optional[str] = None,
        extra_headers: Optional[Mapping[str, str]] = None,
        extra_query: Optional[Mapping[str, Any]] = None,
        extra_body: Optional[Mapping[str, Any]] = None,
        max_retries: Optional[int] = None,
        raw: Literal[True],
    ) -> "APIResponse":
        ...

    async def create(
        self,
        *,
        model: str,
        file_url: str,
        text_type: Optional[str] = None,
        parameters: Optional[Dict[str, Any]] = None,
        timeout: Optional[float] = None,
        api_key: Optional[str] = None,
        workspace: Optional[str] = None,
        extra_headers: Optional[Mapping[str, str]] = None,
        extra_query: Optional[Mapping[str, Any]] = None,
        extra_body: Optional[Mapping[str, Any]] = None,
        max_retries: Optional[int] = None,
        raw: bool = False,
    ) -> Union[Job, "APIResponse"]:
        """Submit a batch task over one file whose lines are the texts.

        Singular, unlike ``asr.transcribe(file_urls=)``: this endpoint
        accepts exactly one file.

        ``raw=True`` returns the :class:`~dashscope.transport.APIResponse`
        of the underlying call before any error check.
        """
        if not file_url:
            raise ValueError("file_url must not be empty")
        merged = dict(parameters or {})
        if text_type is not None:
            merged["text_type"] = text_type
        return await self._jobs.create(
            model=model,
            input={"url": file_url},
            parameters=merged or None,
            api_key=api_key,
            workspace=workspace,
            timeout=timeout,
            extra_headers=extra_headers,
            extra_query=extra_query,
            extra_body=extra_body,
            max_retries=max_retries,
            raw=raw,
        )

    @overload
    async def fetch(
        self,
        task_id: str,
        *,
        timeout: Optional[float] = None,
        api_key: Optional[str] = None,
        workspace: Optional[str] = None,
        extra_headers: Optional[Mapping[str, str]] = None,
        extra_query: Optional[Mapping[str, Any]] = None,
        extra_body: Optional[Mapping[str, Any]] = None,
        max_retries: Optional[int] = None,
        raw: Literal[False] = False,
    ) -> Job:
        ...

    @overload
    async def fetch(
        self,
        task_id: str,
        *,
        timeout: Optional[float] = None,
        api_key: Optional[str] = None,
        workspace: Optional[str] = None,
        extra_headers: Optional[Mapping[str, str]] = None,
        extra_query: Optional[Mapping[str, Any]] = None,
        extra_body: Optional[Mapping[str, Any]] = None,
        max_retries: Optional[int] = None,
        raw: Literal[True],
    ) -> "APIResponse":
        ...

    async def fetch(
        self,
        task_id: str,
        *,
        timeout: Optional[float] = None,
        api_key: Optional[str] = None,
        workspace: Optional[str] = None,
        extra_headers: Optional[Mapping[str, str]] = None,
        extra_query: Optional[Mapping[str, Any]] = None,
        extra_body: Optional[Mapping[str, Any]] = None,
        max_retries: Optional[int] = None,
        raw: bool = False,
    ) -> Union[Job, "APIResponse"]:
        """Fetch one task snapshot.

        ``raw=True`` returns the :class:`~dashscope.transport.APIResponse`
        of the underlying call before any error check.
        """
        return await self._jobs.fetch(
            task_id,
            api_key=api_key,
            workspace=workspace,
            timeout=timeout,
            extra_headers=extra_headers,
            extra_query=extra_query,
            extra_body=extra_body,
            max_retries=max_retries,
            raw=raw,
        )

    @overload
    async def cancel(
        self,
        task_id: str,
        *,
        timeout: Optional[float] = None,
        api_key: Optional[str] = None,
        workspace: Optional[str] = None,
        extra_headers: Optional[Mapping[str, str]] = None,
        extra_query: Optional[Mapping[str, Any]] = None,
        extra_body: Optional[Mapping[str, Any]] = None,
        max_retries: Optional[int] = None,
        raw: Literal[False] = False,
    ) -> Job:
        ...

    @overload
    async def cancel(
        self,
        task_id: str,
        *,
        timeout: Optional[float] = None,
        api_key: Optional[str] = None,
        workspace: Optional[str] = None,
        extra_headers: Optional[Mapping[str, str]] = None,
        extra_query: Optional[Mapping[str, Any]] = None,
        extra_body: Optional[Mapping[str, Any]] = None,
        max_retries: Optional[int] = None,
        raw: Literal[True],
    ) -> "APIResponse":
        ...

    async def cancel(
        self,
        task_id: str,
        *,
        timeout: Optional[float] = None,
        api_key: Optional[str] = None,
        workspace: Optional[str] = None,
        extra_headers: Optional[Mapping[str, str]] = None,
        extra_query: Optional[Mapping[str, Any]] = None,
        extra_body: Optional[Mapping[str, Any]] = None,
        max_retries: Optional[int] = None,
        raw: bool = False,
    ) -> Union[Job, "APIResponse"]:
        """Cancel a PENDING task (``POST /tasks/{task_id}/cancel``).

        ``raw=True`` returns the :class:`~dashscope.transport.APIResponse`
        of the underlying call before any error check.
        """
        return await self._jobs.cancel(
            task_id,
            api_key=api_key,
            workspace=workspace,
            timeout=timeout,
            extra_headers=extra_headers,
            extra_query=extra_query,
            extra_body=extra_body,
            max_retries=max_retries,
            raw=raw,
        )

    @overload
    async def list(  # pylint: disable=redefined-builtin
        self,
        *,
        start_time: Optional[str] = None,
        end_time: Optional[str] = None,
        model_name: Optional[str] = None,
        api_key_id: Optional[str] = None,
        region: Optional[str] = None,
        status: Optional[str] = None,
        page_no: int = 1,
        page_size: int = 10,
        timeout: Optional[float] = None,
        api_key: Optional[str] = None,
        workspace: Optional[str] = None,
        extra_headers: Optional[Mapping[str, str]] = None,
        extra_query: Optional[Mapping[str, Any]] = None,
        extra_body: Optional[Mapping[str, Any]] = None,
        max_retries: Optional[int] = None,
        raw: Literal[False] = False,
    ) -> JobList:
        ...

    @overload
    async def list(  # pylint: disable=redefined-builtin
        self,
        *,
        start_time: Optional[str] = None,
        end_time: Optional[str] = None,
        model_name: Optional[str] = None,
        api_key_id: Optional[str] = None,
        region: Optional[str] = None,
        status: Optional[str] = None,
        page_no: int = 1,
        page_size: int = 10,
        timeout: Optional[float] = None,
        api_key: Optional[str] = None,
        workspace: Optional[str] = None,
        extra_headers: Optional[Mapping[str, str]] = None,
        extra_query: Optional[Mapping[str, Any]] = None,
        extra_body: Optional[Mapping[str, Any]] = None,
        max_retries: Optional[int] = None,
        raw: Literal[True],
    ) -> "APIResponse":
        ...

    async def list(  # pylint: disable=redefined-builtin
        self,
        *,
        start_time: Optional[str] = None,
        end_time: Optional[str] = None,
        model_name: Optional[str] = None,
        api_key_id: Optional[str] = None,
        region: Optional[str] = None,
        status: Optional[str] = None,
        page_no: int = 1,
        page_size: int = 10,
        timeout: Optional[float] = None,
        api_key: Optional[str] = None,
        workspace: Optional[str] = None,
        extra_headers: Optional[Mapping[str, str]] = None,
        extra_query: Optional[Mapping[str, Any]] = None,
        extra_body: Optional[Mapping[str, Any]] = None,
        max_retries: Optional[int] = None,
        raw: bool = False,
    ) -> Union[JobList, "APIResponse"]:
        """List async tasks (``GET /tasks``).

        ``raw=True`` returns the :class:`~dashscope.transport.APIResponse`
        of the underlying call before any error check.
        """
        return await self._jobs.list(
            start_time=start_time,
            end_time=end_time,
            model_name=model_name,
            api_key_id=api_key_id,
            region=region,
            status=status,
            page_no=page_no,
            page_size=page_size,
            api_key=api_key,
            workspace=workspace,
            timeout=timeout,
            extra_headers=extra_headers,
            extra_query=extra_query,
            extra_body=extra_body,
            max_retries=max_retries,
            raw=raw,
        )

    async def wait(
        self,
        job: Union[Job, str],
        *,
        poll_interval: float = DEFAULT_POLL_INTERVAL,
        max_interval: float = DEFAULT_MAX_INTERVAL,
        timeout: float = DEFAULT_WAIT_TIMEOUT,
        api_key: Optional[str] = None,
        workspace: Optional[str] = None,
        extra_headers: Optional[Mapping[str, str]] = None,
        extra_query: Optional[Mapping[str, Any]] = None,
        extra_body: Optional[Mapping[str, Any]] = None,
        max_retries: Optional[int] = None,
        _sleep: Optional[Callable[[float], Awaitable[None]]] = None,
    ) -> Job:
        return await self._jobs.wait(
            job,
            poll_interval=poll_interval,
            max_interval=max_interval,
            timeout=timeout,
            api_key=api_key,
            workspace=workspace,
            extra_headers=extra_headers,
            extra_query=extra_query,
            extra_body=extra_body,
            max_retries=max_retries,
            _sleep=_sleep,
        )


class Embeddings:
    def __init__(self, client) -> None:
        self._client = client
        self.jobs = EmbeddingJobs(client)

    @overload
    def create(
        self,
        *,
        model: str,
        input: Union[str, List[str]],
        text_type: Optional[str] = None,
        dimension: Optional[int] = None,
        output_type: Optional[str] = None,
        instruct: Optional[str] = None,
        parameters: Optional[Dict[str, Any]] = None,
        timeout: Optional[float] = None,
        api_key: Optional[str] = None,
        workspace: Optional[str] = None,
        extra_headers: Optional[Mapping[str, str]] = None,
        extra_query: Optional[Mapping[str, Any]] = None,
        extra_body: Optional[Mapping[str, Any]] = None,
        max_retries: Optional[int] = None,
        raw: Literal[False] = False,
    ) -> EmbeddingResponse:
        ...

    @overload
    def create(
        self,
        *,
        model: str,
        input: Union[str, List[str]],
        text_type: Optional[str] = None,
        dimension: Optional[int] = None,
        output_type: Optional[str] = None,
        instruct: Optional[str] = None,
        parameters: Optional[Dict[str, Any]] = None,
        timeout: Optional[float] = None,
        api_key: Optional[str] = None,
        workspace: Optional[str] = None,
        extra_headers: Optional[Mapping[str, str]] = None,
        extra_query: Optional[Mapping[str, Any]] = None,
        extra_body: Optional[Mapping[str, Any]] = None,
        max_retries: Optional[int] = None,
        raw: Literal[True],
    ) -> "APIResponse":
        ...

    def create(
        self,
        *,
        model: str,
        input: Union[str, List[str]],
        text_type: Optional[str] = None,
        dimension: Optional[int] = None,
        output_type: Optional[str] = None,
        instruct: Optional[str] = None,
        parameters: Optional[Dict[str, Any]] = None,
        timeout: Optional[float] = None,
        api_key: Optional[str] = None,
        workspace: Optional[str] = None,
        extra_headers: Optional[Mapping[str, str]] = None,
        extra_query: Optional[Mapping[str, Any]] = None,
        extra_body: Optional[Mapping[str, Any]] = None,
        max_retries: Optional[int] = None,
        raw: bool = False,
    ) -> Union[EmbeddingResponse, "APIResponse"]:
        body = _build_body(
            model=model,
            input=input,
            text_type=text_type,
            dimension=dimension,
            output_type=output_type,
            instruct=instruct,
            parameters=parameters,
        )
        resp = self._client.transport.request_api(
            "POST",
            _PATH,
            json=body,
            timeout=timeout,
            api_key=api_key,
            workspace=workspace,
            sdk_module=MODULE,
            options=request_options(
                extra_headers,
                extra_query,
                extra_body,
                max_retries=max_retries,
            ),
            client=self._client,
        )
        if raw:
            return resp
        resp.raise_for_status()
        return with_headers(
            parse_embedding_response(
                resp.json(),
                strict=self._client.config.strict_validation,
                response=resp.http_response,
            ),
            resp.http_response,
        )


class AsyncEmbeddings:
    def __init__(self, client) -> None:
        self._client = client
        self.jobs = AsyncEmbeddingJobs(client)

    @overload
    async def create(
        self,
        *,
        model: str,
        input: Union[str, List[str]],
        text_type: Optional[str] = None,
        dimension: Optional[int] = None,
        output_type: Optional[str] = None,
        instruct: Optional[str] = None,
        parameters: Optional[Dict[str, Any]] = None,
        timeout: Optional[float] = None,
        api_key: Optional[str] = None,
        workspace: Optional[str] = None,
        extra_headers: Optional[Mapping[str, str]] = None,
        extra_query: Optional[Mapping[str, Any]] = None,
        extra_body: Optional[Mapping[str, Any]] = None,
        max_retries: Optional[int] = None,
        raw: Literal[False] = False,
    ) -> EmbeddingResponse:
        ...

    @overload
    async def create(
        self,
        *,
        model: str,
        input: Union[str, List[str]],
        text_type: Optional[str] = None,
        dimension: Optional[int] = None,
        output_type: Optional[str] = None,
        instruct: Optional[str] = None,
        parameters: Optional[Dict[str, Any]] = None,
        timeout: Optional[float] = None,
        api_key: Optional[str] = None,
        workspace: Optional[str] = None,
        extra_headers: Optional[Mapping[str, str]] = None,
        extra_query: Optional[Mapping[str, Any]] = None,
        extra_body: Optional[Mapping[str, Any]] = None,
        max_retries: Optional[int] = None,
        raw: Literal[True],
    ) -> "APIResponse":
        ...

    async def create(
        self,
        *,
        model: str,
        input: Union[str, List[str]],
        text_type: Optional[str] = None,
        dimension: Optional[int] = None,
        output_type: Optional[str] = None,
        instruct: Optional[str] = None,
        parameters: Optional[Dict[str, Any]] = None,
        timeout: Optional[float] = None,
        api_key: Optional[str] = None,
        workspace: Optional[str] = None,
        extra_headers: Optional[Mapping[str, str]] = None,
        extra_query: Optional[Mapping[str, Any]] = None,
        extra_body: Optional[Mapping[str, Any]] = None,
        max_retries: Optional[int] = None,
        raw: bool = False,
    ) -> Union[EmbeddingResponse, "APIResponse"]:
        body = _build_body(
            model=model,
            input=input,
            text_type=text_type,
            dimension=dimension,
            output_type=output_type,
            instruct=instruct,
            parameters=parameters,
        )
        resp = await self._client.transport.request_api(
            "POST",
            _PATH,
            json=body,
            timeout=timeout,
            api_key=api_key,
            workspace=workspace,
            sdk_module=MODULE,
            options=request_options(
                extra_headers,
                extra_query,
                extra_body,
                max_retries=max_retries,
            ),
            client=self._client,
        )
        if raw:
            return resp
        resp.raise_for_status()
        return with_headers(
            parse_embedding_response(
                resp.json(),
                strict=self._client.config.strict_validation,
                response=resp.http_response,
            ),
            resp.http_response,
        )
