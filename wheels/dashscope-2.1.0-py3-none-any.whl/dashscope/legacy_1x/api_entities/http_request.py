# -*- coding: utf-8 -*-
# Copyright (c) Alibaba, Inc. and its affiliates.
import atexit
import datetime
import json
import socket
import threading
from http import HTTPStatus
from typing import Callable, List, Optional, Dict, Tuple, Union

import aiohttp
import requests
from requests.adapters import HTTPAdapter

from dashscope.legacy_1x.api_entities.aio_session import (
    get_shared_aio_session,
    send_with_retry_async,
)
from dashscope.legacy_1x.api_entities.base_request import AioBaseRequest
from dashscope.legacy_1x.api_entities.dashscope_response import (
    DashScopeAPIResponse,
)
from dashscope.legacy_1x.common.constants import (
    DEFAULT_REQUEST_TIMEOUT_SECONDS,
    SSE_CONTENT_TYPE,
    HTTPMethod,
)
from dashscope.legacy_1x.common.error import UnsupportedHTTPMethod
from dashscope.legacy_1x.common.logging import logger
from dashscope.legacy_1x.common.utils import (
    _handle_aio_stream,
    _handle_aiohttp_failed_response,
    _handle_http_failed_response,
    _handle_stream,
)
from dashscope.legacy_1x.api_entities.encryption import Encryption

# Shared synchronous session for connection pooling
_shared_sync_session: Optional[requests.Session] = None
_shared_sync_session_lock = threading.Lock()

# TCP keepalive tuning for the shared synchronous session's connection
# pool. A pooled keep-alive connection that has been silently dropped by
# a NAT gateway or load balancer (no FIN/RST received) is detected by the
# kernel once it stays idle for roughly
# _TCP_KEEPIDLE_SECONDS + _TCP_KEEPCNT * _TCP_KEEPINTVL_SECONDS, so the
# next reuse fails fast with ConnectionError (which is retried once)
# instead of stalling until the full read timeout expires.
_TCP_KEEPIDLE_SECONDS = 60
_TCP_KEEPINTVL_SECONDS = 30
_TCP_KEEPCNT = 3


def _tcp_keepalive_socket_options() -> List[Tuple[int, int, int]]:
    """Socket options enabling TCP keepalive on pooled connections.

    urllib3 replaces its default socket options (TCP_NODELAY) as soon as
    custom options are supplied, so TCP_NODELAY is repeated here. The
    keepalive timer options are best-effort: TCP_KEEPIDLE is Linux,
    TCP_KEEPALIVE is the macOS equivalent, and on other platforms only
    SO_KEEPALIVE is applied with the system default timers.
    """
    options = [
        (socket.IPPROTO_TCP, socket.TCP_NODELAY, 1),
        (socket.SOL_SOCKET, socket.SO_KEEPALIVE, 1),
    ]
    keepidle = getattr(socket, "TCP_KEEPIDLE", None)
    if keepidle is None:
        keepidle = getattr(socket, "TCP_KEEPALIVE", None)  # macOS
    if keepidle is not None:
        options.append(
            (socket.IPPROTO_TCP, keepidle, _TCP_KEEPIDLE_SECONDS),
        )
    keepintvl = getattr(socket, "TCP_KEEPINTVL", None)
    if keepintvl is not None:
        options.append(
            (socket.IPPROTO_TCP, keepintvl, _TCP_KEEPINTVL_SECONDS),
        )
    keepcnt = getattr(socket, "TCP_KEEPCNT", None)
    if keepcnt is not None:
        options.append((socket.IPPROTO_TCP, keepcnt, _TCP_KEEPCNT))
    return options


class _KeepAliveHTTPAdapter(HTTPAdapter):
    """HTTPAdapter whose pooled connections enable TCP keepalive."""

    def init_poolmanager(self, connections, maxsize, block=False, **kwargs):
        kwargs.setdefault(
            "socket_options",
            _tcp_keepalive_socket_options(),
        )
        super().init_poolmanager(
            connections,
            maxsize,
            block=block,
            **kwargs,
        )

    def proxy_manager_for(self, proxy, **kwargs):
        kwargs.setdefault(
            "socket_options",
            _tcp_keepalive_socket_options(),
        )
        return super().proxy_manager_for(proxy, **kwargs)


def _create_shared_sync_session() -> requests.Session:
    session = requests.Session()
    adapter = _KeepAliveHTTPAdapter()
    session.mount("http://", adapter)
    session.mount("https://", adapter)
    return session


def _get_shared_sync_session() -> requests.Session:
    """Return a shared requests.Session for connection pooling.

    The session is created lazily and reused for the process lifetime.
    Call close_shared_sync_session() to release its pooled connections.
    """
    global _shared_sync_session
    if _shared_sync_session is None:
        with _shared_sync_session_lock:
            if _shared_sync_session is None:
                _shared_sync_session = _create_shared_sync_session()
    return _shared_sync_session


def close_shared_sync_session() -> None:
    """Close the shared synchronous session and its pooled connections.

    Long-running applications may call this to bound the lifetime of the
    SDK-managed connection pool (e.g. periodically, or after a transport
    failure). A fresh session is created lazily on the next request.
    """
    global _shared_sync_session
    with _shared_sync_session_lock:
        session = _shared_sync_session
        _shared_sync_session = None
    if session is not None:
        session.close()


# Release pooled connections at interpreter exit.
atexit.register(close_shared_sync_session)


def _send_with_retry(
    send: Callable[[], requests.Response],
) -> requests.Response:
    """Send a request, retrying once on a dropped pooled connection.

    A keep-alive connection idle in the pool may have been closed by the
    server or an intermediate LB; reusing it raises ConnectionError before
    any response bytes arrive, so the request was not processed and is
    safe to resend on a fresh connection.
    """
    try:
        return send()
    except requests.exceptions.ConnectionError as e:
        logger.debug(
            "Connection dropped before response, retrying once: %s",
            e,
        )
        return send()


class HttpRequest(AioBaseRequest):
    def __init__(
        self,
        url: str,
        api_key: str,
        http_method: str,
        stream: bool = True,
        async_request: bool = False,
        query: bool = False,
        timeout: int = DEFAULT_REQUEST_TIMEOUT_SECONDS,
        task_id: str = None,
        flattened_output: bool = False,
        encryption: Optional[Encryption] = None,
        user_agent: str = "",
        session: Optional[
            Union[requests.Session, aiohttp.ClientSession]
        ] = None,
    ) -> None:
        """HttpSSERequest, processing http server sent event stream.

        Args:
            url (str): The request url.
            api_key (str): The api key.
            method (str): The http method(GET|POST).
            stream (bool, optional): Is stream request. Defaults to True.
            timeout (int, optional): Request timeout in seconds. For streaming
                requests, this is the idle timeout between chunks (sock_read);
                for non-streaming requests, this is the total request timeout.
                Defaults to DEFAULT_REQUEST_TIMEOUT_SECONDS.
            user_agent (str, optional): Additional user agent string to
                append. Defaults to ''.
            session (Optional[Union[requests.Session,
                aiohttp.ClientSession]], optional):
                Custom Session for connection reuse. Can be either
                requests.Session for sync calls or aiohttp.ClientSession
                for async calls. Defaults to None.
        """

        super().__init__(user_agent=user_agent)
        self.url = url
        self.flattened_output = flattened_output
        self.async_request = async_request
        self.encryption = encryption

        # Auto-detect session type and store accordingly
        if session is not None:
            session_type = type(session).__name__
            session_module = type(session).__module__

            # Check if it's an aiohttp ClientSession
            if (
                session_type == "ClientSession" and "aiohttp" in session_module
            ) or isinstance(session, aiohttp.ClientSession):
                self._external_session = None
                self._external_aio_session = session
            else:
                # Treat as requests Session
                self._external_session = session
                self._external_aio_session = None
        else:
            self._external_session = None
            self._external_aio_session = None
        self.headers: Dict = {
            "Accept": "application/json; charset=utf-8",
            "Authorization": f"Bearer {api_key}",
            **self.headers,
        }

        if encryption and encryption.is_valid():
            self.headers = {
                "X-DashScope-EncryptionKey": json.dumps(
                    {
                        "public_key_id": encryption.get_pub_key_id(),
                        "encrypt_key": encryption.get_encrypted_aes_key_str(),
                        "iv": encryption.get_base64_iv_str(),
                    },
                ),
                **self.headers,
            }

        self.query = query
        if self.async_request and self.query is False:
            self.headers = {
                "X-DashScope-Async": "enable",
                **self.headers,
            }
        self.method = http_method
        if self.method == HTTPMethod.POST:
            self.headers["Content-Type"] = "application/json; charset=utf-8"

        self.stream = stream
        if self.stream:
            self.headers["Accept"] = SSE_CONTENT_TYPE
            self.headers["X-Accel-Buffering"] = "no"
            self.headers["X-DashScope-SSE"] = "enable"
        if self.query:
            self.url = self.url.replace("/api/", "/api-task/", 1)
            self.url += f"{task_id}"
        if timeout is None:
            self.timeout = DEFAULT_REQUEST_TIMEOUT_SECONDS
        else:
            self.timeout = timeout  # type: ignore[has-type]

    def add_header(self, key, value):
        self.headers[key] = value

    def add_headers(self, headers):
        self.headers.update(headers)

    def call(self):
        response = self._handle_request()
        if self.stream:
            return (item for item in response)
        else:
            output = next(response)
            try:
                next(response)
            except StopIteration:
                pass
            return output

    async def aio_call(self):
        response = self._handle_aio_request()
        if self.stream:
            return (item async for item in response)
        else:
            result = await response.__anext__()
            try:
                await response.__anext__()
            except StopAsyncIteration:
                pass
            return result

    async def _handle_aio_request(self):  # pylint: disable=too-many-branches
        try:
            # Use external aio_session if provided,
            # otherwise use shared session with connection pooling
            if self._external_aio_session is not None:
                session = self._external_aio_session
                should_close = False
            else:
                session = await get_shared_aio_session()
                should_close = False

            try:
                if self.stream:
                    request_timeout = aiohttp.ClientTimeout(
                        total=None,
                        sock_read=self.timeout,
                    )
                else:
                    request_timeout = aiohttp.ClientTimeout(total=self.timeout)

                logger.debug("Starting request: %s", self.url)
                if self.method == HTTPMethod.POST:
                    is_form, obj = False, {}
                    if hasattr(self, "data") and self.data is not None:
                        is_form, obj = self.data.get_aiohttp_payload()
                    if is_form:
                        headers = {**self.headers, **obj.headers}
                        response = await session.post(
                            url=self.url,
                            data=obj,
                            headers=headers,
                            timeout=request_timeout,
                        )
                    else:
                        body = json.dumps(obj, ensure_ascii=False).encode(
                            "utf-8",
                        )
                        response = await send_with_retry_async(
                            lambda: session.request(
                                "POST",
                                url=self.url,
                                data=body,
                                headers=self.headers,
                                timeout=request_timeout,
                            ),
                        )
                elif self.method == HTTPMethod.GET:
                    params = {}
                    if hasattr(self, "data") and self.data is not None:
                        params = getattr(self.data, "parameters", {})
                    if params:
                        params = self.__handle_parameters(params)
                    response = await send_with_retry_async(
                        lambda: session.get(
                            url=self.url,
                            params=params,
                            headers=self.headers,
                            timeout=request_timeout,
                        ),
                    )
                else:
                    raise UnsupportedHTTPMethod(
                        f"Unsupported http method: {self.method}",
                    )
                logger.debug("Response returned: %s", self.url)
                async with response:
                    async for rsp in self._handle_aio_response(response):
                        yield rsp
            finally:
                if should_close:
                    await session.close()
        except Exception:
            logger.exception("Request failed")
            raise

    @staticmethod
    def __handle_parameters(params: dict) -> dict:
        # pylint: disable=too-many-return-statements
        def __format(value):
            if isinstance(value, bool):
                return str(value).lower()
            elif isinstance(value, (str, int, float)):
                return value
            elif value is None:
                return ""
            elif isinstance(value, (datetime.datetime, datetime.date)):
                return value.isoformat()
            elif isinstance(value, (list, tuple)):
                return ",".join(str(__format(x)) for x in value)
            elif isinstance(value, dict):
                return json.dumps(value)
            else:
                try:
                    return str(value)
                except Exception as e:
                    # pylint: disable=raise-missing-from
                    raise ValueError(
                        f"Unsupported type {type(value)} for param formatting: {e}",  # noqa: E501
                    )

        formatted = {}
        for k, v in params.items():
            formatted[k] = __format(v)
        # pylint: disable=too-many-statements
        return formatted

    async def _handle_aio_response(  # pylint: disable=too-many-branches, too-many-statements # noqa: E501
        self,
        response: aiohttp.ClientResponse,
    ):
        request_id = ""
        headers = dict(response.headers)
        if (
            response.status == HTTPStatus.OK
            and self.stream
            and SSE_CONTENT_TYPE in response.content_type
        ):
            async for is_error, status_code, data in _handle_aio_stream(
                response,
            ):
                try:
                    output = None
                    usage = None
                    msg = json.loads(data)
                    if not is_error:
                        if "output" in msg:
                            output = msg["output"]
                        if "usage" in msg:
                            usage = msg["usage"]
                    if "request_id" in msg:
                        request_id = msg["request_id"]
                except json.JSONDecodeError:
                    yield DashScopeAPIResponse(
                        request_id=request_id,
                        status_code=HTTPStatus.INTERNAL_SERVER_ERROR,
                        code="Unknown",
                        message=data,
                        headers=headers,
                    )
                    continue
                if is_error:
                    yield DashScopeAPIResponse(
                        request_id=request_id,
                        status_code=status_code,
                        code=msg["code"],
                        message=msg["message"],
                        headers=headers,
                    )
                else:
                    if self.encryption and self.encryption.is_valid():
                        output = self.encryption.decrypt(output)
                    yield DashScopeAPIResponse(
                        request_id=request_id,
                        status_code=HTTPStatus.OK,
                        output=output,
                        usage=usage,
                        headers=headers,
                    )
        elif (
            response.status == HTTPStatus.OK
            and "multipart" in response.content_type
        ):
            reader = aiohttp.MultipartReader.from_response(response)
            output = {}
            while True:
                part = await reader.next()
                if part is None:
                    # pylint: disable=consider-using-get
                    break
                output[part.name] = await part.read()
            if "request_id" in output:  # pylint: disable=consider-using-get
                request_id = output["request_id"]
            if self.encryption and self.encryption.is_valid():
                output = self.encryption.decrypt(output)
            yield DashScopeAPIResponse(
                request_id=request_id,
                status_code=HTTPStatus.OK,
                output=output,
                headers=headers,
            )
        elif response.status == HTTPStatus.OK:
            json_content = await response.json()
            output = None
            usage = None
            if "output" in json_content and json_content["output"] is not None:
                output = json_content["output"]
            # Compatible with wan
            elif (
                "data" in json_content
                and json_content["data"] is not None
                and isinstance(json_content["data"], list)
                and len(json_content["data"]) > 0
                and "task_id" in json_content["data"][0]
            ):
                output = json_content
            if "usage" in json_content:
                usage = json_content["usage"]
            if "request_id" in json_content:
                request_id = json_content["request_id"]
            if self.encryption and self.encryption.is_valid():
                output = self.encryption.decrypt(output)
            yield DashScopeAPIResponse(
                request_id=request_id,
                status_code=HTTPStatus.OK,
                output=output,
                usage=usage,
                headers=headers,
            )
        else:
            yield await _handle_aiohttp_failed_response(response)

    def _handle_response(  # pylint: disable=too-many-branches
        self,
        response: requests.Response,
    ):
        request_id = ""
        headers = dict(response.headers)
        if (
            response.status_code == HTTPStatus.OK
            and self.stream
            and SSE_CONTENT_TYPE
            in response.headers.get(
                "content-type",
                "",
            )
        ):
            for is_error, status_code, event in _handle_stream(response):
                try:
                    data = event.data
                    output = None
                    usage = None
                    msg = json.loads(data)
                    logger.debug("Stream message: %s", msg)
                    if not is_error:
                        if "output" in msg:
                            output = msg["output"]
                        if "usage" in msg:
                            usage = msg["usage"]
                    if "request_id" in msg:
                        request_id = msg["request_id"]
                except json.JSONDecodeError:
                    yield DashScopeAPIResponse(
                        request_id=request_id,
                        status_code=HTTPStatus.BAD_REQUEST,
                        output=None,
                        code="Unknown",
                        message=data,
                        headers=headers,
                    )
                    continue
                if is_error:
                    yield DashScopeAPIResponse(
                        request_id=request_id,
                        status_code=status_code,
                        output=None,
                        code=msg["code"]
                        if "code" in msg
                        else None,  # noqa E501
                        message=msg["message"] if "message" in msg else None,
                        headers=headers,
                    )  # noqa E501
                else:
                    if self.flattened_output:
                        yield msg
                    else:
                        if self.encryption and self.encryption.is_valid():
                            output = self.encryption.decrypt(output)
                        yield DashScopeAPIResponse(
                            request_id=request_id,
                            status_code=HTTPStatus.OK,
                            output=output,
                            usage=usage,
                            headers=headers,
                        )
        elif response.status_code == HTTPStatus.OK:
            json_content = response.json()
            logger.debug("Response: %s", json_content)
            output = None
            usage = None
            if "output" in json_content:
                output = json_content["output"]
            elif "task_id" in json_content:
                output = {"task_id": json_content["task_id"]}
            if "usage" in json_content:
                usage = json_content["usage"]
            if "request_id" in json_content:
                request_id = json_content["request_id"]
            if self.flattened_output:
                yield json_content
            else:
                if self.encryption and self.encryption.is_valid():
                    output = self.encryption.decrypt(output)
                yield DashScopeAPIResponse(
                    request_id=request_id,
                    status_code=HTTPStatus.OK,
                    output=output,
                    usage=usage,
                    headers=headers,
                )
        else:
            yield _handle_http_failed_response(response)

    def _handle_request(self):  # pylint: disable=too-many-branches
        try:
            # Use external session if provided,
            # otherwise use shared session with connection pooling
            if self._external_session is not None:
                session = self._external_session
            else:
                session = _get_shared_sync_session()

            if self.method == HTTPMethod.POST:
                is_form, form, obj = False, None, {}
                if hasattr(self, "data") and self.data is not None:
                    is_form, form, obj = self.data.get_http_payload()
                if is_form:
                    headers = {**self.headers}
                    headers.pop("Content-Type")
                    response = session.post(
                        url=self.url,
                        data=obj,
                        files=form,
                        headers=headers,
                        timeout=self.timeout,
                    )
                else:
                    logger.debug("Request body: %s", obj)
                    body = json.dumps(obj, ensure_ascii=False).encode(
                        "utf-8",
                    )
                    response = _send_with_retry(
                        lambda: session.post(
                            url=self.url,
                            stream=self.stream,
                            data=body,
                            headers={**self.headers},
                            timeout=self.timeout,
                        ),
                    )
            elif self.method == HTTPMethod.GET:
                params = {}
                if hasattr(self, "data") and self.data is not None:
                    params = getattr(self.data, "parameters", {})
                response = _send_with_retry(
                    lambda: session.get(
                        url=self.url,
                        params=params,
                        headers=self.headers,
                        timeout=self.timeout,
                    ),
                )
            else:
                raise UnsupportedHTTPMethod(
                    f"Unsupported http method: {self.method}",
                )
            for rsp in self._handle_response(response):
                yield rsp
        except Exception:
            logger.exception("Request failed")
            raise
